local fn = _gn(0x79EB2BC9)
function Global.ConnectLods(obj0, obj1)
	return _in2(fn, obj0, obj1)
end

local fn = _gn(0x69AE0805)
function Global.Vdist2(x0, y0, z0, x1, y1, z1)
	return _in2(fn, x0, y0, z0, x1, y1, z1, _rf)
end

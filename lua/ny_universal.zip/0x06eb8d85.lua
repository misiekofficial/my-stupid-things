local fn = _gn(0x62B15CD7)
function Global.NetworkInviteFriend(friendname, ukn)
	return _in2(fn, _ts(friendname), _ts(ukn))
end

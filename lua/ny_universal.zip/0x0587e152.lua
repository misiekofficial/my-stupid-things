local fn = _gn(0x15012850)
function Global.TaskCombatHatedTargetsAroundCharTimed(ped, radius, duration)
	return _in2(fn, ped, radius, duration)
end

local fn = _gn(0x53456730)
function Global.DeleteHtmlScriptObject(htmlobj)
	return _in2(fn, htmlobj)
end

local fn = _gn(0x2E291239)
function Global.IsCarUpsidedown(vehicle)
	return _in2(fn, vehicle, _r)
end

local fn = _gn(0x615959BA)
function Global.SetSpritesDrawBeforeFade(set)
	return _in2(fn, set)
end

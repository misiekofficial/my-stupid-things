local fn = _gn(0x7D635E2C)
function Global.DeleteMissionTrains()
	return _in2(fn)
end

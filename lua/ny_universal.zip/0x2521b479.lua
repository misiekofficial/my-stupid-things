local fn = _gn(0x0A9D695E)
function Global.ChangeBlipNameFromTextFile(blip, gxtName)
	return _in2(fn, blip, _ts(gxtName))
end

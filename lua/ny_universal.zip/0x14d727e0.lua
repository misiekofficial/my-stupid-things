local fn = _gn(0x61822A3C)
function Global.SetCharRelationshipGroup(ped, relationshipGroup)
	return _in2(fn, ped, relationshipGroup)
end

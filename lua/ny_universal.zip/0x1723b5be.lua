local fn = _gn(0x1C132038)
function Global.IsCharTryingToEnterALockedCar(ped)
	return _in2(fn, ped, _r)
end

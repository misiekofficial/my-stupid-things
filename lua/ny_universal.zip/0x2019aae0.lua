local fn = _gn(0x74F97CF8)
function Global.GetPedPathWillAvoidDynamicObjects(ped)
	return _in2(fn, ped, _r)
end

local fn = _gn(0x62E319C6)
function Global.GetPlayerId()
	return _in2(fn, _ri)
end

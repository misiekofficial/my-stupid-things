local fn = _gn(0x442B1C1D)
function Global.CreateCharAsPassenger(vehicle, charType, model, passengerIndex, pPed)
	return _in2(fn, vehicle, charType, model, passengerIndex, _ii(pPed) --[[ may be optional ]])
end

local fn = _gn(0x26AA20CF)
function Global.ClearPlayerHasDamagedAtLeastOneVehicle(player)
	return _in2(fn, player)
end

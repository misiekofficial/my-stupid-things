local fn = _gn(0x259E305F)
function Global.ToFloat(value)
	return _in2(fn, value, _rf)
end

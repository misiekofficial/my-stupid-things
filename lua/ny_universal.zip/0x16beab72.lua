local fn = _gn(0x5AA1795C)
function Global.SetPedAlpha(ped, alpha)
	return _in2(fn, ped, alpha)
end

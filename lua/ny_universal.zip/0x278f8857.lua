local fn = _gn(0x717B5EFB)
function Global.GetWebPageLinkPosn(htmlviewport, linkid)
	return _in2(fn, htmlviewport, linkid, _f, _f)
end

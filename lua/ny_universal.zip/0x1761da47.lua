local fn = _gn(0x6C654678)
function Global.HandVehicleControlBackToPlayer(veh)
	return _in2(fn, veh)
end

local fn = _gn(0x5DC456DE)
function Global.SetCharMoveAnimSpeedMultiplier(ped, multiplier)
	return _in2(fn, ped, multiplier)
end

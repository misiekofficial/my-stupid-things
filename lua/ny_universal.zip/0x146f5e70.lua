local fn = _gn(0x3CEB6C7B)
function Global.TaskSmartFleePointPreferringPavements(ped, x, y, z, radius, time_prob)
	return _in2(fn, ped, x, y, z, radius, time_prob)
end

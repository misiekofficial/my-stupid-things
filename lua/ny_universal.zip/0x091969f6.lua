local fn = _gn(0x511454A9)
function Global.GetPlayerChar(playerIndex, pPed)
	return _in2(fn, playerIndex, _ii(pPed) --[[ may be optional ]])
end

local fn = _gn(0x1EAD1D7D)
function Global.SetPedDontDoEvasiveDives(ped, value)
	return _in2(fn, ped, value)
end

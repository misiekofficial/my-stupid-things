local fn = _gn(0x930bd34b)
--- Removes the specified player from the user's voice targets.
-- Performs the opposite operation of [MUMBLE_ADD_VOICE_TARGET_PLAYER_BY_SERVER_ID](#\_0x25F2B65F)
-- @param targetId A Mumble voice target ID, ranging from 1..30 (inclusive).
-- @param serverId The player's server id to remove from the target.
function Global.MumbleRemoveVoiceTargetPlayerByServerId(targetId, serverId)
	return _in2(fn, targetId, serverId)
end

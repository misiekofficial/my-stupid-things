local fn = _gn(0x1C623537)
function Global.AddArmourToChar(ped, amount)
	return _in2(fn, ped, amount)
end

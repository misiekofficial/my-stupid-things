local fn = _gn(0x441B1EAF)
function Global.SetCharWeaponSkill(ped, skill)
	return _in2(fn, ped, skill)
end

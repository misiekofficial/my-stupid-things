local fn = _gn(0x63DE7A05)
function Global.SetVehHasStrongAxles(veh, set)
	return _in2(fn, veh, set)
end

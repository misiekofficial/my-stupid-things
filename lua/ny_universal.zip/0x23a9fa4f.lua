local fn = _gn(0x51112E95)
function Global.SetSyncWeatherAndGameTime(Unk997)
	return _in2(fn, Unk997)
end

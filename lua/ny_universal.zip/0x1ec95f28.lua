local fn = _gn(0x3CB4693B)
function Global.TaskCarMissionCoorsTargetNotAgainstTraffic(ped, vehicle, x, y, z, unknown0_4, speed, unknown2_1, unknown3_5, unknown4_10)
	return _in2(fn, ped, vehicle, x, y, z, unknown0_4, speed, unknown2_1, unknown3_5, unknown4_10)
end

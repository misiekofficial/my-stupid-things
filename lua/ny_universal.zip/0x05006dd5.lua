local fn = _gn(0x5E486AA1)
function Global.IsPedFleeing(ped)
	return _in2(fn, ped, _r)
end

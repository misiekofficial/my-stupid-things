local fn = _gn(0x3A115D9D)
function Global.ReleaseWeather()
	return _in2(fn)
end

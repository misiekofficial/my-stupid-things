local fn = _gn(0x426A4ED8)
function Global.SetAmbientVoiceName(ped, name)
	return _in2(fn, ped, _ts(name))
end

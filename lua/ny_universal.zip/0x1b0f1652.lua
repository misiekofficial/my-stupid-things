local fn = _gn(0x60AE0867)
function Global.PlaySoundFromObject(sound_id, name, obj)
	return _in2(fn, sound_id, _ts(name), obj)
end

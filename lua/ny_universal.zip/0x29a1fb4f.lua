local fn = _gn(0x5FFE33EC)
function Global.SetVehAlarmDuration(veh, duration)
	return _in2(fn, veh, duration)
end

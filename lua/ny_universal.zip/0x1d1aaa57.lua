local fn = _gn(0x02033258)
function Global.SetNextDesiredMoveState(state)
	return _in2(fn, state)
end

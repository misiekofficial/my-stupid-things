local fn = _gn(0x2E12687B)
function Global.AnchorBoat(boat, anchor)
	return _in2(fn, boat, anchor)
end

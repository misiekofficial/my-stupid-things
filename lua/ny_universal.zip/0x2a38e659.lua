local fn = _gn(0x48740598)
function Global.SetCamBehindPed(ped)
	return _in2(fn, ped)
end

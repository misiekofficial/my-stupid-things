local fn = _gn(0x486F3D93)
function Global.PlayAudioEvent(name)
	return _in2(fn, _ts(name))
end

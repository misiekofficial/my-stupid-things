local fn = _gn(0x51DF00D8)
function Global.NetworkIsFindResultValid(Unk883)
	return _in2(fn, Unk883, _r)
end

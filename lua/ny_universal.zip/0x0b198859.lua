local fn = _gn(0x68664078)
function Global.EnableChaseAudio(enable)
	return _in2(fn, enable)
end

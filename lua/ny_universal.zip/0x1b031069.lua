local fn = _gn(0x26747EBE)
function Global.PlaystatsMissionStarted(Unk797)
	return _in2(fn, Unk797)
end

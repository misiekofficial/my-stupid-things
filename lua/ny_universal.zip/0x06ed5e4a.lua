local fn = _gn(0x2B4E2A8C)
function Global.AddSpawnBlockingDisc(Unk904, Unk905, Unk906, Unk907, Unk908)
	return _in2(fn, Unk904, Unk905, Unk906, Unk907, Unk908)
end

local fn = _gn(0x7F4C0E47)
function Global.AsciiIntToString(ascii)
	return _in2(fn, ascii, _s)
end

local fn = _gn(0x775F6665)
function Global.IsPlaceCarBombActive()
	return _in2(fn, _r)
end

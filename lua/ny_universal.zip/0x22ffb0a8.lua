local fn = _gn(0x02491769)
function Global.StartPlaybackRecordedCarWithOffset(car, CarRec, x, y, z)
	return _in2(fn, car, CarRec, x, y, z)
end

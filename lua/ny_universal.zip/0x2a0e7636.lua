local fn = _gn(0x6D9538E1)
function Global.SetCharRelationship(ped, relationshipLevel, relationshipGroup)
	return _in2(fn, ped, relationshipLevel, relationshipGroup)
end

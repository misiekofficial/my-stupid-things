local fn = _gn(0x14007AC6)
function Global.GetStateOfClosestDoorOfType(model, x, y, z)
	return _in2(fn, model, x, y, z, _i, _f)
end

local fn = _gn(0x0B823C8D)
function Global.SetCarColourCombination(car, combination)
	return _in2(fn, car, combination)
end

local fn = _gn(0x690D344F)
function Global.BurstCarTyre(vehicle, tyre)
	return _in2(fn, vehicle, tyre)
end

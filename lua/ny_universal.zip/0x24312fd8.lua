local fn = _gn(0x79973C5A)
function Global.GetCharHeightAboveGround(ped, pValue)
	return _in2(fn, ped, _fi(pValue) --[[ may be optional ]])
end

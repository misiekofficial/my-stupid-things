local fn = _gn(0x051A131D)
function Global.GetIdOfThisThread()
	return _in2(fn, _ri)
end

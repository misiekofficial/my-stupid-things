local fn = _gn(0x4D2771CE)
function Global.ConvertMetresToFeet(metres)
	return _in2(fn, metres, _rf)
end

local fn = _gn(0x1E144C8B)
function Global.GetNumberOfFiresInArea(x0, y0, z0, x1, y1, z1)
	return _in2(fn, x0, y0, z0, x1, y1, z1, _ri)
end

local fn = _gn(0x03E90416)
function Global.GiveWeaponToChar(ped, weapon, ammo, unknown0)
	return _in2(fn, ped, weapon, ammo, unknown0)
end

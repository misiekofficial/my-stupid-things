local fn = _gn(0x103F14E4)
function Global.GetCharMeleeActionFlag0(ped)
	return _in2(fn, ped, _r)
end

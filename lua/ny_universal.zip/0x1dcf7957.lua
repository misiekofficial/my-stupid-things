local fn = _gn(0x08D85CBB)
function Global.ClearThisPrint(gxtentry)
	return _in2(fn, _ts(gxtentry))
end

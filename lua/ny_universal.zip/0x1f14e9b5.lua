local fn = _gn(0x315238D5)
function Global.BlockPedWeaponSwitching(ped, value)
	return _in2(fn, ped, value)
end

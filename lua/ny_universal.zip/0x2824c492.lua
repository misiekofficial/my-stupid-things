local fn = _gn(0x052A30F7)
function Global.IsThreadActive(threadId)
	return _in2(fn, threadId, _r)
end

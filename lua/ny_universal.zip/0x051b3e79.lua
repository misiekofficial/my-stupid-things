local fn = _gn(0x60AD2FE0)
function Global.SetCamNearDof(cam, dof)
	return _in2(fn, cam, dof)
end

local fn = _gn(0x141B23A9)
function Global.IsCarStoppedAtTrafficLights(vehicle)
	return _in2(fn, vehicle, _r)
end

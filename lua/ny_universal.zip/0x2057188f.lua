local fn = _gn(0x282D2CAA)
function Global.NetworkGetFindResult(Unk925, Unk926)
	return _in2(fn, Unk925, Unk926)
end

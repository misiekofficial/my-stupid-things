local fn = _gn(0x295C4C52)
function Global.FreezeCarPosition(vehicle, frozen)
	return _in2(fn, vehicle, frozen)
end

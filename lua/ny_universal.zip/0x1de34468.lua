local fn = _gn(0x45D71590)
function Global.SetObjectLights(obj, lights)
	return _in2(fn, obj, lights)
end

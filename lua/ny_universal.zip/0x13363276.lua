local fn = _gn(0x2A2959DA)
function Global.TaskGoToCoordWhileAiming(ped, Unk241, Unk242, Unk243, Unk244, Unk245, Unk246, Unk247, Unk248, Unk249, Unk250, Unk251)
	return _in2(fn, ped, Unk241, Unk242, Unk243, Unk244, Unk245, Unk246, Unk247, Unk248, Unk249, Unk250, Unk251)
end

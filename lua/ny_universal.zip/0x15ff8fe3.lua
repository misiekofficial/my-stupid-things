local fn = _gn(0x03D16145)
function Global.IsCarModel(vehicle, model)
	return _in2(fn, vehicle, model, _r)
end

local fn = _gn(0x7781290F)
function Global.SwitchCarSiren(car, siren)
	return _in2(fn, car, siren)
end

local fn = _gn(0x52CE5D9F)
function Global.SetCamComponentShake(cam, componentid, Unk564, time, x, y, z)
	return _in2(fn, cam, componentid, Unk564, time, x, y, z)
end

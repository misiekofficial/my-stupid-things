local fn = _gn(0x19976813)
function Global.GetIsHidef()
	return _in2(fn, _r)
end

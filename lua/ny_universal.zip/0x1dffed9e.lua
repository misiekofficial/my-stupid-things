local fn = _gn(0x78CE659D)
function Global.ResetCarWheels(car, reset)
	return _in2(fn, car, reset)
end

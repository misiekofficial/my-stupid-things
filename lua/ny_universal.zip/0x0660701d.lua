local fn = _gn(0x1CB2670D)
function Global.TaskSetCharDecisionMaker(ped, dm)
	return _in2(fn, ped, dm)
end

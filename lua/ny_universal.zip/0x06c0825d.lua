local fn = _gn(0x736027E6)
function Global.CodeWantsMobilePhoneRemovedForWeaponSwitching()
	return _in2(fn, _r)
end

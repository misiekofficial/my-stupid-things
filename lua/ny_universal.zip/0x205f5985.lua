local fn = _gn(0x191E2F12)
function Global.LocateCharOnFootChar_2d(ped, pednext, x, y, flag)
	return _in2(fn, ped, pednext, x, y, flag, _r)
end

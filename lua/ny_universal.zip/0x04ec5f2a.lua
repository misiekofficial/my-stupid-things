local fn = _gn(0x57895F38)
function Global.HasObjectBeenPhotographed(obj)
	return _in2(fn, obj, _r)
end

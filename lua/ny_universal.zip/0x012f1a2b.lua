local fn = _gn(0x0896249A)
function Global.GetCarSirenHealth(car)
	return _in2(fn, car, _ri)
end

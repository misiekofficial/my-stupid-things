local fn = _gn(0x69F55DCC)
function Global.DontSuppressAnyCarModels()
	return _in2(fn)
end

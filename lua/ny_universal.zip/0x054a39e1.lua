local fn = _gn(0x142E7C40)
function Global.GetTimeTilNextStation(train)
	return _in2(fn, train, _rf)
end

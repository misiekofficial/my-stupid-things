local fn = _gn(0x7E8E06F8)
function Global.IsPcUsingJoypad()
	return _in2(fn, _r)
end

local fn = _gn(0x7CAE2557)
function Global.SetDecisionMakerAttributeTargetInjuredReaction(dm, value)
	return _in2(fn, dm, value)
end

local fn = _gn(0x27607F64)
function Global.VehicleCanBeTargettedByHsMissile(car, set)
	return _in2(fn, car, set)
end

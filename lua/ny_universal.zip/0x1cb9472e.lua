local fn = _gn(0x43F5151F)
function Global.TaskWanderStandard(ped)
	return _in2(fn, ped)
end

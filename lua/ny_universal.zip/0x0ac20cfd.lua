local fn = _gn(0x1D0B131A)
function Global.IsVehWindowIntact(vehicle, window)
	return _in2(fn, vehicle, window, _r)
end

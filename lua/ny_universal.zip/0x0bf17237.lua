local fn = _gn(0x245F424F)
function Global.SetCharAnimCurrentTime(ped, AnimName0, AnimName1, time)
	return _in2(fn, ped, _ts(AnimName0), _ts(AnimName1), time)
end

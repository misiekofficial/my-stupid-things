local fn = _gn(0x24885050)
function Global.SetMobileRingType(type)
	return _in2(fn, type)
end

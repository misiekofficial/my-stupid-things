local fn = _gn(0x7EDD58E1)
function Global.AttachParachuteModelToPlayer(ped, obj)
	return _in2(fn, ped, obj)
end

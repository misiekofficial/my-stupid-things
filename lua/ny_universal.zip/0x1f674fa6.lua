local fn = _gn(0x4F9342F3)
function Global.GetCreateRandomCops()
	return _in2(fn, _r)
end

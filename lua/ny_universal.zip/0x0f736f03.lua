local fn = _gn(0x45DF1D92)
function Global.ForceInteriorLightingForPlayer(player, force)
	return _in2(fn, player, force)
end

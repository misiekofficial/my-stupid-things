local fn = _gn(0x37871A37)
function Global.SetMovieTime(time)
	return _in2(fn, time)
end

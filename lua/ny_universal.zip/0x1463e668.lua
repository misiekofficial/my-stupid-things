local fn = _gn(0x633A012B)
function Global.SetPlayerAsDamagedPlayer(playerIndex, Unk1057, Unk1058)
	return _in2(fn, playerIndex, Unk1057, Unk1058)
end

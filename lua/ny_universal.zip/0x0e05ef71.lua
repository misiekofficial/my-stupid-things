local fn = _gn(0x590A6FF4)
function Global.DoesBlipExist(blip)
	return _in2(fn, blip, _r)
end

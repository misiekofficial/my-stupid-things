local fn = _gn(0x0C4B7DD3)
function Global.SetVehicleAlpha(veh, alpha)
	return _in2(fn, veh, alpha)
end

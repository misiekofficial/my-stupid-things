local fn = _gn(0x59AA0635)
function Global.NetworkGetHostMatchProgress(host)
	return _in2(fn, host, _ri)
end

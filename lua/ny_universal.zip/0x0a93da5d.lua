local fn = _gn(0x20BC708E)
function Global.SetFollowVehicleCamSubmode(mode)
	return _in2(fn, mode)
end

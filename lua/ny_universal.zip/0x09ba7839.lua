local fn = _gn(0x740C4C84)
function Global.GetMinutesToTimeOfDay(hour, minute)
	return _in2(fn, hour, minute, _ri)
end

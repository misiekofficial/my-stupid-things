local fn = _gn(0x640E7764)
function Global.SetCharMaxMoveBlendRatio(ped, ratio)
	return _in2(fn, ped, ratio)
end

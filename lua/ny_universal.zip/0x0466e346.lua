local fn = _gn(0x7ED34379)
function Global.NetworkIsFindResultUpdated(ukn0)
	return _in2(fn, ukn0, _r)
end

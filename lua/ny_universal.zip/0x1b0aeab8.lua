local fn = _gn(0x273C2D35)
function Global.TaskPlayAnimSecondary(ped, Unk337, Unk338, Unk339, Unk340, Unk341, Unk342, Unk343, Unk344)
	return _in2(fn, ped, Unk337, Unk338, Unk339, Unk340, Unk341, Unk342, Unk343, Unk344)
end

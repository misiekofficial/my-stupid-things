local fn = _gn(0x6C63251D)
function Global.TaskGetOffBoat(ped, timeout)
	return _in2(fn, ped, timeout)
end

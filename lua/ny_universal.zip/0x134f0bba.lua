local fn = _gn(0x1F913BC7)
function Global.GetCarDeformationAtPos(vehicle, x, y, z, pDeformation)
	return _in2(fn, vehicle, x, y, z, _v)
end

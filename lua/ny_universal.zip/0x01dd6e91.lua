local fn = _gn(0x7ED82ED9)
function Global.CanCharSeeDeadChar(ped, pednext)
	return _in2(fn, ped, pednext, _r)
end

local fn = _gn(0x2BBA7BF0)
function Global.UnmarkAllRoadNodesAsDontWander()
	return _in2(fn)
end

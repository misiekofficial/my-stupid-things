local fn = _gn(0x58FB0BC1)
function Global.SetCharWillCowerInsteadOfFleeing(ped, set)
	return _in2(fn, ped, set)
end

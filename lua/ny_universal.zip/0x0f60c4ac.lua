local fn = _gn(0x2C18736E)
function Global.TaskDrivePointRoute(ped, point, radius)
	return _in2(fn, ped, point, radius)
end

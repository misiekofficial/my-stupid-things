local fn = _gn(0x01C21158)
function Global.SetTrainAudioRolloff(train, rolloff)
	return _in2(fn, train, rolloff)
end

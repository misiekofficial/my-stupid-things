local fn = _gn(0x31A219FA)
function Global.ObfuscateInt(Unk941, Unk942)
	return _in2(fn, Unk941, Unk942)
end

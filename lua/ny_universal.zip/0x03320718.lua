local fn = _gn(0x7B05072C)
function Global.GetBlipInfoIdObjectIndex(blip)
	return _in2(fn, blip, _ri)
end

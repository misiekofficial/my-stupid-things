local fn = _gn(0x31D53B3D)
function Global.SetCameraAutoScriptActivation(set)
	return _in2(fn, set)
end

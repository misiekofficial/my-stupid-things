local fn = _gn(0x391B5A76)
function Global.SetCamSplineCustomSpeedGraph(speed)
	return _in2(fn, speed)
end

local fn = _gn(0x020E0318)
function Global.AddTickerToPreviousBriefWithUnderscore(Unk625, Unk626, Unk627, Unk628, Unk629, Unk630, Unk631)
	return _in2(fn, Unk625, Unk626, Unk627, Unk628, Unk629, Unk630, Unk631)
end

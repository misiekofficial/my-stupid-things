local fn = _gn(0x2E5C36C0)
function Global.SetCharCantBeDraggedOut(ped, enabled)
	return _in2(fn, ped, enabled)
end

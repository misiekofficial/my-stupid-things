local fn = _gn(0x01A05ADD)
function Global.ConvertMetresToFeetInt(metres)
	return _in2(fn, metres, _ri)
end

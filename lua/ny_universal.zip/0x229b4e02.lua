local fn = _gn(0x5873667B)
function Global.NetworkStartSessionSucceeded()
	return _in2(fn, _r)
end

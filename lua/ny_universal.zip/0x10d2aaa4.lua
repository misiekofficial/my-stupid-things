local fn = _gn(0x1DD624A0)
function Global.HasCharBeenDamagedByChar(ped, otherChar, unknownFalse)
	return _in2(fn, ped, otherChar, unknownFalse, _r)
end

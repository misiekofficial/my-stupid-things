local fn = _gn(0xc53bb6d3)
--- DOES_TIMECYCLE_MODIFIER_HAS_VAR
-- @param modifierName The name of timecycle modifier.
-- @param varName The name of timecycle variable.
-- @return Whether or not variable by name was found on the specified timecycle modifier.
function Global.DoesTimecycleModifierHasVar(modifierName, varName)
	return _in2(fn, _ts(modifierName), _ts(varName), _r)
end

local fn = _gn(0x01795753)
function Global.TaskGuardSphereDefensiveArea(ped, Unk282, Unk283, Unk284, Unk285, Unk286, Unk287, Unk288, Unk289, Unk290, Unk291)
	return _in2(fn, ped, Unk282, Unk283, Unk284, Unk285, Unk286, Unk287, Unk288, Unk289, Unk290, Unk291)
end

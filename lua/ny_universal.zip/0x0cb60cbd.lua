local fn = _gn(0x212B4014)
function Global.UnpointCam(cam)
	return _in2(fn, cam)
end

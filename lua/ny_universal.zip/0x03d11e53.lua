local fn = _gn(0x5E756B51)
function Global.GetCharInCarPassengerSeat(vehicle, seatIndex, pPed)
	return _in2(fn, vehicle, seatIndex, _ii(pPed) --[[ may be optional ]])
end

local fn = _gn(0x7D3C3C9D)
function Global.TriggerPtfxOnPedBone(name, ped, x, y, z, Unk1074, Unk1075, Unk1076, pedbone, flags)
	return _in2(fn, _ts(name), ped, x, y, z, Unk1074, Unk1075, Unk1076, pedbone, flags, _r)
end

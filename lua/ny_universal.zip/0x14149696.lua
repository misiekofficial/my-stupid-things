local fn = _gn(0x3B4F1EBA)
function Global.AddCamSplineNode(cam, camnode)
	return _in2(fn, cam, camnode)
end

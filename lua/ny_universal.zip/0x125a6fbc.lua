local fn = _gn(0x3FB14EC5)
function Global.RemovePtfxFromVehicle(veh)
	return _in2(fn, veh)
end

local fn = _gn(0x04962F82)
function Global.TaskCharSlideToCoord(ped, Unk159, Unk160, Unk161, Unk162, Unk163)
	return _in2(fn, ped, Unk159, Unk160, Unk161, Unk162, Unk163)
end

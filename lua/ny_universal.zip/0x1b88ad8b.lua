local fn = _gn(0x15101503)
function Global.BlockPeekingInCover(ped, set)
	return _in2(fn, ped, set)
end

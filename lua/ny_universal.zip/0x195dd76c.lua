local fn = _gn(0x48ED6432)
function Global.RetuneRadioToStationIndex(radioStation)
	return _in2(fn, radioStation)
end

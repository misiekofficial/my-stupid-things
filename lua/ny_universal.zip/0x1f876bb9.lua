local fn = _gn(0x5E8D08CE)
function Global.SetCharWillRemainOnBoatAfterMissionEnds(ped, set)
	return _in2(fn, ped, set)
end

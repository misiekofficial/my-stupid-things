local fn = _gn(0x005868E2)
function Global.IsCarInGarageArea(garageName, vehicle)
	return _in2(fn, _ts(garageName), vehicle, _r)
end

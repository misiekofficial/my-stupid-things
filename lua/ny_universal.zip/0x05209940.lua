local fn = _gn(0x206420A6)
function Global.GetFrameTime(time)
	return _in2(fn, _fi(time) --[[ may be optional ]])
end

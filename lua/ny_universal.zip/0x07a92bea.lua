local fn = _gn(0x4ECB2267)
function Global.IsCharInjured(ped)
	return _in2(fn, ped, _r)
end

local fn = _gn(0x266D0801)
function Global.GetKeyForCharInRoom(ped, pKey)
	return _in2(fn, ped, _ii(pKey) --[[ may be optional ]])
end

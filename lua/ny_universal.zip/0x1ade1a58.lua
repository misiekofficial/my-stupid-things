local fn = _gn(0x27C740D0)
function Global.TaskLookAtObject(ped, targetObject, duration, unknown_0)
	return _in2(fn, ped, targetObject, duration, unknown_0)
end

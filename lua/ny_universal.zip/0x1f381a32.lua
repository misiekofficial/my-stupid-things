local fn = _gn(0x18136217)
function Global.SetTimeOneDayBack()
	return _in2(fn)
end

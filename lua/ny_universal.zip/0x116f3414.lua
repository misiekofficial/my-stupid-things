local fn = _gn(0x43E42686)
function Global.SetCamActive(camera, value)
	return _in2(fn, camera, value)
end

local fn = _gn(0x7A93645C)
function Global.SetDoNotSpawnParkedCarsOnTop(pickup, set)
	return _in2(fn, pickup, set)
end

local fn = _gn(0x49FF799A)
function Global.SpecifyScriptPopulationZonePercentageCops(percentage)
	return _in2(fn, percentage)
end

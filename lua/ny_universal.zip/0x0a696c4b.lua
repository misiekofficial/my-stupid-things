local fn = _gn(0x6E4E1BEC)
function Global.IsHelpMessageBeingDisplayed()
	return _in2(fn, _r)
end

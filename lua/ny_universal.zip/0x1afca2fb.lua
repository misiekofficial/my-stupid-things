local fn = _gn(0x5BB767AD)
function Global.LocateCharAnyMeans_2d(ped, x0, y0, x1, y1, flag)
	return _in2(fn, ped, x0, y0, x1, y1, flag, _r)
end

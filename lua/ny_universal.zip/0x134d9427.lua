local fn = _gn(0x1FC96A99)
function Global.SetEnableRcDetonate(set)
	return _in2(fn, set)
end

local fn = _gn(0x6ADD40EC)
function Global.DrawSprite(texture, Unk740, Unk741, Unk742, Unk743, angle, r, g, b, a)
	return _in2(fn, texture, Unk740, Unk741, Unk742, Unk743, angle, r, g, b, a)
end

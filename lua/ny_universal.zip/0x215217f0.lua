local fn = _gn(0x352865D2)
function Global.SetObjectProofs(obj, unknown0, fallingDamage, unknown1, unknown2, unknown3)
	return _in2(fn, obj, unknown0, fallingDamage, unknown1, unknown2, unknown3)
end

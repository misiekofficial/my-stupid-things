local fn = _gn(0x0BCE3423)
function Global.IsPedAttachedToObject(ped, obj)
	return _in2(fn, ped, obj, _r)
end

local fn = _gn(0x0DDC19F4)
function Global.SetPlayerNeverGetsTired(playerIndex, value)
	return _in2(fn, playerIndex, value)
end

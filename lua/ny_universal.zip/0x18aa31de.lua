local fn = _gn(0x1B8E7EED)
function Global.IsInLanMode()
	return _in2(fn, _r)
end

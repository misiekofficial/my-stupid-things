local fn = _gn(0x5E4327D2)
function Global.DestroyAllScriptViewports()
	return _in2(fn)
end

local fn = _gn(0x7C4C63EF)
function Global.CheckNmFeedback(ped, id, Unk13)
	return _in2(fn, ped, id, Unk13, _r)
end

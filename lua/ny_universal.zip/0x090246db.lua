local fn = _gn(0x19D16ACE)
function Global.IsAnyCharShootingInArea(x0, y0, z0, x1, y1, z1, flag)
	return _in2(fn, x0, y0, z0, x1, y1, z1, flag, _r)
end

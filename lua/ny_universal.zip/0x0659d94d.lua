local fn = _gn(0x61040B08)
function Global.ActivateReplayMenu()
	return _in2(fn)
end

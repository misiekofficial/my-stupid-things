local fn = _gn(0x318F65E6)
function Global.IsReplaySystemSaving()
	return _in2(fn, _r)
end

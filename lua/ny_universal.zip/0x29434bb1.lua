local fn = _gn(0x62687944)
function Global.AddPedToCinematographyAi(Unk28, ped)
	return _in2(fn, Unk28, ped)
end

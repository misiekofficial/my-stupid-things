local fn = _gn(0x08240FB7)
function Global.SetRenderTrainAsDerailed(train, set)
	return _in2(fn, train, set)
end

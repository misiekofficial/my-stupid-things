local fn = _gn(0x3BF93ED7)
function Global.SetPedDiesWhenInjured(ped, value)
	return _in2(fn, ped, value)
end

local fn = _gn(0x7BEE5003)
function Global.GetNetworkIdFromPed(ped, netid)
	return _in2(fn, ped, _ii(netid) --[[ may be optional ]])
end

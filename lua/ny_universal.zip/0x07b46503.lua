local fn = _gn(0x4371559F)
function Global.SetClearHelpInMissionCleanup(set)
	return _in2(fn, set)
end

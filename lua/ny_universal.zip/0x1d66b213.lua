local fn = _gn(0x711214F3)
function Global.DisablePlayerLockon(playerIndex, disabled)
	return _in2(fn, playerIndex, disabled)
end

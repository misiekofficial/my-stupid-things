local fn = _gn(0x03A01F39)
function Global.PrintWith_6Numbers(gxtentry, Unk688, Unk689, Unk690, Unk691, Unk692, Unk693, time, flag)
	return _in2(fn, _ts(gxtentry), Unk688, Unk689, Unk690, Unk691, Unk692, Unk693, time, flag)
end

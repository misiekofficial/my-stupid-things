local fn = _gn(0x59EE3A11)
function Global.IsScreenFadedOut()
	return _in2(fn, _r)
end

local fn = _gn(0x36537CE1)
function Global.TaskFollowNavMeshAndSlideToCoord(ped, x, y, z, Unk215, Unk216, Unk217, angle)
	return _in2(fn, ped, x, y, z, Unk215, Unk216, Unk217, angle)
end

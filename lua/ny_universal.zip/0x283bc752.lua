local fn = _gn(0x42690F6B)
function Global.SetSniperZoomFactor(factor)
	return _in2(fn, factor)
end

local fn = _gn(0x64655F10)
function Global.IsMouseUsingVerticalInversion()
	return _in2(fn, _r)
end

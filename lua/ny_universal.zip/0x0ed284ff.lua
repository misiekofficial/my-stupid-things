local fn = _gn(0x4BB9178A)
function Global.PlayAudioEventFromObject(EventName, obj)
	return _in2(fn, _ts(EventName), obj)
end

local fn = _gn(0x24B42ED2)
function Global.SetVehHazardlights(vehicle, on)
	return _in2(fn, vehicle, on)
end

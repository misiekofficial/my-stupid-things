local fn = _gn(0x6D0E1BCE)
function Global.LocateCharAnyMeansObject_3d(ped, obj, x, y, z, flag)
	return _in2(fn, ped, obj, x, y, z, flag, _r)
end

local fn = _gn(0x09C95A65)
function Global.GetCarRoll(vehicle, pValue)
	return _in2(fn, vehicle, _fi(pValue) --[[ may be optional ]])
end

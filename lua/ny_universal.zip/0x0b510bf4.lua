local fn = _gn(0x0FFD1A92)
function Global.SwitchRandomTrains(on)
	return _in2(fn, on)
end

local fn = _gn(0x24CC682B)
function Global.Tan(value)
	return _in2(fn, value, _rf)
end

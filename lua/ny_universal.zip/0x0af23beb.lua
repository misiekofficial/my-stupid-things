local fn = _gn(0x4E4C2F92)
function Global.SetMsgForLoadingScreen(label)
	return _in2(fn, _ts(label))
end

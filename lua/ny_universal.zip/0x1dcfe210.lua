local fn = _gn(0x5AA025C2)
function Global.GetNumCarColours(vehicle, pNumColours)
	return _in2(fn, vehicle, _ii(pNumColours) --[[ may be optional ]])
end

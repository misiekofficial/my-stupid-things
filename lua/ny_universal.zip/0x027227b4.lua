local fn = _gn(0x1A081F78)
function Global.SetGunshotSenseRangeForRiot2(range)
	return _in2(fn, range)
end

local fn = _gn(0x65752C65)
function Global.PlaySoundFromPosition(sound_id, name, x, y, z)
	return _in2(fn, sound_id, _ts(name), x, y, z)
end

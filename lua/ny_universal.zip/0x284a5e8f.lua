local fn = _gn(0x60320FEB)
function Global.HideHudAndRadarThisFrame()
	return _in2(fn)
end

local fn = _gn(0x689D5EEE)
function Global.SetPlayerIconColour(colour)
	return _in2(fn, colour)
end

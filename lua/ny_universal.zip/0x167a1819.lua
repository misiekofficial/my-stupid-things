local fn = _gn(0x3E8443E0)
function Global.WasPedSkeletonUpdated(ped)
	return _in2(fn, ped, _r)
end

local fn = _gn(0x43EF56EE)
function Global.SetSuppressHeadlightSwitch(set)
	return _in2(fn, set)
end

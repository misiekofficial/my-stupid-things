local fn = _gn(0x6CE00370)
function Global.SetNmMessageFloat(id, value)
	return _in2(fn, id, value)
end

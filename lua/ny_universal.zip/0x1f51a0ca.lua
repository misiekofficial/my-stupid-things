local fn = _gn(0x124D4571)
function Global.GetPedModelFromIndex(index)
	return _in2(fn, index, _ri)
end

local fn = _gn(0x40035D5D)
function Global.SetInSpectatorMode(spectate)
	return _in2(fn, spectate)
end

local fn = _gn(0x126C0B99)
function Global.GetTimeSincePlayerHitBuilding(playerIndex)
	return _in2(fn, playerIndex, _ri)
end

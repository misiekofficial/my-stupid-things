local fn = _gn(0x5EA253A5)
function Global.FailKillFrenzy()
	return _in2(fn)
end

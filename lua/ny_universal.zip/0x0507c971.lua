local fn = _gn(0x0DDD70AE)
function Global.CreateMissionTrain(unknown1, x, y, z, unknown2, pTrain)
	return _in2(fn, unknown1, x, y, z, unknown2, _ii(pTrain) --[[ may be optional ]])
end

local fn = _gn(0x720673D9)
function Global.SetVehicleIsConsideredByPlayer(veh, set)
	return _in2(fn, veh, set)
end

local fn = _gn(0x7939764F)
function Global.StartMobilePhoneCall(callfrom, callfromvoice, callto, calltovoice, flag0, flag1)
	return _in2(fn, callfrom, _ts(callfromvoice), callto, _ts(calltovoice), flag0, flag1)
end

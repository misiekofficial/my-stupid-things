local fn = _gn(0x20BB5507)
function Global.SetPedHeliPilotRespectsMinimummHeight(ped, set)
	return _in2(fn, ped, set)
end

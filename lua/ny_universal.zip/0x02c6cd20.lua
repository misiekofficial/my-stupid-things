local fn = _gn(0x2F444F95)
function Global.SetDecisionMakerAttributeSightRange(dm, value)
	return _in2(fn, dm, value)
end

local fn = _gn(0x2D1A5F8C)
function Global.GetRandomCarNodeIncludeSwitchedOffNodes(x, y, z, radius, flag0, flag1, flag2)
	return _in2(fn, x, y, z, radius, flag0, flag1, flag2, _f, _f, _f, _f, _r)
end

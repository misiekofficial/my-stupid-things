local fn = _gn(0x36DF37DB)
function Global.AddSpawnBlockingArea(Unk900, Unk901, Unk902, Unk903)
	return _in2(fn, Unk900, Unk901, Unk902, Unk903)
end

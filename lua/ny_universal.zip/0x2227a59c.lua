local fn = _gn(0x2F2405D1)
function Global.GetClosestCarNodeFavourDirection(Unk802, x, y, z)
	return _in2(fn, Unk802, x, y, z, _f, _f, _f, _f, _r)
end

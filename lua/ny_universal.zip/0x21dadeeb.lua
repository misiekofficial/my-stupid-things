local fn = _gn(0x4B907716)
function Global.NetworkHaveOnlinePrivileges()
	return _in2(fn, _r)
end

local fn = _gn(0x612062DB)
function Global.SetRichPresenceTemplatemp3(Unk982, Unk983)
	return _in2(fn, Unk982, Unk983)
end

local fn = _gn(0x5C422066)
function Global.GetCharReadyToBeStunned(ped)
	return _in2(fn, ped, _r)
end

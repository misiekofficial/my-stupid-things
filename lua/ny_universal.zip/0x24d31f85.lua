local fn = _gn(0x30BA2716)
function Global.TaskPlayAnimWithAdvancedFlags(ped, Unk377, Unk378, Unk379, Unk380, Unk381, Unk382, Unk383, Unk384, Unk385, Unk386, Unk387)
	return _in2(fn, ped, Unk377, Unk378, Unk379, Unk380, Unk381, Unk382, Unk383, Unk384, Unk385, Unk386, Unk387)
end

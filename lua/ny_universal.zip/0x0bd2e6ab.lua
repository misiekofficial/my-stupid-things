local fn = _gn(0x5FAD09CA)
function Global.GetHeightOfVehicle(vehicle, x, y, z, unknownTrue1, unknownTrue2)
	return _in2(fn, vehicle, x, y, z, unknownTrue1, unknownTrue2, _rf)
end

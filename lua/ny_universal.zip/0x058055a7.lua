local fn = _gn(0x7B8D68E7)
function Global.SetRoute(blip, value)
	return _in2(fn, blip, value)
end

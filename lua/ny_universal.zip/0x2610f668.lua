local fn = _gn(0x91310870)
--- The backing function for TriggerEvent.
function Global.TriggerEventInternal(eventName, eventPayload, payloadLength)
	return _in2(fn, _ts(eventName), _ts(eventPayload), payloadLength)
end

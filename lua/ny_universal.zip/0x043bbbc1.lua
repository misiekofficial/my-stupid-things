local fn = _gn(0x08181609)
function Global.NetworkStoreSinglePlayerGame()
	return _in2(fn, _ri)
end

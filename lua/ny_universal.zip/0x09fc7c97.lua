local fn = _gn(0x32D3165D)
function Global.ForceInitialPlayerStation(stationName)
	return _in2(fn, _ts(stationName))
end

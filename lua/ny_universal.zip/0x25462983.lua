local fn = _gn(0x69A52C96)
function Global.GetCharWillCowerInsteadOfFleeing(ped)
	return _in2(fn, ped, _r)
end

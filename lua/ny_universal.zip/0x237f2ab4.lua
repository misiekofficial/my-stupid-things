local fn = _gn(0x4FB069ED)
function Global.SetHelpMessageBoxSize(Unk773)
	return _in2(fn, Unk773)
end

local fn = _gn(0x10436A86)
function Global.SetStatFrontendDisplayType(stat, type)
	return _in2(fn, stat, type)
end

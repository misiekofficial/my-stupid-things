local fn = _gn(0x475267B0)
function Global.SetTrainForcedToSlowDown(train, set)
	return _in2(fn, train, set)
end

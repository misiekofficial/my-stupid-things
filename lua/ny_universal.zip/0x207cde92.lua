local fn = _gn(0x07EE2A45)
function Global.SetRoomForViewportByKey(viewportid, roomkey)
	return _in2(fn, viewportid, roomkey)
end

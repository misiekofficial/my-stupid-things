local fn = _gn(0x73245AB3)
function Global.GetInteriorHeading(interior, pHeading)
	return _in2(fn, interior, _fi(pHeading) --[[ may be optional ]])
end

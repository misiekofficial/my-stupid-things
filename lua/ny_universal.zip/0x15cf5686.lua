local fn = _gn(0x68966670)
function Global.GetOffsetFromInteriorInWorldCoords(interior, x, y, z, pOffset)
	return _in2(fn, interior, x, y, z, _fi(pOffset) --[[ may be optional ]])
end

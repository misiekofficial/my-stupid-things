local fn = _gn(0x6EA72622)
function Global.IsCarWaitingForWorldCollision(vehicle)
	return _in2(fn, vehicle, _r)
end

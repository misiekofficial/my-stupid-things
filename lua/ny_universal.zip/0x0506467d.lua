local fn = _gn(0x084F7B9F)
function Global.WasPedKilledByHeadshot(ped)
	return _in2(fn, ped, _r)
end

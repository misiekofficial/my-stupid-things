local fn = _gn(0x03EE5F1C)
function Global.PlayCarAnim(car, animname0, animname1, Unk50, flag0, flag1)
	return _in2(fn, car, _ts(animname0), _ts(animname1), Unk50, flag0, flag1, _r)
end

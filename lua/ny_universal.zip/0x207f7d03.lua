local fn = _gn(0x5996315E)
function Global.ConvertIntToPlayerindex(playerId)
	return _in2(fn, playerId, _ri)
end

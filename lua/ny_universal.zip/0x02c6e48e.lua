local fn = _gn(0x73BD71A9)
function Global.GetPlayerRgbColour(Player)
	return _in2(fn, Player, _i, _i, _i)
end

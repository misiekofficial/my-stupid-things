local fn = _gn(0x0E3B49BF)
function Global.DeleteChar(pPed)
	return _in2(fn, _ii(pPed) --[[ may be optional ]])
end

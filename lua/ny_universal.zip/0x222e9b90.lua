local fn = _gn(0x7B3F0058)
function Global.GetCharExtractedVelocity(ped, Unk5)
	return _in2(fn, ped, Unk5, _f, _f, _f)
end

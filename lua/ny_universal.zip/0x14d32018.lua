local fn = _gn(0x2232704D)
function Global.IncreasePlayerMaxArmour(player, armour)
	return _in2(fn, player, armour)
end

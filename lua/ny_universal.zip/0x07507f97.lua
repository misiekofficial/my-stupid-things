local fn = _gn(0x3F6B5975)
function Global.SetStartFromFilterMenu(Unk996)
	return _in2(fn, Unk996)
end

local fn = _gn(0x32517AE2)
function Global.TaskFleeCharAnyMeans(ped, Unk207, Unk208, Unk209, Unk210, Unk211, Unk212, Unk213)
	return _in2(fn, ped, Unk207, Unk208, Unk209, Unk210, Unk211, Unk212, Unk213)
end

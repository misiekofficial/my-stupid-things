local fn = _gn(0x0D8407E9)
function Global.StartPtfxOnObj(name, obj, x, y, z, yaw, pitch, roll, scale)
	return _in2(fn, _ts(name), obj, x, y, z, yaw, pitch, roll, scale, _ri)
end

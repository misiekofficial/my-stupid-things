local fn = _gn(0x3C2A3334)
function Global.SetCharAnimSpeed(ped, AnimName0, AnimName1, speed)
	return _in2(fn, ped, _ts(AnimName0), _ts(AnimName1), speed)
end

local fn = _gn(0x4DB55DF5)
function Global.TaskSeekCoverToObject(ped, Unk417, Unk418, Unk419, Unk420, Unk421)
	return _in2(fn, ped, Unk417, Unk418, Unk419, Unk420, Unk421)
end

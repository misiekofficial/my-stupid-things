local fn = _gn(0x046A4720)
function Global.IsCharArmed(ped, slot)
	return _in2(fn, ped, slot, _r)
end

local fn = _gn(0x2AE87B02)
function Global.SetCamName(cam, camname)
	return _in2(fn, cam, _ts(camname))
end

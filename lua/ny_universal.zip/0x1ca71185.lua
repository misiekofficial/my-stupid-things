local fn = _gn(0x2CC356D0)
function Global.PrintWith_5Numbers(gxtentry, Unk678, Unk679, Unk680, Unk681, Unk682, time, flag)
	return _in2(fn, _ts(gxtentry), Unk678, Unk679, Unk680, Unk681, Unk682, time, flag)
end

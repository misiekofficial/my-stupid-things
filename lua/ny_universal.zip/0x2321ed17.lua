local fn = _gn(0x7FF21081)
function Global.IsButtonPressed(padIndex, button)
	return _in2(fn, padIndex, button, _r)
end

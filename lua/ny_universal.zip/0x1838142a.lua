local fn = _gn(0x662235A5)
function Global.SetCharAllowedToRunOnBoats(ped, set)
	return _in2(fn, ped, set)
end

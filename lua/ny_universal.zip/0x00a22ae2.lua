local fn = _gn(0x001954A2)
function Global.RegisterPlayerRespawnCoords(playerIndex, x, y, z)
	return _in2(fn, playerIndex, x, y, z)
end

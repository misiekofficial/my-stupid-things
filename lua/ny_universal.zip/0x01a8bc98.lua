local fn = _gn(0x71C30148)
function Global.AllocateScriptToObject(ScriptName, model, Unk602, radius, UnkTime)
	return _in2(fn, _ts(ScriptName), model, Unk602, radius, UnkTime)
end

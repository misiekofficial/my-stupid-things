local fn = _gn(0x6A9E5CE5)
function Global.GetBlipInfoIdType(blip)
	return _in2(fn, blip, _ri)
end

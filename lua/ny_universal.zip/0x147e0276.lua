local fn = _gn(0x7DA4736D)
function Global.IsWantedLevelGreater(playerIndex, level)
	return _in2(fn, playerIndex, level, _r)
end

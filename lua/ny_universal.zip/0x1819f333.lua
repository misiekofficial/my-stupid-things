local fn = _gn(0x515C3218)
function Global.TaskSitDownOnObject(ped, Unk444, Unk445, Unk446, Unk447, Unk448, Unk449, Unk450, Unk451, Unk452)
	return _in2(fn, ped, Unk444, Unk445, Unk446, Unk447, Unk448, Unk449, Unk450, Unk451, Unk452)
end

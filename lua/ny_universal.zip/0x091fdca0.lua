local fn = _gn(0x5384065B)
function Global.SetFadeInAfterLoad(set)
	return _in2(fn, set)
end

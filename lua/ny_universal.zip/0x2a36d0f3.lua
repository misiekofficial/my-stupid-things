local fn = _gn(0x07F35BFE)
function Global.PlaystatsIntInt(Unk792, Unk793, Unk794)
	return _in2(fn, Unk792, Unk793, Unk794)
end

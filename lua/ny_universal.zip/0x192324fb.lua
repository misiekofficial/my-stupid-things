local fn = _gn(0x2C297C5D)
function Global.Sqrt(value)
	return _in2(fn, value, _rf)
end

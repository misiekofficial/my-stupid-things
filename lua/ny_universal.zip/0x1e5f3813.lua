local fn = _gn(0x07BC4223)
function Global.SetUsesCollisionOfClosestObjectOfType(x, y, z, radius, type_or_model, flag)
	return _in2(fn, x, y, z, radius, type_or_model, flag)
end

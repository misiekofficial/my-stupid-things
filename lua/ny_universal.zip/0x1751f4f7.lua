local fn = _gn(0x106811E4)
function Global.HasObjectCollidedWithAnything(obj)
	return _in2(fn, obj, _r)
end

local fn = _gn(0x7330132C)
function Global.RemoveProjtexFromObject(obj)
	return _in2(fn, obj)
end

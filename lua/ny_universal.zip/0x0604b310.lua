local fn = _gn(0x16DD2D00)
function Global.GetCarSpeed(vehicle, pValue)
	return _in2(fn, vehicle, _fi(pValue) --[[ may be optional ]])
end

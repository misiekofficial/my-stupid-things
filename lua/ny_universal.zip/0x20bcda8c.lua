local fn = _gn(0x0F4B0239)
function Global.GetClosestChar(x, y, z, radius, unknown1, unknown2, pPed)
	return _in2(fn, x, y, z, radius, unknown1, unknown2, _ii(pPed) --[[ may be optional ]], _r)
end

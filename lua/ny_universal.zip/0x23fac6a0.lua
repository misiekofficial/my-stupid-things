local fn = _gn(0x6CF44DD6)
function Global.SetCurrentCharWeapon(ped, w, unknownTrue)
	return _in2(fn, ped, w, unknownTrue)
end

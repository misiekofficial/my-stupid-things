local fn = _gn(0x5D786EEE)
function Global.ExtinguishCharFire(ped)
	return _in2(fn, ped)
end

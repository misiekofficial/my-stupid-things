local fn = _gn(0x69F11716)
function Global.GetPedFromNetworkId(netid, ped)
	return _in2(fn, netid, _ii(ped) --[[ may be optional ]])
end

local fn = _gn(0x50DC54B3)
function Global.IsSniperInverted()
	return _in2(fn, _r)
end

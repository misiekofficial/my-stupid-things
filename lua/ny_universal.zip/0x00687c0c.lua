local fn = _gn(0x67A42263)
function Global.DoesVehicleExist(vehicle)
	return _in2(fn, vehicle, _r)
end

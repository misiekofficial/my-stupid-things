local fn = _gn(0x60F720F6)
function Global.GetVehicleTypeOfModel(model)
	return _in2(fn, model, _ri)
end

local fn = _gn(0x18F477E1)
function Global.GetPedType(ped, pType)
	return _in2(fn, ped, _ii(pType) --[[ may be optional ]])
end

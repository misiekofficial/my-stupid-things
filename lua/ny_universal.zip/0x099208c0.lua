local fn = _gn(0x189E32C9)
function Global.CopySharedCharDecisionMaker(type, pDM)
	return _in2(fn, type, _ii(pDM) --[[ may be optional ]])
end

local fn = _gn(0x764236CE)
function Global.SecuromSpotCheck4()
	return _in2(fn, _r)
end

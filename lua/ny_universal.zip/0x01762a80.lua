local fn = _gn(0x5E564CFF)
function Global.AttachCamToVehicle(cam, veh)
	return _in2(fn, cam, veh)
end

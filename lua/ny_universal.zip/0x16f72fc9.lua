local fn = _gn(0x2E5E1600)
function Global.IsThisMachineTheServer()
	return _in2(fn, _r)
end

local fn = _gn(0x12ED0BC9)
function Global.RequestCollisionAtPosn(x, y, z)
	return _in2(fn, x, y, z)
end

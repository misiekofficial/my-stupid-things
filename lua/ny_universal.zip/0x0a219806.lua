local fn = _gn(0x3AB06137)
function Global.IsCharTouchingObject(ped, obj)
	return _in2(fn, ped, obj, _r)
end

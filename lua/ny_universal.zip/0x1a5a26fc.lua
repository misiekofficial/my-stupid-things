local fn = _gn(0x26E66DF3)
function Global.GetObjectAnimTotalTime(obj, animname0, animname1, time)
	return _in2(fn, obj, _ts(animname0), _ts(animname1), _fi(time) --[[ may be optional ]])
end

local fn = _gn(0x31E25160)
function Global.SetPlayerControlAdvanced(playerIndex, unknown1, unknown2, unknown3)
	return _in2(fn, playerIndex, unknown1, unknown2, unknown3)
end

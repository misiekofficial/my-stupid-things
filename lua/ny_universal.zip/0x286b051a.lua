local fn = _gn(0x309C265B)
function Global.IsCharSittingInCar(ped, vehicle)
	return _in2(fn, ped, vehicle, _r)
end

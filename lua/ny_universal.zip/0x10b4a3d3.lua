local fn = _gn(0x616F492C)
function Global.Printstring(value)
	return _in2(fn, _ts(value))
end

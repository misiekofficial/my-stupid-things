local fn = _gn(0x0F0269B5)
function Global.GetIsWidescreen()
	return _in2(fn, _r)
end

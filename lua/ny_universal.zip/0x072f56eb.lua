local fn = _gn(0x32A3647C)
function Global.GetTextInputActive()
	return _in2(fn, _r)
end

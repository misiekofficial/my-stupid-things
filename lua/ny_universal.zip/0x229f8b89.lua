local fn = _gn(0x524F7543)
function Global.NetworkGetMaxSlots()
	return _in2(fn, _ri)
end

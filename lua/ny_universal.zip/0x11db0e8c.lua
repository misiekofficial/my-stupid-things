local fn = _gn(0x7EA03481)
function Global.IsCarInArea_2d(vehicle, x1, y1, x2, y2, unknownFalse)
	return _in2(fn, vehicle, x1, y1, x2, y2, unknownFalse, _r)
end

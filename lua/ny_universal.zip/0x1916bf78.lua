local fn = _gn(0x67D908DF)
function Global.SwitchPedPathsOn(x0, y0, z0, x1, y1, z1)
	return _in2(fn, x0, y0, z0, x1, y1, z1)
end

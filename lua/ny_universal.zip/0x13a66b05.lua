local fn = _gn(0x6C7566F3)
function Global.MpGetAmountOfAnchorPoints(ped, id)
	return _in2(fn, ped, id, _ri)
end

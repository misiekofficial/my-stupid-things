local fn = _gn(0x391E4575)
function Global.NetworkHostGamePending()
	return _in2(fn, _r)
end

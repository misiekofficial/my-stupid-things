local fn = _gn(0x417F6EBD)
function Global.TaskUseMobilePhone(ped, use)
	return _in2(fn, ped, use)
end

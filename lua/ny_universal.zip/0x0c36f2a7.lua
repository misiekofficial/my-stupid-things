local fn = _gn(0x56A70F57)
function Global.ForcePedPinnedDown(ped, force, timerMaybe)
	return _in2(fn, ped, force, timerMaybe)
end

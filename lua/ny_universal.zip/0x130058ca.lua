local fn = _gn(0x52632919)
function Global.DisplayHud(display)
	return _in2(fn, display)
end

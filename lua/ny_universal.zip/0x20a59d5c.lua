local fn = _gn(0x418D0889)
function Global.SetNoResprays(set)
	return _in2(fn, set)
end

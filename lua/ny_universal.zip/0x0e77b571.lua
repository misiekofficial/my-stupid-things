local fn = _gn(0x709154FC)
function Global.GiveDelayedWeaponToChar(ped, weapon, delaytime, flag)
	return _in2(fn, ped, weapon, delaytime, flag)
end

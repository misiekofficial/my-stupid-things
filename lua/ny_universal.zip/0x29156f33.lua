local fn = _gn(0x50424095)
function Global.GetNetworkIdFromObject(obj, netid)
	return _in2(fn, obj, _ii(netid) --[[ may be optional ]])
end

local fn = _gn(0x5AF23F31)
function Global.SetCurrentMovie(filename)
	return _in2(fn, _ts(filename))
end

local fn = _gn(0x1D8800E3)
function Global.ChangeBlipColour(blip, colour)
	return _in2(fn, blip, colour)
end

local fn = _gn(0x2E9E149D)
function Global.SetCarLivery(car, livery)
	return _in2(fn, car, livery)
end

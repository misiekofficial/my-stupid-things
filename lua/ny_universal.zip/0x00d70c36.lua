local fn = _gn(0x362B5D1B)
function Global.AllowLockonToFriendlyPlayers(player, allow)
	return _in2(fn, player, allow)
end

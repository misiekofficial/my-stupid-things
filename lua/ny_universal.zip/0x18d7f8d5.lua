local fn = _gn(0x52DA430A)
function Global.SetCharAnimPlayingFlag(ped, AnimName0, AnimName1, flag)
	return _in2(fn, ped, _ts(AnimName0), _ts(AnimName1), flag, _r)
end

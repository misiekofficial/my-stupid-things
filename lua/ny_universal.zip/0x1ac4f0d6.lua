local fn = _gn(0x5BE115FD)
function Global.AddPointToGpsRaceTrack(point)
	return _in2(fn, _v)
end

local fn = _gn(0x67DB4150)
function Global.GetGroupFormationSpacing(group, spacing)
	return _in2(fn, group, _fi(spacing) --[[ may be optional ]])
end

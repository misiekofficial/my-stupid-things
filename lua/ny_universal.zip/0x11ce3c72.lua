local fn = _gn(0x27045521)
function Global.GetClosestStealableObject(x, y, z, radius, obj)
	return _in2(fn, x, y, z, radius, _ii(obj) --[[ may be optional ]])
end

local fn = _gn(0x58F814C4)
function Global.TaskOpenPassengerDoor(ped, vehicle, seatIndex, unknown0)
	return _in2(fn, ped, vehicle, seatIndex, unknown0)
end

local fn = _gn(0x4D077DBA)
function Global.IsStreamingThisAdditionalText(str0, Unk597, Unk598)
	return _in2(fn, _ts(str0), Unk597, Unk598, _r)
end

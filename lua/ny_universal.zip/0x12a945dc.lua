local fn = _gn(0x03FB6DED)
function Global.IsCharTouchingChar(ped, otherChar)
	return _in2(fn, ped, otherChar, _r)
end

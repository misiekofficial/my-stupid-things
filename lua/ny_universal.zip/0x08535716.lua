local fn = _gn(0x44C27071)
function Global.RemoveTxd(txd)
	return _in2(fn, txd)
end

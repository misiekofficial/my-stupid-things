local fn = _gn(0x0AB9317B)
function Global.ClearCharLastDamageEntity(ped)
	return _in2(fn, ped)
end

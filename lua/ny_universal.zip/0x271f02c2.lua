local fn = _gn(0x0A3D60CE)
function Global.GetCharModel(ped, pModel)
	return _in2(fn, ped, _ii(pModel) --[[ may be optional ]])
end

local fn = _gn(0x14790F9F)
function Global.SetPoliceRadarBlips(set)
	return _in2(fn, set)
end

local fn = _gn(0x763274B7)
function Global.PlaySoundFromVehicle(SoundId, SoundName, veh)
	return _in2(fn, SoundId, _ts(SoundName), veh)
end

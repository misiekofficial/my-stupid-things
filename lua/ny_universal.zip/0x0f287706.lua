local fn = _gn(0x4859273F)
function Global.IsPedLookingAtCar(ped, car)
	return _in2(fn, ped, car, _r)
end

local fn = _gn(0x5EA84115)
function Global.SetCharNeverTargetted(ped, set)
	return _in2(fn, ped, set)
end

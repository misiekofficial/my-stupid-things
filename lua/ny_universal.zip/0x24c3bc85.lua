local fn = _gn(0x0437222B)
function Global.LocateCharAnyMeans_3d(ped, x0, y0, z0, x1, y1, z1, flag)
	return _in2(fn, ped, x0, y0, z0, x1, y1, z1, flag, _r)
end

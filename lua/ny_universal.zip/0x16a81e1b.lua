local fn = _gn(0x42DB145F)
function Global.ClearCharRelationship(ped, reltype, relgroup)
	return _in2(fn, ped, reltype, relgroup)
end

local fn = _gn(0x232642DE)
function Global.DrawWindow(Unk764, Unk765, Unk766, Unk767, str, alpha)
	return _in2(fn, Unk764, Unk765, Unk766, Unk767, _ts(str), alpha)
end

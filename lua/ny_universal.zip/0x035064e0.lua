local fn = _gn(0x5FDF1493)
function Global.SetCollideWithPeds(set)
	return _in2(fn, set)
end

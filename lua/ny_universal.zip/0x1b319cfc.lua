local fn = _gn(0x4B7C3AEC)
function Global.DisplayTextWithTwoLiteralStrings(x, y, gxtName, literalStr1, literalStr2)
	return _in2(fn, x, y, _ts(gxtName), _ts(literalStr1), _ts(literalStr2))
end

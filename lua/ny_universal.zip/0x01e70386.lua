local fn = _gn(0x6B9C7392)
function Global.SetOnlineScore(Unk1059, Unk1060)
	return _in2(fn, Unk1059, Unk1060)
end

local fn = _gn(0x176C2DB5)
function Global.HasControlOfNetworkId(netid)
	return _in2(fn, netid, _r)
end

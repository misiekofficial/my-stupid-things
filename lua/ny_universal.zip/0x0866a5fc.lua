local fn = _gn(0x17265607)
function Global.GetPlayerMaxArmour(playerIndex, pMaxArmour)
	return _in2(fn, playerIndex, _ii(pMaxArmour) --[[ may be optional ]])
end

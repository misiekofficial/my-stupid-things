local fn = _gn(0x7858750E)
function Global.StartStreamingRequestList(name)
	return _in2(fn, _ts(name))
end

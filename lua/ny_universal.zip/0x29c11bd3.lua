local fn = _gn(0x3B5D0F27)
function Global.GetVehicleComponentInfo(veh, component_id, flag)
	return _in2(fn, veh, component_id, _v, _v, _i, flag, _r)
end

local fn = _gn(0x453F587D)
function Global.HasCarRecordingBeenLoaded(CarRec)
	return _in2(fn, CarRec, _r)
end

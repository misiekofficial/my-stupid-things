local fn = _gn(0x4A1D15D5)
function Global.SetUseHighdof(set)
	return _in2(fn, set)
end

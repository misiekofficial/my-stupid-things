local fn = _gn(0x60E335FA)
function Global.SetHasBeenOwnedForCarGenerator(CarGen, set)
	return _in2(fn, CarGen, set)
end

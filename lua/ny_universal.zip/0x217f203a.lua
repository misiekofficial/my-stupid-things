local fn = _gn(0x08AB2787)
function Global.SetAllowDummyConversions(set)
	return _in2(fn, set)
end

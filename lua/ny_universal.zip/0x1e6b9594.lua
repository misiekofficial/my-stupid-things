local fn = _gn(0x6AC52840)
function Global.GetCurrentStackSize()
	return _in2(fn, _ri)
end

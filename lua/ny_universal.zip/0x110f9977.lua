local fn = _gn(0x2B64229C)
function Global.ImproveLowPerformanceMissionPerFrameFlag()
	return _in2(fn)
end

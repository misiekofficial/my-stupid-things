local fn = _gn(0x38293796)
function Global.MakePlayerFireProof(player, proof)
	return _in2(fn, player, proof)
end

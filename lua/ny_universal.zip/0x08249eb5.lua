local fn = _gn(0x03622640)
function Global.RemoveAllPickupsOfType(type)
	return _in2(fn, type)
end

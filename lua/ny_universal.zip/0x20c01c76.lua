local fn = _gn(0x42D250A7)
function Global.DoScreenFadeOutUnhacked(timeMS)
	return _in2(fn, timeMS)
end

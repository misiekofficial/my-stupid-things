local fn = _gn(0x7EAC3387)
function Global.IsCamPropagating(camera)
	return _in2(fn, camera, _r)
end

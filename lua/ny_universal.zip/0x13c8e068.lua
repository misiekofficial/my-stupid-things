local fn = _gn(0x6FFE0DFD)
function Global.RequestScript(scriptName)
	return _in2(fn, _ts(scriptName))
end

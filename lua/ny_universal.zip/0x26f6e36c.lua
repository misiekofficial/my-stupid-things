local fn = _gn(0x07533EC9)
function Global.GetHudColour(type)
	return _in2(fn, type, _i, _i, _i, _i)
end

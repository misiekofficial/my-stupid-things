local fn = _gn(0x51F54148)
function Global.SetDecisionMakerAttributeCanChangeTarget(dm, value)
	return _in2(fn, dm, value)
end

local fn = _gn(0x25AC586E)
function Global.SetDitchPoliceModels(set)
	return _in2(fn, set)
end

local fn = _gn(0x06C71148)
function Global.SetWidescreenBorders(set)
	return _in2(fn, set)
end

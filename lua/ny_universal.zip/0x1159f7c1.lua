local fn = _gn(0x077B17B5)
function Global.StartKillFrenzy(gxtname, Unk512, Unk513, Unk514, Unk515, Unk516, Unk517, Unk518, Unk519)
	return _in2(fn, _ts(gxtname), Unk512, Unk513, Unk514, Unk515, Unk516, Unk517, Unk518, Unk519)
end

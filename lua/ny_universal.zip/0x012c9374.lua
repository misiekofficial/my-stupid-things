local fn = _gn(0xa7dd3209)
--- SET_SNAKEOIL_FOR_ENTRY
function Global.SetSnakeoilForEntry(name, path, data)
	return _in2(fn, _ts(name), _ts(path), _ts(data))
end

local fn = _gn(0x49261BA6)
function Global.Floor(value)
	return _in2(fn, value, _ri)
end

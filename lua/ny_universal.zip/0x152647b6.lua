local fn = _gn(0x7DF26C8C)
function Global.GetCutsceneTime()
	return _in2(fn, _ri)
end

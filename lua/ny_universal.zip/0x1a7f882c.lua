local fn = _gn(0x059E3BEB)
function Global.GetBlipInfoIdPickupIndex(blip)
	return _in2(fn, blip, _ri)
end

local fn = _gn(0x3F236954)
function Global.ClearOnscreenCounter(counterid)
	return _in2(fn, counterid)
end

local fn = _gn(0x116D009A)
function Global.CompareTwoDates(date0_0, date0_1, date1_0, date1_1)
	return _in2(fn, date0_0, date0_1, date1_0, date1_1, _ri)
end

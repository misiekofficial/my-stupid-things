local fn = _gn(0x446E6515)
function Global.AddToPreviousBrief(gxtentry)
	return _in2(fn, _ts(gxtentry))
end

local fn = _gn(0x29103E08)
function Global.TaskCower(ped)
	return _in2(fn, ped)
end

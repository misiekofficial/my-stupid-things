local fn = _gn(0x6ED83424)
function Global.CancelOverrideRestart()
	return _in2(fn)
end

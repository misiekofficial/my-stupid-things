local fn = _gn(0x0AA202B0)
function Global.TaskAimGunAtCoord(ped, tX, tY, tZ, duration)
	return _in2(fn, ped, tX, tY, tZ, duration)
end

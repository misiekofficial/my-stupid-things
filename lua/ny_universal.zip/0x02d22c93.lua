local fn = _gn(0x0A1D6E36)
function Global.NetworkLimitTo_16Players()
	return _in2(fn)
end

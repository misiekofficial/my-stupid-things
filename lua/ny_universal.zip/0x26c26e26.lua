local fn = _gn(0x4FE23851)
function Global.SetGlobalRenderFlags(Unk507, Unk508, Unk509, Unk510)
	return _in2(fn, Unk507, Unk508, Unk509, Unk510)
end

local fn = _gn(0x062E0076)
function Global.CopyCombatDecisionMaker(type, pDM)
	return _in2(fn, type, _ii(pDM) --[[ may be optional ]])
end

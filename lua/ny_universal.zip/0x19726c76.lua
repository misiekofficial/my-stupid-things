local fn = _gn(0x4E61480A)
function Global.HasModelLoaded(model)
	return _in2(fn, model, _r)
end

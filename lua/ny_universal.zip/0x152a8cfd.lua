local fn = _gn(0x59523479)
function Global.TaskStandGuard(ped, x, y, z, Unk460, Unk461, Unk462, Unk463)
	return _in2(fn, ped, x, y, z, Unk460, Unk461, Unk462, Unk463)
end

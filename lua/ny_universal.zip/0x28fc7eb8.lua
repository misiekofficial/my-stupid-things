local fn = _gn(0x3EA0648D)
function Global.EnableScriptControlledMicrophone()
	return _in2(fn, _r)
end

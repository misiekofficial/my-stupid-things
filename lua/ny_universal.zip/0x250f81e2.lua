local fn = _gn(0x04C65BEB)
function Global.GetCutsceneSectionPlaying()
	return _in2(fn, _ri)
end

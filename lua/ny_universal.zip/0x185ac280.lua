local fn = _gn(0xd932a3f3)
--- MUMBLE_SET_ACTIVE
-- @param state Voice chat state.
function Global.MumbleSetActive(state)
	return _in2(fn, state)
end

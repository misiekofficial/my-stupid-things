local fn = _gn(0x60806A0C)
function Global.NetworkJoinGame(Unk1053)
	return _in2(fn, Unk1053, _ri)
end

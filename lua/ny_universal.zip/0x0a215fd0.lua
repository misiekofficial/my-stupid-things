local fn = _gn(0x57F7558B)
function Global.GetGameViewportId(viewportid)
	return _in2(fn, _ii(viewportid) --[[ may be optional ]])
end

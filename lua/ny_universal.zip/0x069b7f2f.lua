local fn = _gn(0x58DD4CCC)
function Global.LocateCharAnyMeansCar_3d(ped, car, x, y, z, flag)
	return _in2(fn, ped, car, x, y, z, flag, _r)
end

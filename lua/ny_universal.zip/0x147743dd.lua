local fn = _gn(0x517B7068)
function Global.IsScoreGreater(playerIndex, score)
	return _in2(fn, playerIndex, score, _r)
end

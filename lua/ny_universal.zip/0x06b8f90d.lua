local fn = _gn(0x2F1D6843)
function Global.CreateCar(nameHash, x, y, z, unknownTrue)
	return _in2(fn, nameHash, x, y, z, _i, unknownTrue)
end

local fn = _gn(0x31017E6E)
function Global.SetCarWatertight(car, set)
	return _in2(fn, car, set)
end

local fn = _gn(0x68C57282)
function Global.SetDeadCharCoordinates(ped, x, y, z)
	return _in2(fn, ped, x, y, z)
end

local fn = _gn(0x791D1778)
function Global.GetObjectHeading(obj, pHeading)
	return _in2(fn, obj, _fi(pHeading) --[[ may be optional ]])
end

local fn = _gn(0x3CAA1340)
function Global.NetworkDidInviteFriend(FRIENDNAME)
	return _in2(fn, _ts(FRIENDNAME), _r)
end

local fn = _gn(0x49EA22C8)
function Global.SetVehInteriorlight(veh, set)
	return _in2(fn, veh, set)
end

local fn = _gn(0x0860560B)
function Global.AttachPedToShimmyEdge(ped, x, y, z, Unk39)
	return _in2(fn, ped, x, y, z, Unk39)
end

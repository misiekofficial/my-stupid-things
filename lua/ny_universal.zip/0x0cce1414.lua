local fn = _gn(0x590A6F04)
function Global.Asin(value)
	return _in2(fn, value, _rf)
end

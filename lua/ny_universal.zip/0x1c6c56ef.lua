local fn = _gn(0x75E32257)
function Global.GetPedSteersAroundObjects(ped)
	return _in2(fn, ped, _r)
end

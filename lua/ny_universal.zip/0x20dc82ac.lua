local fn = _gn(0x28A73BCA)
function Global.IsCharInTaxi(ped)
	return _in2(fn, ped, _r)
end

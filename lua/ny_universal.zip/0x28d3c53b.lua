local fn = _gn(0x4CC81FCB)
function Global.SetHintTimes(Unk580, Unk581, Unk582)
	return _in2(fn, Unk580, Unk581, Unk582)
end

local fn = _gn(0x2BA92322)
function Global.SetPedForceVisualiseHeadDamageFromBullets(ped, set)
	return _in2(fn, ped, set)
end

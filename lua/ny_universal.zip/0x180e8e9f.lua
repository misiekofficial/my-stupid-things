local fn = _gn(0x5BE30681)
function Global.GetNumberOfPassengers(vehicle, pNumPassengers)
	return _in2(fn, vehicle, _ii(pNumPassengers) --[[ may be optional ]])
end

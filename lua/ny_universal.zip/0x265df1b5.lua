local fn = _gn(0x314E106A)
function Global.NetworkGetNextTextChat()
	return _in2(fn, _s)
end

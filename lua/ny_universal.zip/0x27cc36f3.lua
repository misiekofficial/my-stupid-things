local fn = _gn(0x4F705478)
function Global.SetUseLegIk(player, set)
	return _in2(fn, player, set)
end

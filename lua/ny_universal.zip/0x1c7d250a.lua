local fn = _gn(0x698F762E)
function Global.UnregisterScriptWithAudio()
	return _in2(fn)
end

local fn = _gn(0x7783449D)
function Global.AwardPlayerMissionRespect(respect)
	return _in2(fn, respect)
end

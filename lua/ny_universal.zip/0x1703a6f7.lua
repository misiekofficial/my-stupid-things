local fn = _gn(0x1DFF5B06)
function Global.StoreScriptValuesForNetworkGame(Unk998)
	return _in2(fn, Unk998)
end

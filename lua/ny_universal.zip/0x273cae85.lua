local fn = _gn(0x5DDB09F8)
function Global.IsCharRespondingToAnyEvent(ped)
	return _in2(fn, ped, _r)
end

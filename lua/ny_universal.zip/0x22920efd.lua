local fn = _gn(0xcf143fb9)
--- Returns all player indices for 'active' physical players known to the client.
-- The data returned adheres to the following layout:
-- ```
-- [127, 42, 13, 37]
-- ```
-- @return An object containing a list of player indices.
function Global.GetActivePlayers()
	return _in2(fn, _ro)
end

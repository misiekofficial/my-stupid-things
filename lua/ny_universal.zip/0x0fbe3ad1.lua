local fn = _gn(0x37C85316)
function Global.IsThisPedAPlayer(ped)
	return _in2(fn, ped, _r)
end

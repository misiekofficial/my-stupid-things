local fn = _gn(0x31B64D2B)
function Global.HasFragmentRootOfClosestObjectOfTypeBeenDamaged(x, y, z, radius, Unk70)
	return _in2(fn, x, y, z, radius, Unk70, _r)
end

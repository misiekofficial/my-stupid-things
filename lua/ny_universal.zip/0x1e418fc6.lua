local fn = _gn(0x051742D5)
function Global.SetMultiplayerHudCash(cash)
	return _in2(fn, cash)
end

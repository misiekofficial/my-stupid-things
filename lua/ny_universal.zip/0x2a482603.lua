local fn = _gn(0x0CA614E6)
function Global.IsCharStopped(ped)
	return _in2(fn, ped, _r)
end

local fn = _gn(0x79700852)
function Global.SetPedExistsOnAllMachines(ped, exists)
	return _in2(fn, ped, exists)
end

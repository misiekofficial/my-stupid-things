local fn = _gn(0x30B1316B)
function Global.GetBlipSprite(blip)
	return _in2(fn, blip, _ri)
end

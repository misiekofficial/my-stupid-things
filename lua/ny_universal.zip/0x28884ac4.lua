local fn = _gn(0x1B886584)
function Global.SpecifyScriptPopulationZoneNumCars(num)
	return _in2(fn, num)
end

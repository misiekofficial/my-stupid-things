local fn = _gn(0x7F71342D)
function Global.DeleteCar(pVehicle)
	return _in2(fn, _ii(pVehicle) --[[ may be optional ]])
end

local fn = _gn(0x530F4572)
function Global.GetAcceptButton()
	return _in2(fn, _ri)
end

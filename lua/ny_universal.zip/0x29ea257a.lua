local fn = _gn(0x7D591EAD)
function Global.IsCharInAngledArea_2d(ped, x1, y1, x2, y2, unknown, unknownFalse)
	return _in2(fn, ped, x1, y1, x2, y2, unknown, unknownFalse, _r)
end

local fn = _gn(0x298827FC)
function Global.SetCamNearClip(cam, clip)
	return _in2(fn, cam, clip)
end

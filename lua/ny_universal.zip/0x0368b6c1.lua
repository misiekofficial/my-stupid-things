local fn = _gn(0x361A01AD)
function Global.UnpausePlaybackRecordedCar(car)
	return _in2(fn, car)
end

local fn = _gn(0x5C083072)
function Global.CloseGarage(garageName)
	return _in2(fn, _ts(garageName))
end

local fn = _gn(0x369A4540)
function Global.DisplayTextWithStringAndInt(x, y, gxtname, gxtnamenext, val)
	return _in2(fn, x, y, _ts(gxtname), _ts(gxtnamenext), val)
end

local fn = _gn(0x49FD2621)
function Global.ShutdownAndLaunchSinglePlayerGame()
	return _in2(fn)
end

local fn = _gn(0x1B731C3F)
function Global.GetBlipInfoIdDisplay(blip)
	return _in2(fn, blip, _ri)
end

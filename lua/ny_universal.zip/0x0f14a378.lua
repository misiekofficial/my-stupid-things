local fn = _gn(0x63B87EBE)
function Global.DontDispatchCopsForPlayer(player, dont)
	return _in2(fn, player, dont)
end

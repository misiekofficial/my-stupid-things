local fn = _gn(0x575E2880)
function Global.SetCharHealth(ped, health)
	return _in2(fn, ped, health)
end

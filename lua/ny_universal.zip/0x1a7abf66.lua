local fn = _gn(0x3A7B78C5)
function Global.GetCharTextureVariation(ped, component)
	return _in2(fn, ped, component, _ri)
end

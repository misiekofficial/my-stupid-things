local fn = _gn(0x68251A95)
function Global.CreateEmergencyServicesCarReturnDriver(model, x, y, z)
	return _in2(fn, model, x, y, z, _i, _i, _i, _r)
end

local fn = _gn(0x71F001D2)
function Global.TaskPlayAnimFacial(ped, Unk314, Unk315, Unk316, Unk317, Unk318, Unk319)
	return _in2(fn, ped, Unk314, Unk315, Unk316, Unk317, Unk318, Unk319)
end

local fn = _gn(0x7E113020)
function Global.SetOnlineLan(Unk968)
	return _in2(fn, Unk968)
end

local fn = _gn(0x3458600C)
function Global.SetCharCoordinatesDontClearPlayerTasks(ped, x, y, z)
	return _in2(fn, ped, x, y, z)
end

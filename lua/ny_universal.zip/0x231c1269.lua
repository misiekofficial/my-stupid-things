local fn = _gn(0x27636B69)
function Global.OverrideNextRestart(x, y, z, heading)
	return _in2(fn, x, y, z, heading)
end

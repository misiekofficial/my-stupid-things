local fn = _gn(0x79A95BF9)
function Global.IsPlayerBeingArrested()
	return _in2(fn, _r)
end

local fn = _gn(0x4ED45146)
function Global.SetCameraState(cam, state)
	return _in2(fn, cam, state)
end

local fn = _gn(0x3D385F6D)
function Global.DoesGroupExist(group)
	return _in2(fn, group, _r)
end

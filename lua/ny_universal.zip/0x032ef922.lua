local fn = _gn(0x489C3A48)
function Global.PedQueueConsiderPedsWithFlagTrue(flagid)
	return _in2(fn, flagid)
end

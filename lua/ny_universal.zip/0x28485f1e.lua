local fn = _gn(0x7F7B4FC5)
function Global.LoadCharDecisionMaker(type, pDM)
	return _in2(fn, type, _ii(pDM) --[[ may be optional ]])
end

local fn = _gn(0x131A0C84)
function Global.TaskCombatRoll(ped, Unk191)
	return _in2(fn, ped, Unk191)
end

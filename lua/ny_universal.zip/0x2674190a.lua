local fn = _gn(0x1788346E)
function Global.FinishStreamingRequestList()
	return _in2(fn)
end

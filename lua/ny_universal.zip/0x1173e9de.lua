local fn = _gn(0x15285933)
function Global.CheckStuckTimer(car, timernum, timeout)
	return _in2(fn, car, timernum, timeout, _r)
end

local fn = _gn(0x4371502A)
function Global.RemoveCoverPoint(coverPoint)
	return _in2(fn, coverPoint)
end

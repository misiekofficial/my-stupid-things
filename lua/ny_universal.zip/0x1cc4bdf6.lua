local fn = _gn(0x4437501B)
function Global.TaskAimGunAtChar(ped, targetPed, duration)
	return _in2(fn, ped, targetPed, duration)
end

local fn = _gn(0x3EBE11B9)
function Global.ActivateScriptedCams(Unk538, Unk539)
	return _in2(fn, Unk538, Unk539)
end

local fn = _gn(0x60EC0540)
function Global.SetCharAsMissionChar(ped)
	return _in2(fn, ped)
end

local fn = _gn(0x48726B45)
function Global.NetworkHaveSummons()
	return _in2(fn, _r)
end

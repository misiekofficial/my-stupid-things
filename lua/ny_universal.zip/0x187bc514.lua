local fn = _gn(0x71755E9B)
function Global.GetMaxWantedLevel(pMaxWantedLevel)
	return _in2(fn, _ii(pMaxWantedLevel) --[[ may be optional ]])
end

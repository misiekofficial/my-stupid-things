local fn = _gn(0x499700EF)
function Global.SetDriveTaskCruiseSpeed(ped, speed)
	return _in2(fn, ped, speed)
end

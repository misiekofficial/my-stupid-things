local fn = _gn(0x412E68D0)
function Global.ClearTextLabel(label)
	return _in2(fn, _ts(label))
end

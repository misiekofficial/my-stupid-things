local fn = _gn(0x75353EA4)
function Global.TaskExtendRoute(ped, Unk203, Unk204)
	return _in2(fn, ped, Unk203, Unk204)
end

local fn = _gn(0x2E921B0F)
function Global.CountPickupsOfType(type)
	return _in2(fn, type, _ri)
end

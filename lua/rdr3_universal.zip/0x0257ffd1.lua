local fn = _gn(0xB9BDFAE609DFB7C5)
--- 0xB9BDFAE609DFB7C5
function Global.N_0xb9bdfae609dfb7c5(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

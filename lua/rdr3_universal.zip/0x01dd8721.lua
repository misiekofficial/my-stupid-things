local fn = _gn(0x25F6EF88664540E2)
--- SET_FOCUS_POS_AND_VEL
function Global.SetFocusPosAndVel(x, y, z, offsetX, offsetY, offsetZ)
	return _in2(fn, x, y, z, offsetX, offsetY, offsetZ)
end

local fn = _gn(0x13F138225C202F66)
--- _SET_TRANSPORT_PRIORITY_SEAT
function Global.N_0x13f138225c202f66(transportEntity, seatIndex)
	return _in2(fn, transportEntity, seatIndex)
end

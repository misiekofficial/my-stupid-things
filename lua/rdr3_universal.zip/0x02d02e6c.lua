local fn = _gn(0x88B58B83A43A8CAB)
--- _INVENTORY_DOES_ITEM_OWN_EQUIPMENT
function Global.N_0x88b58b83a43a8cab(inventoryId, item)
	return _in2(fn, inventoryId, _i, _ch(item), _ri)
end

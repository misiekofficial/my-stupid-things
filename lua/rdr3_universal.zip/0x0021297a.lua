local fn = _gn(0x16F798A05BB9E3B5)
--- _PED_COWER_M*
function Global.N_0x16f798a05bb9e3b5(ped)
	return _in2(fn, ped)
end

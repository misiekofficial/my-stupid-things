local fn = _gn(0x95384C6CE1526EFF)
--- Found icons: SPEAKER, THROPY
function Global.N_0x95384c6ce1526eff(gamerTagId, icon)
	return _in2(fn, gamerTagId, _ch(icon))
end

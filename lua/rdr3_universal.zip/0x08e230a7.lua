local fn = _gn(0xAA5B7C8309F73230)
--- START_SHAPE_TEST_SWEPT_SPHERE
function Global.StartShapeTestSweptSphere(x1, y1, z1, x2, y2, z2, radius, flags, entity, p9)
	return _in2(fn, x1, y1, z1, x2, y2, z2, radius, flags, entity, p9, _ri)
end

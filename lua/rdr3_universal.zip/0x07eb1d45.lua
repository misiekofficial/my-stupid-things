local fn = _gn(0x78C2E029DB205A3A)
--- _TELEMETRY_CRAFT_ITEM
function Global.N_0x78c2e029db205a3a(p0, p1, p2, quantity)
	return _in2(fn, p0, p1, p2, quantity)
end

local fn = _gn(0x9993F1E11944A3DD)
--- _UGC_QUERY_GET_PUBLISHED
function Global.UgcQueryGetPublished(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

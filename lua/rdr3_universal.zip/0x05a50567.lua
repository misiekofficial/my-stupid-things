local fn = _gn(0x565C1CE183CB0EAF)
--- _UI_PROMPT_SET_ALLOWED_ACTION
function Global.UiPromptSetAllowedAction(prompt, action)
	return _in2(fn, prompt, _ch(action))
end

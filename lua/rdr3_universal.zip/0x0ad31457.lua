local fn = _gn(0x93FFD92F05EC32FD)
--- _IS_META_PED_ASSET_VALID
function Global.N_0x93ffd92f05ec32fd(requestId)
	return _in2(fn, requestId, _ri)
end

local fn = _gn(0x4C11CCACB7C02B6E)
--- _DOES_CHECKPOINT_HAVE_FX
function Global.N_0x4c11ccacb7c02b6e(checkpoint)
	return _in2(fn, checkpoint, _ri)
end

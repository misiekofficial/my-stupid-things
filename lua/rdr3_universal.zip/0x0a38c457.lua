local fn = _gn(0xAFF2FD8ADD927585)
--- _GAME_FRAMEWORK_MANAGER_SHUTDOWN
function Global.N_0xaff2fd8add927585()
	return _in2(fn)
end

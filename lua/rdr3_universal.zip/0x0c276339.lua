local fn = _gn(0xF666EF30F4F0AC4E)
--- _SET_CARRIABLE_CARRY_ACTION_PROMPT_OVERRIDE
function Global.SetCarriableCarryActionPromptOverride(data)
	return _in2(fn, _ii(data) --[[ may be optional ]])
end

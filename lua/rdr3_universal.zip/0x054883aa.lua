local fn = _gn(0xAC8FAB22A914AE34)
--- AWARDS_GET_RESULT_ITEM
function Global.AwardsGetResultItem(awardHash, itemIndex)
	return _in2(fn, _i, _ch(awardHash), itemIndex, _i, _ri)
end

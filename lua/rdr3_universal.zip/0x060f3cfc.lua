local fn = _gn(0x6AD66548840472E5)
--- _IS_WEAPON_SNIPER
function Global.IsWeaponSniper(weaponHash)
	return _in2(fn, _ch(weaponHash), _ri)
end

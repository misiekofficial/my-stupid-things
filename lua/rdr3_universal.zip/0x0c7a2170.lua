local fn = _gn(0xFF975BC4435A0FA3)
--- DOES_THREAD_EXIST
function Global.DoesThreadExist(threadId)
	return _in2(fn, threadId, _ri)
end

local fn = _gn(0x31DC8D3F216D8509)
--- _IS_TEXTURE_VALID
function Global.N_0x31dc8d3f216d8509(textureId)
	return _in2(fn, textureId, _ri)
end

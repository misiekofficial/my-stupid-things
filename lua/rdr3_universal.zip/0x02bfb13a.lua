local fn = _gn(0x74CF39E030A382C4)
--- SC_INBOX_GET_MESSAGE_IS_READ_AT_INDEX
function Global.ScInboxGetMessageIsReadAtIndex(msgIndex)
	return _in2(fn, msgIndex, _r)
end

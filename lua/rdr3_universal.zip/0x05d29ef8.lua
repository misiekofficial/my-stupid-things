local fn = _gn(0xD4FA73FE628FEC63)
--- 0xD4FA73FE628FEC63
function Global.N_0xd4fa73fe628fec63(p0, p1)
	return _in2(fn, p0, p1)
end

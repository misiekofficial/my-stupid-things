local fn = _gn(0x59577799F6AE2F34)
--- NETWORK_SPAWN_CONFIG_SET_GROUND_TO_ROOT_OFFSET
function Global.NetworkSpawnConfigSetGroundToRootOffset(offset)
	return _in2(fn, offset)
end

local fn = _gn(0x104D9A7B1C0D0783)
--- 0x104D9A7B1C0D0783
function Global.N_0x104d9a7b1c0d0783(vehicle, p1)
	return _in2(fn, vehicle, p1)
end

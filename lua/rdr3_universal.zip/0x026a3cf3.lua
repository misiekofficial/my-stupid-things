local fn = _gn(0xFCA8B23F28813F69)
--- Checks against a global variable that is set by _SET_WORLD_WATER_TYPE. If that is set to one it will fail. Likely not the only issue but part of it.
function Global.GetWaterHeight(x, y, z, height)
	return _in2(fn, x, y, z, _fi(height) --[[ may be optional ]], _r)
end

local fn = _gn(0x31108BB5715D035F)
--- IPL_GROUP_SWAP_CANCEL
function Global.IplGroupSwapCancel()
	return _in2(fn)
end

local fn = _gn(0x5B4BBE80AD5972DC)
--- groundSetting: 0: spawn on ground, 2 (1?): do not spawn on ground
-- p7: -1 in R* Scripts
-- Returns compositeId
function Global.N_0x5b4bbe80ad5972dc(asset, x, y, z, heading, groundSetting, p7)
	return _in2(fn, _ch(asset), x, y, z, heading, groundSetting, _i, p7, _ri)
end

local fn = _gn(0x3B005FF0538ED2A9)
--- Ped (horse) will run away from players and mounting will trigger them to buck until disabled.
-- Used for: REL_DOMESTICATED_ANIMAL
function Global.N_0x3b005ff0538ed2a9(ped)
	return _in2(fn, ped, _ri)
end

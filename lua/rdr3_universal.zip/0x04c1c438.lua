local fn = _gn(0x9821B68CD3E05F2B)
--- _SET_VARIABLE_ON_SOUND_WITH_NAME
function Global.SetVariableOnSoundWithName(variableName, variableValue, audioName, audioRef)
	return _in2(fn, _ts(variableName), variableValue, _ts(audioName), _ts(audioRef))
end

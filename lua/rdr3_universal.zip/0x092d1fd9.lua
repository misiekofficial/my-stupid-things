local fn = _gn(0x11A7ADCD629E170F)
--- NETWORK_GET_GLOBAL_CLOCK
function Global.NetworkGetClockTimeOverride()
	return _in2(fn, _i, _i, _i, _r)
end

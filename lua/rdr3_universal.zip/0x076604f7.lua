local fn = _gn(0xFC79DCC94D0A5897)
--- _SET_PLAYER_WEAPON_GROUP_DAMAGE_MODIFIER
function Global.SetPlayerWeaponGroupDamageModifier(player, weaponGroup, modifier)
	return _in2(fn, player, _ch(weaponGroup), modifier)
end

local fn = _gn(0x5AABB09F6FBD1F87)
--- wetLevel: 0.0 - 1.0
function Global.SetVehicleWetLevel(vehicle, wetLevel)
	return _in2(fn, vehicle, wetLevel)
end

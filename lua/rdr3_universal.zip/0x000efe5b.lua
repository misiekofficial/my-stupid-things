local fn = _gn(0x3A379D2166CF5B92)
--- SET_ANIM_SCENE_INT
function Global.SetAnimSceneInt(animScene, name, value, p3)
	return _in2(fn, animScene, _ts(name), value, p3)
end

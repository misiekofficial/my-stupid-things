local fn = _gn(0xECD67E9FA677CCCF)
--- _TELEMETRY_LOBBY_PROGRESSION
function Global.N_0xecd67e9fa677cccf(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3)
end

local fn = _gn(0xF7AC7DC0DEE7C9BE)
--- COPY_SCRIPT_STRUCT
function Global.CopyScriptStruct(size)
	return _in2(fn, _i, _i, size)
end

local fn = _gn(0x37C13863ABA1B4A3)
--- TASK_AMBIENT_ANIMAL_STALK
function Global.TaskAmbientAnimalStalk(ped, p1, p2)
	return _in2(fn, ped, p1, p2)
end

local fn = _gn(0x7332461FC59EB7EC)
--- DOES_STREAMED_TEXTURE_DICT_EXIST
function Global.DoesStreamedTextureDictExist(textureDict)
	return _in2(fn, _ts(textureDict), _ri)
end

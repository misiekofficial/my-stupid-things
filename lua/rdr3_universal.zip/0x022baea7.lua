local fn = _gn(0xE824CE7D13FCB300)
--- MISSION_RATING_INCOMPLETE = 0,
-- MISSION_RATING_SKIPPED,
-- MISSION_RATING_COMPLETE,
-- MISSION_RATING_BRONZE,
-- MISSION_RATING_SILVER,
-- MISSION_RATING_GOLD,
function Global.N_0xe824ce7d13fcb300(missionId, rating)
	return _in2(fn, _ch(missionId), rating)
end

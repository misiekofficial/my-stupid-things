local fn = _gn(0xDF1D85BCAF60D537)
--- _TASK_CLIMB_2
function Global.TaskClimb_2(ped, heading)
	return _in2(fn, ped, heading)
end

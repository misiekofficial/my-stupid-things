local fn = _gn(0x68772DB2B2526F9F)
--- NativeDB Introduced: v1311
function Global.IsAnyHostilePedNearPoint(ped, x, y, z, radius)
	return _in2(fn, ped, x, y, z, radius, _r)
end

local fn = _gn(0x502EC17B1BED4BFA)
--- TASK_PICKUP_CARRIABLE_ENTITY
function Global.TaskPickupCarriableEntity(ped, entity)
	return _in2(fn, ped, entity)
end

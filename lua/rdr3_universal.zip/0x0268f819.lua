local fn = _gn(0xE843D21A8E2498AA)
--- _INVENTORY_GET_CHILDREN_COUNT
function Global.N_0xe843d21a8e2498aa(inventoryId, parentGuid)
	return _in2(fn, inventoryId, _ii(parentGuid) --[[ may be optional ]], _ri)
end

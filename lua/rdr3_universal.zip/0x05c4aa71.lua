local fn = _gn(0xC061E50F8D299F95)
--- _GET_PROP_SET_AT_COORDS
function Global.N_0xc061e50f8d299f95(propsetHash, x, y, z)
	return _in2(fn, _ch(propsetHash), x, y, z, _ri)
end

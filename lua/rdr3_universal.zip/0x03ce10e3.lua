local fn = _gn(0xFA821997794F48E7)
--- 0xFA821997794F48E7
function Global.N_0xfa821997794f48e7(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

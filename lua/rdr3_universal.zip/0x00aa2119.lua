local fn = _gn(0xF08E42BFA46BDFF8)
--- 0xF08E42BFA46BDFF8
function Global.N_0xf08e42bfa46bdff8(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

local fn = _gn(0xB1F6665AA54DCD5C)
--- 0xB1F6665AA54DCD5C
function Global.N_0xb1f6665aa54dcd5c(p0)
	return _in2(fn, p0, _ri)
end

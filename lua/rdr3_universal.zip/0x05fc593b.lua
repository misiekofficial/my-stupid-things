local fn = _gn(0xB6E6FBA95C7324AC)
--- Sets the ajar angle of a door.
-- Ranges from -1.0 to 1.0, and 0.0 is closed / default.
function Global.DoorSystemSetOpenRatio(doorHash, ajar, forceUpdate)
	return _in2(fn, _ch(doorHash), ajar, forceUpdate)
end

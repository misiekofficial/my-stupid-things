local fn = _gn(0x21A99A72B00D8002)
--- _UGC_QUERY_GET_POSIX_UPDATED_DATE
function Global.UgcQueryGetPosixUpdatedDate(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

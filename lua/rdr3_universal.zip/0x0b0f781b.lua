local fn = _gn(0x4A8FEFC43FD8AC9B)
--- 0x4A8FEFC43FD8AC9B
function Global.N_0x4a8fefc43fd8ac9b(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

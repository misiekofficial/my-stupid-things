local fn = _gn(0x50C14328119E1DD1)
--- _BLOCK_PICKUP_OBJECT_LIGHT
function Global.N_0x50c14328119e1dd1(pickupObject, toggle)
	return _in2(fn, pickupObject, toggle)
end

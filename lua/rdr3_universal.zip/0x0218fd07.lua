local fn = _gn(0x5708EDD71B50C008)
--- _SET_PLAYER_ANTAGONIZE_DISABLED_FOR_PED
function Global.N_0x5708edd71b50c008(ped, player, duration)
	return _in2(fn, ped, player, duration)
end

local fn = _gn(0x45AB66D02B601FA7)
--- _IS_SECONDARY_SPECIAL_ABILITY_ACTIVE
function Global.IsSecondarySpecialAbilityActive(player)
	return _in2(fn, player, _ri)
end

local fn = _gn(0x92A1B55A59720395)
--- 0x92A1B55A59720395
function Global.N_0x92a1b55a59720395(p0, p1)
	return _in2(fn, p0, p1)
end

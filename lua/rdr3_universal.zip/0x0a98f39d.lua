local fn = _gn(0x6C76BC24F8BB709A)
--- _SET_TEXTURE_LAYER_ALPHA
function Global.SetTextureLayerAlpha(textureId, layerId, texAlpha)
	return _in2(fn, textureId, layerId, texAlpha)
end

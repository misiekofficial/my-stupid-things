local fn = _gn(0xD42514C182121C23)
--- Returns weaponCollection Hash
-- Example: RE_POLICECHASE_MALES_01: Carbine Repeater + Knife, LO_AGRO_PED
function Global.N_0xd42514c182121c23(pedModel)
	return _in2(fn, _ch(pedModel), _ri)
end

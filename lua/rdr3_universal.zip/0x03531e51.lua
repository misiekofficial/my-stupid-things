local fn = _gn(0xC97E0D2302382211)
--- _INVENTORY_GET_INVENTORY_ITEM_COUNT_WITH_GUID
function Global.InventoryGetInventoryItemCountWithGuid(inventoryId, p2)
	return _in2(fn, inventoryId, _i, p2, _ri)
end

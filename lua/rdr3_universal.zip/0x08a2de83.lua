local fn = _gn(0x8FB7C254CFCBF78E)
--- NETWORK_SESSION_IS_REQUEST_IN_PROGRESS
function Global.N_0x8fb7c254cfcbf78e(sessionRequestId)
	return _in2(fn, _ii(sessionRequestId) --[[ may be optional ]], _ri)
end

local fn = _gn(0x5EBE38A20BC51C27)
--- _GET_PLAYER_PED_2
function Global.N_0x5ebe38a20bc51c27(player)
	return _in2(fn, player, _ri)
end

local fn = _gn(0xDDF803377F94AAA8)
--- SET_PED_GESTURE_GROUP
function Global.SetPedGestureGroup(ped, gesture, p2)
	return _in2(fn, ped, _ts(gesture), p2)
end

local fn = _gn(0x67943537D179597C)
--- p3 is always -1.0f in the scripts
function Global.ForceLightningFlashAtCoords(x, y, z, p3)
	return _in2(fn, x, y, z, p3)
end

local fn = _gn(0x1F85E4AC774A201E)
--- _CREATE_VOLUME_BY_HASH_WITH_CUSTOM_NAME
function Global.CreateVolumeByHashWithCustomName(volumeType, x, y, z, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, name)
	return _in2(fn, _ch(volumeType), x, y, z, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, _ts(name), _ri)
end

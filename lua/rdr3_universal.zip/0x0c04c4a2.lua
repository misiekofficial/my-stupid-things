local fn = _gn(0x27F89FDC16688A7A)
--- IS_PLAYER_TARGETTING_ENTITY
function Global.IsPlayerTargettingEntity(player, entity, p2)
	return _in2(fn, player, entity, p2, _r)
end

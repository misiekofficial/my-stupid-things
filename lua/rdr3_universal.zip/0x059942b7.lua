local fn = _gn(0x40C5D95818823C94)
--- _ITEMDATABASE_FILLOUT_PRICE_MODIFIER_BY_KEY
function Global.ItemDatabaseFilloutPriceModifierByKey(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

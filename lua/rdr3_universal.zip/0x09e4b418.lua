local fn = _gn(0x7F8E2B131E1DCA6C)
--- SET_FORCE_VEHICLE_ENGINE_DAMAGE_BY_BULLET
function Global.SetForceVehicleEngineDamageByBullet(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

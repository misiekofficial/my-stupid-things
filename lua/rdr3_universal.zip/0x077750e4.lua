local fn = _gn(0xE2C3CEC3C0903A00)
--- _TEXTURE_DOWNLOAD_TEXTURE_NAME_IS_VALID
function Global.N_0xe2c3cec3c0903a00(name)
	return _in2(fn, _ts(name), _ri)
end

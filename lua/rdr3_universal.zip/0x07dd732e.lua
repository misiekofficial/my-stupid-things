local fn = _gn(0x89783FDDF079C88D)
--- _TASK_AI_SEEK_COVER_TO_COVER_POINT
function Global.TaskAiSeekCoverToCoverPoint(args)
	return _in2(fn, _ii(args) --[[ may be optional ]])
end

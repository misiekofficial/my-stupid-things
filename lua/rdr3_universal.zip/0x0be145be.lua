local fn = _gn(0x42718CC559BD7776)
--- FIND_ANIM_EVENT_PHASE
function Global.FindAnimEventPhase(animDictionary, animName, p2)
	return _in2(fn, _ts(animDictionary), _ts(animName), _ts(p2), _i, _i, _r)
end

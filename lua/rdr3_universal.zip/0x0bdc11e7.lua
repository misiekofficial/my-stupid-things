local fn = _gn(0x025A1B1FB03FBF61)
--- _INVENTORY_GET_FULL_INVENTORY_ITEM_DATA
function Global.N_0x025a1b1fb03fbf61(inventoryId, p3, p4)
	return _in2(fn, inventoryId, _i, _i, p3, p4, _ri)
end

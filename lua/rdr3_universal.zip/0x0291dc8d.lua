local fn = _gn(0xF7EA250B9A919E03)
--- _REQUEST_MOTION_TYPE_ASSET
function Global.N_0xf7ea250b9a919e03(nameHash, ped)
	return _in2(fn, _ch(nameHash), ped)
end

local fn = _gn(0x22741652985C84D0)
--- Used in SP only
-- _REPORT_*
function Global.N_0x22741652985c84d0(player, lawRegionHash)
	return _in2(fn, player, _ch(lawRegionHash))
end

local fn = _gn(0x4C221BAC54D735C3)
--- ADD_ROAD_NODE_SPEED_ZONE
function Global.AddSpeedZoneForCoord(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10)
	return _in2(fn, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, _ri)
end

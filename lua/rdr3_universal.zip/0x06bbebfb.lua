local fn = _gn(0x2970929FD5F9FC89)
--- Inhibits the player from using any method of combat including melee and firearms.
-- NOTE: Only disables the firing for one frame
function Global.DisablePlayerFiring(player, toggle)
	return _in2(fn, player, toggle)
end

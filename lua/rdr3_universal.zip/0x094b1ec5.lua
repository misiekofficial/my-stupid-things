local fn = _gn(0x37BB86A751148A6A)
--- _DATABINDING_ADD_DATA_BOOL_FROM_PATH
function Global.DatabindingAddDataBoolFromPath(p0, p1, p2)
	return _in2(fn, _ts(p0), _ts(p1), p2, _ri)
end

local fn = _gn(0x19A6BE7D9C6884D3)
--- _REQUEST_SCENARIO_TYPE
function Global.RequestScenarioType(scenarioType, p1, p2, p3)
	return _in2(fn, _ch(scenarioType), p1, p2, p3, _ri)
end

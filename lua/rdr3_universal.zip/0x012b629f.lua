local fn = _gn(0xBC29A9894C976945)
--- FORCE_ROOM_FOR_ENTITY
function Global.ForceRoomForEntity(entity, interior, roomHashKey)
	return _in2(fn, entity, interior, _ch(roomHashKey))
end

local fn = _gn(0xFB6EB8785F808551)
--- GET_PLAYER_RECEIVED_BATTLE_EVENT_RECENTLY
function Global.N_0xfb6eb8785f808551(player, p1, p2)
	return _in2(fn, player, p1, p2, _r)
end

local fn = _gn(0x2B8B605F2A9E64BF)
--- Returns true if player is moving mouse while cursor is active
-- _PI* - _PO*
-- ```
-- ```
-- NativeDB Introduced: v1311
function Global.N_0x2b8b605f2a9e64bf()
	return _in2(fn, _r)
end

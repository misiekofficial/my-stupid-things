local fn = _gn(0x07C0F87AAC57F2E4)
--- _SET_LIGHTS_INTENSITY_FOR_ENTITY
function Global.N_0x07c0f87aac57f2e4(entity, intensity)
	return _in2(fn, entity, intensity)
end

local fn = _gn(0x543DFE14BE720027)
--- Used for setting up eagle eye for entity
-- Params: p2 = re-register or not?
function Global.RegisterEagleEyeForEntity(player, entity, p2)
	return _in2(fn, player, entity, p2)
end

local fn = _gn(0xCD6F8A0335D821F9)
--- _TELEMETRY_REGION
function Global.N_0xcd6f8a0335d821f9(regionHash)
	return _in2(fn, _ch(regionHash))
end

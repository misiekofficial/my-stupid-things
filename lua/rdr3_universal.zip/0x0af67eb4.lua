local fn = _gn(0x46CBCF0E98A4E156)
--- 0x46CBCF0E98A4E156
function Global.N_0x46cbcf0e98a4e156(p0, p1)
	return _in2(fn, p0, p1)
end

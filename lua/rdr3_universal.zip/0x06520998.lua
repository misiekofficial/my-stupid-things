local fn = _gn(0x4C60C333F9CCA2B6)
--- Params: p1 usually true in R* Scripts
-- _SET_DRAFT_VEHICLE_*
function Global.N_0x4c60c333f9cca2b6(vehicle, p1)
	return _in2(fn, vehicle, p1)
end

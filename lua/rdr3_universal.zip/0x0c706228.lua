local fn = _gn(0xB285AD0EC870B2DF)
--- Params: hash - ARTHUR or JOHN
-- _SET_PED_(A-D)*
function Global.N_0xb285ad0ec870b2df(ped, playerType)
	return _in2(fn, ped, _ch(playerType))
end

local fn = _gn(0xC6A7DC546E94FED5)
--- _EVENT_GET_TIME_SINCE_EVENT
function Global.N_0xc6a7dc546e94fed5(entity, eventType, p2, p3)
	return _in2(fn, entity, _ch(eventType), p2, p3, _ri)
end

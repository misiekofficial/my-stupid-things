local fn = _gn(0x08FC896D2CB31FCC)
--- 0x08FC896D2CB31FCC
function Global.N_0x08fc896d2cb31fcc(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

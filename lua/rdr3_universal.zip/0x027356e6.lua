local fn = _gn(0x41452E8A3B9C0C4B)
--- 0x41452E8A3B9C0C4B
function Global.N_0x41452e8a3b9c0c4b()
	return _in2(fn, _ri)
end

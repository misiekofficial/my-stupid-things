local fn = _gn(0x5D1C5D8E62E8EE1C)
--- Returns proxyInteriorIndex
function Global.N_0x5d1c5d8e62e8ee1c(interiorId)
	return _in2(fn, interiorId, _ri)
end

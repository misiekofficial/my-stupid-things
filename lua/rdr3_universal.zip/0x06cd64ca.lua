local fn = _gn(0x8785E6E40C7A8819)
--- GET_IS_PED_AIMING_IN_THE_AIR
function Global.GetIsPedAimingInTheAir(ped)
	return _in2(fn, ped, _ri)
end

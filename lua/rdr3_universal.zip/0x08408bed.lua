local fn = _gn(0x411189E51B8020BA)
--- _REMOVE_PED_BLACKBOARD_FLOAT
function Global.N_0x411189e51b8020ba(ped, variableName)
	return _in2(fn, ped, _ts(variableName))
end

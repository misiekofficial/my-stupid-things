local fn = _gn(0xE2B3B852B537C398)
--- ALLOW_DAMAGE_EVENTS_FOR_NON_NETWORKED_OBJECTS
function Global.AllowDamageEventsForNonNetworkedObjects(enabled)
	return _in2(fn, enabled)
end

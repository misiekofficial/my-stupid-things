local fn = _gn(0xA924028272A61364)
--- SET_CAM_NEAR_CLIP
function Global.SetCamNearClip(cam, nearClip)
	return _in2(fn, cam, nearClip)
end

local fn = _gn(0x725D52F21A5E9E06)
--- COMPENDIUM_GANG_BOUNTY_CAPTURED
function Global.CompendiumGangBountyCaptured(p0)
	return _in2(fn, p0)
end

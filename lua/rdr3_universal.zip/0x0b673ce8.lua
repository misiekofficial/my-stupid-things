local fn = _gn(0x81948DFE4F5A0283)
--- _DELETE_SCENARIO_POINT
function Global.DeleteScenarioPoint(scenario)
	return _in2(fn, scenario)
end

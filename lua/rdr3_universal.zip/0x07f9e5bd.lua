local fn = _gn(0x1549BA7FE83A2383)
--- SET_VEHICLE_KEEP_ENGINE_ON_WHEN_ABANDONED
function Global.SetVehicleKeepEngineOnWhenAbandoned(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

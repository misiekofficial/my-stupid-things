local fn = _gn(0xC61E2FD926DBB406)
--- NativeDB Introduced: v1311
function Global.N_0xc61e2fd926dbb406()
	return _in2(fn)
end

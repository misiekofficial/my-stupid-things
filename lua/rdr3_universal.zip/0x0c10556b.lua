local fn = _gn(0x5C9978A2A3DC3D0D)
--- DISABLE_ENTITYMASK
function Global.DisableEntitymask()
	return _in2(fn)
end

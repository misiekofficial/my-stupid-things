local fn = _gn(0x73118A3EE9C9B6DB)
--- _SET_VEHICLE_WHEELS_*
function Global.N_0x73118a3ee9c9b6db(wagon, p1, p2)
	return _in2(fn, wagon, p1, p2)
end

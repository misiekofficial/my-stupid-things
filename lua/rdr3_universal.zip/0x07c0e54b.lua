local fn = _gn(0x2056AB38DF06825C)
--- _SET_SCENARIO_POINT_COORDS
function Global.SetScenarioPointCoords(scenario, xPos, yPos, zPos, p4)
	return _in2(fn, scenario, xPos, yPos, zPos, p4)
end

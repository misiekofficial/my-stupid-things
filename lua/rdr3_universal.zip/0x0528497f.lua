local fn = _gn(0x8800776E410EB669)
--- Returns true if a path of waypoints was found. Waypoints can be retrieved with _NAVMESH_REQUESTED_PATH_NUM_WAYPOINTS and _NAVMESH_REQUESTED_PATH_WAYPOINT_BY_INDEX
function Global.N_0x8800776e410eb669(path)
	return _in2(fn, path, _r)
end

local fn = _gn(0x10AB107B887214D8)
--- TASK_VEHICLE_SHOOT_AT_PED
function Global.TaskVehicleShootAtPed(ped, target, p2)
	return _in2(fn, ped, target, p2)
end

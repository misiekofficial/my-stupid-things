local fn = _gn(0x7D7D2B47FA788E85)
--- WAYPOINT_PLAYBACK_OVERRIDE_SPEED
function Global.WaypointPlaybackOverrideSpeed(ped, speed, p2, p3, p4)
	return _in2(fn, ped, speed, p2, p3, p4)
end

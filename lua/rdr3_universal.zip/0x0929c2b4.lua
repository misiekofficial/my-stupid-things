local fn = _gn(0x10B2218320B6F5AC)
--- Only works with objects!
function Global.CreateModelSwap(x, y, z, radius, originalModel, newModel, p6)
	return _in2(fn, x, y, z, radius, _ch(originalModel), _ch(newModel), p6)
end

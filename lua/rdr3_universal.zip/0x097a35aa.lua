local fn = _gn(0x88D9D76D78065487)
--- _GET_INCAPACITATION_TIME_REMAINING
function Global.GetIncapacitationTimeRemaining(ped)
	return _in2(fn, ped, _ri)
end

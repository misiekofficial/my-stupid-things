local fn = _gn(0xF01C570E0A0A1E67)
--- _IS_SCRIPTED_CONVERSION_ONGOING
function Global.IsScriptedConversionOngoing(p0)
	return _in2(fn, _ts(p0), _ri)
end

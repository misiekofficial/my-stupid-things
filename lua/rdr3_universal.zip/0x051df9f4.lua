local fn = _gn(0x9F6DCD0C939C71E9)
--- SC_COMMUNITY_EVENT_GET_EXTRA_DATA_STRING
function Global.N_0x9f6dcd0c939c71e9(p0, p1)
	return _in2(fn, _ts(p0), _ts(p1), _ri)
end

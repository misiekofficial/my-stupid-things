local fn = _gn(0xF8D1D2DAB6007EEF)
--- _IS_ANIM_SCENE_METADATA_ASSET_IN_RANGE_LOADING
function Global.N_0xf8d1d2dab6007eef(animScene, p1)
	return _in2(fn, animScene, p1, _ri)
end

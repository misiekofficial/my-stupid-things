local fn = _gn(0xADC45010BC17AF0E)
--- _SET_SCENARIO_POINT_*
function Global.N_0xadc45010bc17af0e(p0, p1)
	return _in2(fn, p0, p1)
end

local fn = _gn(0xEBA51A294C73292E)
--- 0xEBA51A294C73292E
function Global.N_0xeba51a294c73292e(args)
	return _in2(fn, _ii(args) --[[ may be optional ]])
end

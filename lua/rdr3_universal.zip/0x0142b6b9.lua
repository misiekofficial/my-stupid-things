local fn = _gn(0x9C74AC9D87B3FFF4)
--- Starts a task to check an entered string for profanity on the ROS/Social Club services.
function Global.ScProfanityCheckString(string, token)
	return _in2(fn, _ts(string), _ii(token) --[[ may be optional ]], _r)
end

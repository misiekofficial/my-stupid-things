local fn = _gn(0x32CCAD8A981B53D3)
--- _STOP_(?)*
function Global.N_0x32ccad8a981b53d3(ped)
	return _in2(fn, ped)
end

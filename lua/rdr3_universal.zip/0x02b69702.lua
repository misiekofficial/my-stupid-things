local fn = _gn(0x2F11D3A254169EA4)
--- tabIndex: specifies tab of prompt
function Global.UiPromptSetGroup(prompt, groupId, tabIndex)
	return _in2(fn, prompt, groupId, tabIndex)
end

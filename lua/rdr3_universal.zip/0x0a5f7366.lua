local fn = _gn(0x5D3C528B7A7DF836)
--- _NETWORK_SPAWN_CONFIG_*
function Global.N_0x5d3c528b7a7df836(nsctf)
	return _in2(fn, _ch(nsctf))
end

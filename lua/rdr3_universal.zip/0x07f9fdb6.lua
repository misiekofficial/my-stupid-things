local fn = _gn(0x73F0D0327BFA0812)
--- https://github.com/femga/rdr3_discoveries/tree/master/objects/composites
function Global.RequestHerbCompositeAsset(asset)
	return _in2(fn, _ch(asset), _ri)
end

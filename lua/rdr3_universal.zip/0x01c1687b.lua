local fn = _gn(0x89D9FCC2435112F1)
--- Climbs or vaults the nearest thing.
function Global.TaskClimb(ped, unused)
	return _in2(fn, ped, unused)
end

local fn = _gn(0xA2058154357726BB)
--- _TELEMETRY_MATCH_OVER
function Global.TelemetryMatchOver(p0, p1, p2, p3, p4)
	return _in2(fn, p0, p1, p2, p3, p4)
end

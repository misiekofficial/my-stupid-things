local fn = _gn(0xA33914B00CA55756)
--- 0xA33914B00CA55756
function Global.N_0xa33914b00ca55756(p0, p1)
	return _in2(fn, _ts(p0), p1, _ri)
end

local fn = _gn(0x92E87F60F21A0C3A)
--- SET_PICKUP_NOT_LOOTABLE
function Global.SetPickupNotLootable(p0, p1)
	return _in2(fn, p0, p1)
end

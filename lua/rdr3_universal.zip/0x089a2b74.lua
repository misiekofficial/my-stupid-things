local fn = _gn(0x08EAF8E9F2EB7B2E)
--- _PARSEDDATA_RQ_FILLOUT_STRING_63
function Global.ParseddataRqFilloutString_63(p0, p1)
	return _in2(fn, _ts(p0), _ii(p1) --[[ may be optional ]], _ri)
end

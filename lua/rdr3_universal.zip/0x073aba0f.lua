local fn = _gn(0x76F7E1BCD623A429)
--- 0x76F7E1BCD623A429
function Global.N_0x76f7e1bcd623a429(p0)
	return _in2(fn, p0)
end

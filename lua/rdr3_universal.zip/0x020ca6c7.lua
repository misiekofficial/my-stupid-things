local fn = _gn(0x3332695B01015DF9)
--- _ITEMDATABASE_GET_BUNDLE_ITEM_COUNT
function Global.ItemdatabaseGetBundleItemCount(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

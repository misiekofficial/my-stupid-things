local fn = _gn(0xF58A0C0E086E8E36)
--- NativeDB Introduced: v1311
function Global.CompendiumGetNumEntriesInSubcategory(category, subcategory)
	return _in2(fn, _ch(category), _ch(subcategory), _ri)
end

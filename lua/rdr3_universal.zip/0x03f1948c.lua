local fn = _gn(0x787E43477746876F)
--- Restarts the train
function Global.SetTrainLeaveStation(train)
	return _in2(fn, train)
end

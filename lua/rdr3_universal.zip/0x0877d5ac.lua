local fn = _gn(0x954451EA2D2120FB)
--- 0x954451EA2D2120FB
function Global.N_0x954451ea2d2120fb(p0, p1)
	return _in2(fn, p0, p1)
end

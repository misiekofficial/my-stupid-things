local fn = _gn(0x802092B07E3B1EEA)
--- lookIntensity: see SET_PED_SHOULD_PLAY_FLEE_SCENARIO_EXIT
function Global.N_0x802092b07e3b1eea(ped, x, y, z, lookIntensity)
	return _in2(fn, ped, x, y, z, lookIntensity, _ri)
end

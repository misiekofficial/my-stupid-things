local fn = _gn(0x1694A053DFB61A34)
--- nullsub, doesn't do anything
function Global.N_0x1694a053dfb61a34(p0)
	return _in2(fn, _ts(p0))
end

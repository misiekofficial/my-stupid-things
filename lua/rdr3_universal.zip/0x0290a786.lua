local fn = _gn(0x8AE4EFA464DAE42D)
--- 0x8AE4EFA464DAE42D
function Global.N_0x8ae4efa464dae42d(p0, p1)
	return _in2(fn, p0, p1)
end

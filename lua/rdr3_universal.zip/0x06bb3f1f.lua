local fn = _gn(0x3923EC958249657D)
--- Params: p2 is always -1.f in R* Scripts
function Global.AddFleeTargetPed(ped, targetPed, p2)
	return _in2(fn, ped, targetPed, p2)
end

local fn = _gn(0x4735E2A4BB83D9DA)
--- _GET_PINNED_MAP_ENTITY
function Global.N_0x4735e2a4bb83d9da(p0)
	return _in2(fn, p0, _ri)
end

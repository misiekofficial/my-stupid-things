local fn = _gn(0x5829A02AF4F0B3CB)
--- Returns true if the id is non zero.
function Global.IsVehicleNodeIdValid(vehicleNodeId)
	return _in2(fn, vehicleNodeId, _r)
end

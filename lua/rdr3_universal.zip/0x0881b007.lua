local fn = _gn(0x40914CCF2A1AB531)
--- _TELEMETRY_CUSTOM
function Global.TelemetryCustom(args)
	return _in2(fn, _ii(args) --[[ may be optional ]])
end

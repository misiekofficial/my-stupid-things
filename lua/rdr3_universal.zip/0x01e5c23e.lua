local fn = _gn(0xE4EFB315BCD2A838)
--- _DAMAGE_BONE_ON_PROP
function Global.DamageBoneOnProp(object, bone)
	return _in2(fn, object, bone)
end

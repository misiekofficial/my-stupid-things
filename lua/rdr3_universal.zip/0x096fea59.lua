local fn = _gn(0xFE26E4609B1C3772)
--- This function sets metadata of type bool to specified entity.
function Global.DecorSetBool(entity, propertyName, value)
	return _in2(fn, entity, _ts(propertyName), value, _r)
end

local fn = _gn(0xBC864A70AD55E0C1)
--- GET_ITEM_INTERACTION_PROMPT_PROGRESS
function Global.N_0xbc864a70ad55e0c1(ped, inputContext)
	return _in2(fn, ped, _ch(inputContext), _rf)
end

local fn = _gn(0x56A786E87FF53478)
--- _REMOVE_ENTITY_FROM_ENTITY_MASK
function Global.RemoveEntityFromEntityMask(entity)
	return _in2(fn, entity)
end

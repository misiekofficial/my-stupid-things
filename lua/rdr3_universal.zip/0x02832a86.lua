local fn = _gn(0x408CF580C5E96D49)
--- _STOP_* - _TEST_*
-- ```
-- ```
-- NativeDB Introduced: v1355
function Global.SetGunSpinningInventorySlotIdActivate(ped, emoteType)
	return _in2(fn, ped, emoteType)
end

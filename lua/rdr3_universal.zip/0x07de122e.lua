local fn = _gn(0x6843A1AA3A336DFF)
--- DETACH_ANIM_SCENE
function Global.DetachAnimScene(animScene)
	return _in2(fn, animScene)
end

local fn = _gn(0xFA3E3CA8A1DE6D5D)
--- Params: BOOL p3 is always true
function Global.SetWeatherTypeTransition(weatherType1, weatherType2, percentWeather2, enabled)
	return _in2(fn, _ch(weatherType1), _ch(weatherType2), percentWeather2, enabled)
end

local fn = _gn(0x5E420FF293EE5472)
--- _ARE_ALL_AMBIENT_PED_RESERVATIONS_READY
function Global.AreAllAmbientPedReservationsReady()
	return _in2(fn, _ri)
end

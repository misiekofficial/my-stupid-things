local fn = _gn(0xE41885592B08B097)
--- TASK_VEHICLE_AIM_AT_PED
function Global.TaskVehicleAimAtPed(ped, target)
	return _in2(fn, ped, target)
end

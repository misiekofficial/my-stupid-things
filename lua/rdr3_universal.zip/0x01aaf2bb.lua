local fn = _gn(0xDD1E1393D966D39A)
--- _GET_VEHICLE_DOORS_LOCKED_FOR_TEAM
function Global.N_0xdd1e1393d966d39a(vehicle, team)
	return _in2(fn, vehicle, team, _ri)
end

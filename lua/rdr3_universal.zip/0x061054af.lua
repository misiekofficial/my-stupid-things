local fn = _gn(0xFFE9C53DEEA3DB0B)
--- 0xFFE9C53DEEA3DB0B
function Global.N_0xffe9c53deea3db0b(p0, p1, x, y, z, isSrlLoaded, p6)
	return _in2(fn, p0, p1, x, y, z, isSrlLoaded, p6, _ri)
end

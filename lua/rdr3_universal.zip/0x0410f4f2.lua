local fn = _gn(0x112BCA290D2EB53C)
--- Only used in R* SP Scripts
function Global.N_0x112bca290d2eb53c(inventoryId, p1)
	return _in2(fn, inventoryId, _ch(p1), _i, _i, _i, _i, _i, _i, _r)
end

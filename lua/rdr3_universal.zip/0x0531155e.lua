local fn = _gn(0x08FDC6F796E350D1)
--- CLEAR_GPS_PLAYER_WAYPOINT
function Global.ClearGpsPlayerWaypoint()
	return _in2(fn)
end

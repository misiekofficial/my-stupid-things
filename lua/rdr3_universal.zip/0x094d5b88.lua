local fn = _gn(0x4248AB2EEB3C75AD)
--- _SET_TRANSPORT_*
function Global.N_0x4248ab2eeb3c75ad(transportEntity, ped, p2)
	return _in2(fn, transportEntity, ped, p2)
end

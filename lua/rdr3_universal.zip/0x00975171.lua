local fn = _gn(0x2F050A3FF8738245)
--- COUNT_PARTICIPANT_BITS
function Global.CountParticipantBits(value)
	return _in2(fn, _ii(value) --[[ may be optional ]], _ri)
end

local fn = _gn(0xBA958F68031DDBFC)
--- Returns Coords of vStation
-- p0 - NET_TRAIN_MANAGER_GET_TRAIN_STATION_DATA
-- _GET_P* - _GET_T*
function Global.N_0xba958f68031ddbfc(trackIndex, stationIndex)
	return _in2(fn, trackIndex, stationIndex, _rv)
end

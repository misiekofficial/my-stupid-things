local fn = _gn(0xB292203008EBBAAC)
--- 0xB292203008EBBAAC
function Global.N_0xb292203008ebbaac(p0)
	return _in2(fn, p0, _ri)
end

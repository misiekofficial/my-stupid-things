local fn = _gn(0x1854217C640B39EC)
--- _SET_PED_DEFENSIVE_SPHERE_ATTACHED_TO_ENTITY
function Global.SetPedDefensiveSphereAttachedToEntity(ped, entity, x, y, z, radius, p6, p7)
	return _in2(fn, ped, entity, x, y, z, radius, p6, p7)
end

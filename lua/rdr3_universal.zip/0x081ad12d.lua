local fn = _gn(0x7FEE4F07C54B6B3C)
--- Example:
-- char displayName[64];
-- if (_NETWORK_GET_DISPLAY_NAME_FROM_HANDLE(handle, displayName))
-- {
-- // use displayName
-- }
function Global.NetworkGetDisplayNameFromHandle(displayName)
	return _in2(fn, _i, _ts(displayName), _ri)
end

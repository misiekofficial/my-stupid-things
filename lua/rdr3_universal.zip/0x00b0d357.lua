local fn = _gn(0xA80FF73F772ACF6A)
--- SET_WANTED_SCORE
function Global.N_0xa80ff73f772acf6a(player, intensity)
	return _in2(fn, player, intensity)
end

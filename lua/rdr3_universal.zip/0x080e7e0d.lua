local fn = _gn(0x89023FBBF9200E9F)
--- GET_NETWORK_TIME_ACCURATE
function Global.GetNetworkTimeAccurate()
	return _in2(fn, _ri)
end

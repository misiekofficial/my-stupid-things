local fn = _gn(0xC0258742B034DFAF)
--- _SET_AMBIENT_ANIMAL_DENSITY_MULTIPLIER_THIS_FRAME
function Global.N_0xc0258742b034dfaf(multiplier)
	return _in2(fn, multiplier)
end

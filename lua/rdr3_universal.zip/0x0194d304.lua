local fn = _gn(0xFE99B66D079CF6BC)
--- DISABLE_CONTROL_ACTION
function Global.DisableControlAction(control, action, disableRelatedActions)
	return _in2(fn, control, _ch(action), disableRelatedActions)
end

local fn = _gn(0xDBDF80673BBA3D65)
--- Note: this native was added in build 1491.50
-- ```
-- ```
-- NativeDB Introduced: v1491
function Global.N_0xdbdf80673bba3d65(p0)
	return _in2(fn, p0, _r)
end

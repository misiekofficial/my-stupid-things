local fn = _gn(0x1F471B79ACC98BEF)
--- _SPACTIONPROXY_GET_NEXT_PENDING_BUY_ACTION
function Global.SpactionproxyGetNextPendingBuyAction(data)
	return _in2(fn, _ii(data) --[[ may be optional ]], _r)
end

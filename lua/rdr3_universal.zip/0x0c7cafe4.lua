local fn = _gn(0x42688E94E96FD9B4)
--- If targetPed is set to 0 the ped motivationState affects everyone
function Global.N_0x42688e94e96fd9b4(ped, motivationState, targetPed)
	return _in2(fn, ped, motivationState, targetPed, _rf)
end

local fn = _gn(0xC29996A337BDD099)
--- _DOES_TRAIN_EXIST_ON_TRACK
function Global.DoesTrainExistOnTrack(trackIndex)
	return _in2(fn, trackIndex, _ri)
end

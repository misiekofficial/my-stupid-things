local fn = _gn(0x5FFE9B4144F9712F)
--- SET_LOCAL_PLAYER_AS_GHOST
function Global.SetLocalPlayerAsGhost(toggle)
	return _in2(fn, toggle)
end

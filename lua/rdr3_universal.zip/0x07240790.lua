local fn = _gn(0xC70041408E16BE2E)
--- _DATABINDING_WRITE_DATA_POSSE_ID
function Global.N_0xc70041408e16be2e(p0, p1, posseId)
	return _in2(fn, p0, _ts(p1), posseId)
end

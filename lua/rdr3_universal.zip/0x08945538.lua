local fn = _gn(0x5CA6BBD4A7D8145E)
--- _GET_PLAYER_HUNTING_WAGON
function Global.N_0x5ca6bbd4a7d8145e(player)
	return _in2(fn, player, _ri)
end

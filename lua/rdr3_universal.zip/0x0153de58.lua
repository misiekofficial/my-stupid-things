local fn = _gn(0x356088527D9EBAAD)
--- TASK_REVIVE_TARGET
function Global.TaskReviveTarget(ped, reviver, tool)
	return _in2(fn, ped, reviver, _ch(tool))
end

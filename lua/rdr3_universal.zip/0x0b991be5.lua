local fn = _gn(0xB43163388484CC87)
--- _UILOG_ADD_OR_UPDATE_OBJECTIVE
function Global.LogAddOrUpdateObjective(p0, p1, p2, p3, p4, p5, p6)
	return _in2(fn, p0, _ch(p1), _ch(p2), _ts(p3), p4, p5, p6)
end

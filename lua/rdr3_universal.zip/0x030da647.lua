local fn = _gn(0xF9ACF4A08098EA25)
--- SPECIAL_FUNCTION_DO_NOT_USE
function Global.SpecialFunctionDoNotUse(ped, p1)
	return _in2(fn, ped, p1)
end

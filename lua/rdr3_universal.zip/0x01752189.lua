local fn = _gn(0xEB2BFE5D009F0331)
--- _SET_PED_(A?)*
-- ```
-- ```
-- NativeDB Introduced: v1232
function Global.SetPedDefensiveAreaToAngledArea(ped, x1, y1, z1, x2, y2, z2, p7, p8, p9, entity, p11)
	return _in2(fn, ped, x1, y1, z1, x2, y2, z2, p7, p8, p9, entity, p11)
end

local fn = _gn(0x31C70A716CAE1FEE)
--- _GET_PERSCHAR_PED_INDEX
function Global.GetPerscharPedIndex(persChar)
	return _in2(fn, persChar, _ri)
end

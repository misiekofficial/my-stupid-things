local fn = _gn(0xD7ECC25E176ECBA5)
--- GET_PLAYER_CURRENT_STEALTH_NOISE
function Global.GetPlayerCurrentStealthNoise(player)
	return _in2(fn, player, _rf)
end

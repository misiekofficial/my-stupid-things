local fn = _gn(0x789DABD18E9024DB)
--- _SET_PED_GRAPPLE_FLAG
function Global.N_0x789dabd18e9024db(ped, flag, enable)
	return _in2(fn, ped, flag, enable)
end

local fn = _gn(0xC08DFF658B2E51DB)
--- 0xC08DFF658B2E51DB
function Global.N_0xc08dff658b2e51db(p0)
	return _in2(fn, p0, _ri)
end

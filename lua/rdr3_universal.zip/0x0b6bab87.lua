local fn = _gn(0x007BD043587F7C82)
--- _IS_PICKUP_TYPE_VALID
function Global.IsPickupTypeValid(pickupHash)
	return _in2(fn, _ch(pickupHash), _ri)
end

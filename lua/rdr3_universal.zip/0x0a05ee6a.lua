local fn = _gn(0xD43D95C7A869447F)
--- TASK_SEEK_COVER_TO_COVER_POINT
function Global.TaskSeekCoverToCoverPoint(ped, p1, p2, p3, p4, p5, p6, p7, p8)
	return _in2(fn, ped, p1, p2, p3, p4, p5, p6, p7, p8)
end

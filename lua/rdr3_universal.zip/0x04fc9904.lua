local fn = _gn(0x31167ED4324B758D)
--- _GET_PED_ID_RANGE
function Global.N_0x31167ed4324b758d(ped)
	return _in2(fn, ped, _rf)
end

local fn = _gn(0xF6D9E1F3560CBF8E)
--- _REQUEST_META_PED_COMPONENT
function Global.N_0xf6d9e1f3560cbf8e(metaPedType, p1, p2, p3, p4)
	return _in2(fn, metaPedType, p1, p2, p3, p4, _ri)
end

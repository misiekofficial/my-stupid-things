local fn = _gn(0xDB5B9A474148F699)
--- _DATABINDING_ADD_UI_ITEM_LIST_FROM_PATH
function Global.DatabindingAddUiItemListFromPath(p0, p1)
	return _in2(fn, _ts(p0), _ts(p1), _ri)
end

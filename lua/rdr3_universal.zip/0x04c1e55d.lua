local fn = _gn(0x164CECC59E70DF86)
--- _IS_TRACKED_PED_VISIBILITY_PERCENTAGE_NOT_LESS_THAN
function Global.IsTrackedPedVisibilityPercentageNotLessThan(ped, percent)
	return _in2(fn, ped, percent, _ri)
end

local fn = _gn(0x140B3CB1D424A945)
--- weaponHash can also be -1
function Global.N_0x140b3cb1d424a945(ped, weaponHash)
	return _in2(fn, ped, _ch(weaponHash))
end

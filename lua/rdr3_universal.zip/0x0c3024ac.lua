local fn = _gn(0x4CC5F2FC1332577F)
--- https://github.com/femga/rdr3_discoveries/tree/master/graphics/HUD/hud_presets
function Global.N_0x4cc5f2fc1332577f(component)
	return _in2(fn, _ch(component))
end

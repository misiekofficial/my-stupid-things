local fn = _gn(0x8E8A2369F48EC839)
--- EVENTS_UI_POP_MESSAGE
function Global.EventsUiPopMessage(hash)
	return _in2(fn, _ch(hash))
end

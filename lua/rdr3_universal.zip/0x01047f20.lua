local fn = _gn(0x641351E9AD103890)
--- 0x641351E9AD103890
function Global.N_0x641351e9ad103890(p0, p1)
	return _in2(fn, p0, p1)
end

local fn = _gn(0x3C606747B23E497B)
--- range:
-- enum eCombatRange
-- {
-- CR_NEAR,
-- CR_MEDIUM,
-- CR_FAR,
-- CR_VERY_FAR
-- };
function Global.SetPedCombatRange(ped, range)
	return _in2(fn, ped, range)
end

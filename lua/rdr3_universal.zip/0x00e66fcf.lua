local fn = _gn(0x8C13DB96497B7ABF)
--- TAN
function Global.Tan(p0)
	return _in2(fn, p0, _rf)
end

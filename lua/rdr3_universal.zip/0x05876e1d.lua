local fn = _gn(0x8E462DB1EAA9C47C)
--- 0x8E462DB1EAA9C47C
function Global.N_0x8e462db1eaa9c47c(player)
	return _in2(fn, player, _r)
end

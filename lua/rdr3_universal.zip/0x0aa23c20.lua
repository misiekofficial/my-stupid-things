local fn = _gn(0xBDBACB52A03CC760)
--- UPDATE_LIGHTS_ON_ENTITY
function Global.UpdateLightsOnEntity(entity)
	return _in2(fn, entity)
end

local fn = _gn(0x437C08DB4FEBE2BD)
--- _SET_PED_BLACKBOARD_FLOAT
function Global.SetPedBlackboardFloat(ped, variableName, value, removeTimer)
	return _in2(fn, ped, _ts(variableName), value, removeTimer)
end

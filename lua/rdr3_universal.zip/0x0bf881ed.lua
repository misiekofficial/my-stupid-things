local fn = _gn(0x002AAC783ED323ED)
--- 0x002AAC783ED323ED
function Global.N_0x002aac783ed323ed(p0, p1)
	return _in2(fn, p0, p1)
end

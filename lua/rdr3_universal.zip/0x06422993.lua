local fn = _gn(0x619E63980BFC0096)
--- IS_PED_ENTERING_TRANSPORT
function Global.IsPedEnteringTransport(ped, transportEntity, p2)
	return _in2(fn, ped, transportEntity, p2, _ri)
end

local fn = _gn(0xF0FE8E790BFEB5BB)
--- Max level is 5.
function Global.N_0xf0fe8e790bfeb5bb(player, level)
	return _in2(fn, player, level)
end

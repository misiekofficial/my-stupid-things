local fn = _gn(0x3E2FDDBE435A8787)
--- _PEDSHOT_PREVIOUS_PERSONA_PHOTO_DATA_CLEANUP
function Global.PedshotPreviousPersonaPhotoDataCleanup()
	return _in2(fn)
end

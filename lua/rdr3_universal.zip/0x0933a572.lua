local fn = _gn(0x6818D1A194E29983)
--- _GET_SCRIPT_BRAIN_ENTITY
function Global.N_0x6818d1a194e29983()
	return _in2(fn, _ri)
end

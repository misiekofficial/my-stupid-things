local fn = _gn(0x48E4C137A71C2688)
--- SET_VEHICLE_ENGINE_CAN_DEGRADE
function Global.SetVehicleEngineCanDegrade(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

local fn = _gn(0xDF947FE0D551684E)
--- 0xDF947FE0D551684E
function Global.N_0xdf947fe0d551684e(ped, p1)
	return _in2(fn, ped, _ts(p1), _r)
end

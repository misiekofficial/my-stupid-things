local fn = _gn(0xC3ADF4880784FA9C)
--- _TELEMETRY_GUN_LOCKER_WEAPON_STORED
function Global.TelemetryGunLockerWeaponStored(p0)
	return _in2(fn, _ch(p0))
end

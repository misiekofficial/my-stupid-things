local fn = _gn(0x4AF1D73861212F52)
--- TASK_AIM_AT_COORD
function Global.TaskAimAtCoord(ped, p1, p2, p3, p4, p5, p6)
	return _in2(fn, ped, p1, p2, p3, p4, p5, p6)
end

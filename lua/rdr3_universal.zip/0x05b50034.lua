local fn = _gn(0x59767C5A7A9AE6DA)
--- REQUEST_IPL_HASH
function Global.RequestImap(iplHash)
	return _in2(fn, _ch(iplHash))
end

local fn = _gn(0x6EF4E31B4D5D2DA0)
--- _DISASSOCIATE_PROP_FROM_SCENARIO
function Global.N_0x6ef4e31b4d5d2da0(scenario, propName)
	return _in2(fn, scenario, _ts(propName), _ri)
end

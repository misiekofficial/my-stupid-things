local fn = _gn(0xA4550FE9C512E3DD)
--- _INVENTORY_GET_INVENTORY_ITEM_DESCRIPTION_HASH
function Global.InventoryGetInventoryItemDescriptionHash(item)
	return _in2(fn, _ch(item), _ri)
end

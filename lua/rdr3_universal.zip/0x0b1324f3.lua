local fn = _gn(0xEF259AA1E097E0AD)
--- 0xEF259AA1E097E0AD
function Global.N_0xef259aa1e097e0ad(entity, p1)
	return _in2(fn, entity, p1)
end

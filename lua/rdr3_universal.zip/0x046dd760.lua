local fn = _gn(0x652712478F1721F4)
--- SET_VEHICLE_PROVIDES_COVER
function Global.SetVehicleProvidesCover(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

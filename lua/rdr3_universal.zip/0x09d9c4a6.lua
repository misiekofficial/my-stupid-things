local fn = _gn(0x6C8065A3B780185B)
--- SET_AMBIENT_VOICE_NAME
function Global.SetAmbientVoiceName(ped, name)
	return _in2(fn, ped, _ts(name))
end

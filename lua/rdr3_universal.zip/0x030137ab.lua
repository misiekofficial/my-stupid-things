local fn = _gn(0x423C6B1F3786D28B)
--- 0x423C6B1F3786D28B
function Global.N_0x423c6b1f3786d28b(p0, p1)
	return _in2(fn, p0, p1)
end

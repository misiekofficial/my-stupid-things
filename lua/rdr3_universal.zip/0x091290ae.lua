local fn = _gn(0x10BD227A753B0D84)
--- NativeDB Introduced: v1436
function Global.NetworkGetTunableCloudCrc()
	return _in2(fn, _ri)
end

local fn = _gn(0x632BE8D84846FA56)
--- Zooms in the gameplay camera to the next zoom level?
-- USE_* - WAS_*
function Global.N_0x632be8d84846fa56()
	return _in2(fn)
end

local fn = _gn(0x0556C784FA056628)
--- Creates stream and returns streamId handle to be used with PLAY_STREAM_* natives
-- https://github.com/femga/rdr3_discoveries/tree/master/audio/create_stream
function Global.N_0x0556c784fa056628(streamName, soundSet)
	return _in2(fn, _ts(streamName), _ts(soundSet), _ri)
end

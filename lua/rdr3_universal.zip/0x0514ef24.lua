local fn = _gn(0x5463C962BC7777C3)
--- Returns loot state
-- enum eLootState
-- {
-- LAP_NONE,
-- LAP_RESUMING,
-- LAP_GETTING_ON_FOOT,
-- LAP_DISTANT_NAV,
-- LAP_CHOOSING_ACTION,
-- LAP_APPROACHING,
-- LAP_ENTERING,
-- LAP_LOOTING,
-- LAP_EXITING
-- };
-- _POSSE_* - _REGISTER_HATED*
function Global.N_0x5463c962bc7777c3(ped, p1, p3, p4)
	return _in2(fn, ped, p1, _i, p3, p4, _ri)
end

local fn = _gn(0x0C093C1787F18519)
--- _INVENTORY_GET_INVENTORY_ITEM_INSPECTION_INFO
function Global.InventoryGetInventoryItemInspectionInfo(item, info)
	return _in2(fn, _ch(item), _ii(info) --[[ may be optional ]], _ri)
end

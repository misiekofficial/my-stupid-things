local fn = _gn(0x9ED3108D6847760A)
--- SET_NETWORK_ID_STOP_CLONING
function Global.N_0x9ed3108d6847760a(networkId, bStopCloning)
	return _in2(fn, networkId, bStopCloning)
end

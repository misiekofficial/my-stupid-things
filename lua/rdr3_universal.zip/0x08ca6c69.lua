local fn = _gn(0x1E8099F449ABB0BA)
--- 0x1E8099F449ABB0BA
function Global.N_0x1e8099f449abb0ba(p0)
	return _in2(fn, p0, _ri)
end

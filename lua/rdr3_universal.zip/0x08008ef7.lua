local fn = _gn(0xC163DAC52AC975D3)
--- _SET_PED_TARGET_ACTION_DISABLE_FLAG
function Global.SetPedTargetActionDisableFlag(ped, actionDisableFlag)
	return _in2(fn, ped, actionDisableFlag)
end

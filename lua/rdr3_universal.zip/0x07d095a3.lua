local fn = _gn(0x8974647ED222EA5F)
--- enum eScriptWaterTestResult
-- {
-- SCRIPT_WATER_TEST_RESULT_NONE,
-- SCRIPT_WATER_TEST_RESULT_WATER,
-- SCRIPT_WATER_TEST_RESULT_BLOCKED,
-- };
function Global.TestProbeAgainstAllWater(x1, y1, z1, x2, y2, z2, flags, intersectionPos)
	return _in2(fn, x1, y1, z1, x2, y2, z2, flags, _v, _ri)
end

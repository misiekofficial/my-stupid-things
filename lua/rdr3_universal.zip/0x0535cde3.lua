local fn = _gn(0x9F348DE670423460)
--- 0x9F348DE670423460
function Global.N_0x9f348de670423460(p0)
	return _in2(fn, p0)
end

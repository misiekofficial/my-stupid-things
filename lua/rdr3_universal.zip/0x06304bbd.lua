local fn = _gn(0x825F6DD559A0895B)
--- _GET_STAMINA_DEPLETION_MULTIPLIER
function Global.GetStaminaDepletionMultiplier(ped)
	return _in2(fn, ped, _rf)
end

local fn = _gn(0xAC6153A0722F524C)
--- Returns CGameConfig->ConfigOnlineServices->RosTitleName (see gameconfig.xml)
function Global.NetworkGetRosTitleName()
	return _in2(fn, _s)
end

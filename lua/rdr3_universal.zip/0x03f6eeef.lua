local fn = _gn(0x10C70A515BC03707)
--- GET_NUM_META_PED_OUTFITS
function Global.N_0x10c70a515bc03707(ped)
	return _in2(fn, ped, _ri)
end

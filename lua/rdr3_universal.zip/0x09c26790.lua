local fn = _gn(0x724CB89D35B283D0)
--- _GET_HASH_OF_THREAD
function Global.GetHashOfThread(threadId)
	return _in2(fn, threadId, _ri)
end

local fn = _gn(0x95CBC65780DE7EB1)
--- IS_PED_FULLY_ON_MOUNT
function Global.N_0x95cbc65780de7eb1(ped, p1)
	return _in2(fn, ped, p1, _ri)
end

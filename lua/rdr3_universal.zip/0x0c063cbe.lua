local fn = _gn(0xBFFF81E12A745A5F)
--- nullsub, doesn't do anything
function Global.N_0xbfff81e12a745a5f()
	return _in2(fn)
end

local fn = _gn(0x27F9D613092159CF)
--- REMOVE_ALL_PICKUPS_OF_TYPE
function Global.RemoveAllPickupsOfType(pickupHash)
	return _in2(fn, _ch(pickupHash))
end

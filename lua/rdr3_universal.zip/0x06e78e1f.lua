local fn = _gn(0x7C9E45A4CED2E8DA)
--- Params: 1.0f will make balloon hover
function Global.N_0x7c9e45a4ced2e8da(balloon, p1)
	return _in2(fn, balloon, p1)
end

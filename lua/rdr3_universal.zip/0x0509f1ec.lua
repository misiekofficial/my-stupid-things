local fn = _gn(0xFB680A9B33D0EDBE)
--- _DISABLE_*
function Global.N_0xfb680a9b33d0edbe(p0)
	return _in2(fn, p0)
end

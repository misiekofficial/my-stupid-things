local fn = _gn(0x918990BD9CE08582)
--- GET_ALLOW_DUAL_WIELD
function Global.N_0x918990bd9ce08582(ped)
	return _in2(fn, ped, _ri)
end

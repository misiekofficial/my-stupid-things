local fn = _gn(0xD090ABEF4D6A7D96)
--- Same as _HAS_PROP_SET_LOADED
function Global.HasPropSetLoaded_2(hash)
	return _in2(fn, _ch(hash), _ri)
end

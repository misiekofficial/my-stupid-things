local fn = _gn(0xEFC4303DDC6E60D3)
--- _IS_PED_LEADING_HORSE
function Global.IsPedLeadingHorse(ped)
	return _in2(fn, ped, _ri)
end

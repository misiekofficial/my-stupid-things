local fn = _gn(0x0EABF182FBB63D72)
--- Seems to disable IK on ped
function Global.N_0x0eabf182fbb63d72(ped, p1, p2)
	return _in2(fn, ped, p1, p2)
end

local fn = _gn(0x75415EE0CB583760)
--- attributeIndex: see SET_ATTRIBUTE_BASE_RANK
function Global.AddAttributePoints(ped, attributeIndex, p2)
	return _in2(fn, ped, attributeIndex, p2)
end

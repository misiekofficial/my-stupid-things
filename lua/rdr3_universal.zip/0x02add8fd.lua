local fn = _gn(0xCEEC64BD27A59312)
--- Hardcoded to return true.
function Global.N_0xceec64bd27a59312(p0)
	return _in2(fn, p0, _ri)
end

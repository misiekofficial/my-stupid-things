local fn = _gn(0x1FDA57E8908F2609)
--- 0x1FDA57E8908F2609
function Global.N_0x1fda57e8908f2609(player, ped, useSteerassist)
	return _in2(fn, player, ped, useSteerassist)
end

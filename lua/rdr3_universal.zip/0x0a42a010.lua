local fn = _gn(0xB65927F861E7AE39)
--- 0xB65927F861E7AE39
function Global.N_0xb65927f861e7ae39(ped, p1)
	return _in2(fn, ped, p1, _r)
end

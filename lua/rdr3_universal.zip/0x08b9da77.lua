local fn = _gn(0x56E58D4D118FB45E)
--- Can be used to get a peds foliage raw height: variableName = FoliageHeight
function Global.N_0x56e58d4d118fb45e(ped, variableName)
	return _in2(fn, ped, _ts(variableName), _rf)
end

local fn = _gn(0x6D58167F62238284)
--- 0x6D58167F62238284
function Global.N_0x6d58167f62238284(vehicle)
	return _in2(fn, vehicle, _rf)
end

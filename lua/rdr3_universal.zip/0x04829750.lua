local fn = _gn(0xB93A769B8B726950)
--- Used in Script Function NET_CAMP_CLIENT_UPDATE_PED_ROLE_STATE_SHOP: hash exists! Playing hash
function Global.N_0xb93a769b8b726950(ped, p1)
	return _in2(fn, ped, _ch(p1))
end

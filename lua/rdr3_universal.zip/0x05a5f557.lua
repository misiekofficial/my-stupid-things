local fn = _gn(0xB5DED7B65C604FDF)
--- _IS_DOOR_REGISTERED_WITH_NETWORK
function Global.IsDoorRegisteredWithNetwork(doorHash)
	return _in2(fn, _ch(doorHash), _ri)
end

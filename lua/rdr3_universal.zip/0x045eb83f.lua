local fn = _gn(0x2238EC3EC631AB1F)
--- Returns true if GtaThread+0x77C is equal to 1.
function Global.BgIsExitflagSet()
	return _in2(fn, _r)
end

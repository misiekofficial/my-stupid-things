local fn = _gn(0x8D1249BD28791878)
--- _UI_FEED_POST_GAME_UPDATE_SHARD
function Global.UiFeedPostGameUpdateShard(p2)
	return _in2(fn, _i, _i, p2, _ri)
end

local fn = _gn(0xF336E9F989B3518F)
--- 0xF336E9F989B3518F
function Global.N_0xf336e9f989b3518f(p0)
	return _in2(fn, _ts(p0), _ri)
end

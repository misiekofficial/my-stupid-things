local fn = _gn(0xF5472C80DF2FF847)
--- IS_SCREEN_FADED_OUT
function Global.IsScreenFadedOut()
	return _in2(fn, _r)
end

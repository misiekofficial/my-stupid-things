local fn = _gn(0x35A33783EC3C3448)
--- NativeDB Introduced: v1311
function Global.N_0x35a33783ec3c3448(p0)
	return _in2(fn, p0)
end

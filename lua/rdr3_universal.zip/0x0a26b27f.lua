local fn = _gn(0x390710D2DAFA6BFF)
--- _CLEAR*
function Global.N_0x390710d2dafa6bff(player, p1)
	return _in2(fn, player, p1)
end

local fn = _gn(0xEB1A4DD8352EC828)
--- NETWORK_GET_ROPE_ID_FROM_NETWORK_ID
function Global.NetworkGetRopeIdFromNetworkId(netId)
	return _in2(fn, netId, _ri)
end

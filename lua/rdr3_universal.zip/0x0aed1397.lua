local fn = _gn(0xB096547D61868254)
--- _BOUNTY_REQUEST_BECOME_TARGET_OF_CHARACTER_BOUNTY_HUNT
function Global.N_0xb096547d61868254(outRpcGuid)
	return _in2(fn, _ii(outRpcGuid) --[[ may be optional ]], _ri)
end

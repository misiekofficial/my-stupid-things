local fn = _gn(0xDF93973251FB2CA5)
--- Name could potentially be inaccurate.
-- Used in Script Function HORSE_SETUP_PLAYER_HORSE_ATTRIBUTES (p1 = true)
-- _SET_PLAYER_L* - _SET_PLAYER_M*
function Global.SetPlayerMountStateActive(player, active)
	return _in2(fn, player, active)
end

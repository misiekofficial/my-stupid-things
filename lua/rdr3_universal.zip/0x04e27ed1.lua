local fn = _gn(0xAAB86462966168CE)
--- Related to _0x704C908E9C405136 for component loading
-- _S*
function Global.N_0xaab86462966168ce(ped, isMP)
	return _in2(fn, ped, isMP, _ri)
end

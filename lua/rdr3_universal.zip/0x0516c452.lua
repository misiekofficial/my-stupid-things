local fn = _gn(0x73348402566ECB6E)
--- Up to eight coordinates may be revealed per frame
function Global.N_0x73348402566ecb6e(x, y, z, p3)
	return _in2(fn, x, y, z, _ch(p3))
end

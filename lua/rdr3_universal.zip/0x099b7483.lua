local fn = _gn(0x3DF1A0A58498E209)
--- NativeDB Introduced: v1436
function Global.N_0x3df1a0a58498e209(object, p1)
	return _in2(fn, object, p1)
end

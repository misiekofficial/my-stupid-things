local fn = _gn(0x19B2C7A6C34FAD54)
--- 0x19B2C7A6C34FAD54
function Global.N_0x19b2c7a6c34fad54(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

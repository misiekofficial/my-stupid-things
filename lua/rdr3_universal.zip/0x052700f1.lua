local fn = _gn(0xC932F57F31EA9152)
--- HAS_PLAYER_BEEN_SPOTTED_IN_STOLEN_VEHICLE
function Global.HasPlayerBeenSpottedInStolenVehicle(player)
	return _in2(fn, player, _r)
end

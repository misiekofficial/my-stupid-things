local fn = _gn(0x919AF2D93E9AA89D)
--- 0x919AF2D93E9AA89D
function Global.N_0x919af2d93e9aa89d(player)
	return _in2(fn, player, _r)
end

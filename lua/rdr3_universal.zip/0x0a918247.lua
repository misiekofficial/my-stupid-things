local fn = _gn(0xF92FA8890DECECF6)
--- _REMOVE_E* - _REMOVE_R*
function Global.RemoveBoundsFromAggregateVolume(volume, aggregate)
	return _in2(fn, volume, aggregate)
end

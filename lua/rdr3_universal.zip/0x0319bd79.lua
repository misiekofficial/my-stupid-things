local fn = _gn(0x6B34BE961F639E21)
--- 0x6B34BE961F639E21
function Global.N_0x6b34be961f639e21(trackIndex, p1)
	return _in2(fn, trackIndex, p1)
end

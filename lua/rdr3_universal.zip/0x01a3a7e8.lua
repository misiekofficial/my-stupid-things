local fn = _gn(0x857ACB0AB4BD0D55)
--- _IS_ENTITY_ON_TRAIN_TRACK
function Global.IsEntityOnTrainTrack(entity)
	return _in2(fn, entity, _ri)
end

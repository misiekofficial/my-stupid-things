local fn = _gn(0x462C687BEA254BD9)
--- COUNT_PLAYER_BITS
function Global.N_0x462c687bea254bd9(value)
	return _in2(fn, _ii(value) --[[ may be optional ]], _ri)
end

local fn = _gn(0xF239400E16C23E08)
--- SET_CONTROL_SHAKE_SUPPRESSED_ID
function Global.SetControlShakeSuppressedId(control, uniqueId)
	return _in2(fn, control, uniqueId)
end

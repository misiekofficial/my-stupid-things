local fn = _gn(0x4E23CD07BD161E06)
--- ADD_CUSTOM_FORMATION_LOCATION
function Global.AddCustomFormationLocation(groupId, x, y, z, position)
	return _in2(fn, groupId, x, y, z, position)
end

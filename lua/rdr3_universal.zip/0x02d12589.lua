local fn = _gn(0x3B6405E8AB34A907)
--- SET_PED_VISUAL_FIELD_CENTER_ANGLE
function Global.SetPedVisualFieldCenterAngle(ped, angle)
	return _in2(fn, ped, angle)
end

local fn = _gn(0x4D89D607CB3DD1D2)
--- SET_OBJECT_ALLOW_LOW_LOD_BUOYANCY
function Global.SetObjectAllowLowLodBuoyancy(object, toggle)
	return _in2(fn, object, toggle)
end

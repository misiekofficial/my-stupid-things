local fn = _gn(0xF20B18A330E6DB5C)
--- _NETWORK_SESSION_TRANSITION_TO_SESSION
function Global.NetworkSessionTransitionToSession(sessionRequestId)
	return _in2(fn, _ii(sessionRequestId) --[[ may be optional ]], _ri)
end

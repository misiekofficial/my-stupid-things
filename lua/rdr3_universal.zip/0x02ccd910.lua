local fn = _gn(0x30146C25686B7836)
--- 0x30146C25686B7836
function Global.N_0x30146c25686b7836(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

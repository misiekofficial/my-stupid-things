local fn = _gn(0xC568B1A0F17C7025)
--- _ITEMDATABASE_GET_SHOP_INVENTORIES_ITEMS_COUNT
function Global.ItemdatabaseGetShopInventoriesItemsCount(p0)
	return _in2(fn, p0, _ri)
end

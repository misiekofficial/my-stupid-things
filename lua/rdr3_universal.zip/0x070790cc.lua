local fn = _gn(0x12E981D53B07BF48)
--- _BOUNTY_REQUEST_ESCAPED_CHARACTER_BOUNTY_HUNT
function Global.N_0x12e981d53b07bf48(outRpcGuid)
	return _in2(fn, _ii(outRpcGuid) --[[ may be optional ]], _ri)
end

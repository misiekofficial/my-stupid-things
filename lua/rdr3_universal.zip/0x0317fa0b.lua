local fn = _gn(0x0EDEC3C276198689)
--- Returns the network ID of the given ped.
function Global.PedToNet(ped)
	return _in2(fn, ped, _ri)
end

local fn = _gn(0xA586FBEB32A53DBB)
--- SPAWNPOINTS_IS_SEARCH_COMPLETE
function Global.SpawnpointsIsSearchComplete()
	return _in2(fn, _ri)
end

local fn = _gn(0xBD94CECFB2D65119)
--- 0xBD94CECFB2D65119
function Global.N_0xbd94cecfb2d65119(p0, p1, p2, p3, p4, p5)
	return _in2(fn, p0, p1, p2, p3, p4, p5)
end

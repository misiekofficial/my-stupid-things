local fn = _gn(0x5A498FCA232F71E1)
--- _SET_SPECIAL_ABILITY_MULTIPLIER
function Global.N_0x5a498fca232f71e1(player, multiplier)
	return _in2(fn, player, multiplier)
end

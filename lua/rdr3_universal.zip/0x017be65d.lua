local fn = _gn(0xD389A2549C4EFB30)
--- Returns (collection?) size/index (?)
-- _ITEMDATABASE_GET_(A)* - _ITEMDATABASE_GET_(B)*
function Global.N_0xd389a2549c4efb30(collectionId)
	return _in2(fn, collectionId, _ri)
end

local fn = _gn(0x9F9A829C6751F3C7)
--- https://github.com/Halen84/RDR3-Native-Flags-And-Enums/tree/main/ePlayerResetFlags
-- https://github.com/femga/rdr3_discoveries/tree/master/AI/PLAYER_RESET_FLAGS
function Global.N_0x9f9a829c6751f3c7(player, playerResetFlag, p2)
	return _in2(fn, player, playerResetFlag, p2)
end

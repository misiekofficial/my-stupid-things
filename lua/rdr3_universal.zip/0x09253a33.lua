local fn = _gn(0x2FB0ACADA6A238DD)
--- Returns true if the player is riding a train.
function Global.IsPlayerRidingTrain(player)
	return _in2(fn, player, _r)
end

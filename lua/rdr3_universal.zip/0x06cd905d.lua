local fn = _gn(0x865FEC2FA899F29C)
--- GET_TRACK_INDEX_OF_TRAIN
function Global.N_0x865fec2fa899f29c(train)
	return _in2(fn, train, _ri)
end

local fn = _gn(0x49DADFC4CD808B0A)
--- 0x49DADFC4CD808B0A
function Global.N_0x49dadfc4cd808b0a(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

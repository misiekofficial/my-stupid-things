local fn = _gn(0x74C3B1093728D263)
--- _ITEMDATABASE_FILLOUT_(A)* - _ITEMDATABASE_FILLOUT_(B)*
function Global.N_0x74c3b1093728d263(p0, p1)
	return _in2(fn, p0, p1, _r)
end

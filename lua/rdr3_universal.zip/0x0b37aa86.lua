local fn = _gn(0x38C16A305E8CDC8D)
--- STOP_CONTROL_SHAKE
function Global.StopControlShake(control)
	return _in2(fn, control)
end

local fn = _gn(0x3F892CAF67444AE7)
--- dispatchService: see ENABLE_DISPATCH_SERVICE
function Global.CreateIncident(dispatchService, x, y, z, numUnits, radius, p7, p8)
	return _in2(fn, dispatchService, x, y, z, numUnits, radius, _i, p7, p8, _r)
end

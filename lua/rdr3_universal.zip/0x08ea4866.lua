local fn = _gn(0xA7479FB665361EDB)
--- _SET_SCENARIO_*
function Global.N_0xa7479fb665361edb(p0, p1)
	return _in2(fn, p0, p1)
end

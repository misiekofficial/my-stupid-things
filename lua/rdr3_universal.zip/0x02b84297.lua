local fn = _gn(0x89E005B1662F6E48)
--- 0x89E005B1662F6E48
function Global.N_0x89e005b1662f6e48(player, p1, p2)
	return _in2(fn, player, p1, p2, _r)
end

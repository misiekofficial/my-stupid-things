local fn = _gn(0x1C6CD14A876FFE39)
--- meleeStyles: AR_GRAPPLE_BACK_FROM_BACK, AR_GRAPPLE_MOUNT_FACEDOWN_FROM_FRONT, AR_ALLIGATOR_LEAPKILL, AR_ALLIGATOR_WAIST_AUTOKILL_FRONT
function Global.TaskPutPedDirectlyIntoMelee(ped, meleeTarget, meleeStyle, p3, animBlendRatio, p5, p6)
	return _in2(fn, ped, meleeTarget, _ch(meleeStyle), p3, animBlendRatio, p5, p6)
end

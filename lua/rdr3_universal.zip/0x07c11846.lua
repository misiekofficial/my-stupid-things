local fn = _gn(0x69E181772886F48B)
--- ARE_WITNESSES_ACTIVE
function Global.N_0x69e181772886f48b(player)
	return _in2(fn, player, _ri)
end

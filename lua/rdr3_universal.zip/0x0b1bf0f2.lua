local fn = _gn(0x63E7279D04160477)
--- Used for GUARMA MODE; Enabled: toggle = false, 0; Disabled: toggle = true, 0
-- Hash p1 seems to be unused, always 0
function Global.N_0x63e7279d04160477(toggle, p1)
	return _in2(fn, toggle, _ch(p1))
end

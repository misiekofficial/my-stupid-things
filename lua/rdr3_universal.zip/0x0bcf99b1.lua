local fn = _gn(0xCD356B42C57BFE01)
--- _GET_BEST_* - _GET_CLOSEST_*
-- ```
-- ```
-- NativeDB Introduced: v1355
function Global.GetCorrectKitEmoteTwirlGun(ped, weaponGuid)
	return _in2(fn, ped, _ii(weaponGuid) --[[ may be optional ]], _r)
end

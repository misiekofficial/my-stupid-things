local fn = _gn(0x40AB73092C95B5F5)
--- _EAGLE_EYE_DISABLE_TRACKING_TRAIL
function Global.N_0x40ab73092c95b5f5(entity, trail, p2, p3)
	return _in2(fn, entity, _ts(trail), p2, p3)
end

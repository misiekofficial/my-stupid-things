local fn = _gn(0x73F1E4F6DF26FE30)
--- SET_ENABLE_VEHICLE_SLIPSTREAMING
function Global.N_0x73f1e4f6df26fe30(p0)
	return _in2(fn, p0)
end

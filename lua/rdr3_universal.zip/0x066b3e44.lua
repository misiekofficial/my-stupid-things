local fn = _gn(0x1B5447CF18544B18)
--- DATADICT_GET_ARRAY
function Global.ObjectValueGetArray(key)
	return _in2(fn, _i, _ts(key), _ri)
end

local fn = _gn(0xF66F820909453B8C)
--- SET_ENTITY_COLLISION
function Global.SetEntityCollision(entity, toggle, keepPhysics)
	return _in2(fn, entity, toggle, keepPhysics)
end

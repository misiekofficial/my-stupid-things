local fn = _gn(0x2B32B11520626229)
--- 0x2B32B11520626229
function Global.N_0x2b32b11520626229(p0, p1, p2, p3, p4)
	return _in2(fn, p0, p1, p2, p3, p4, _ri)
end

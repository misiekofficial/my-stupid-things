local fn = _gn(0x55B0ECFD98596624)
--- TASK_PICK_UP_WEAPON
function Global.TaskPickUpWeapon(ped, p1)
	return _in2(fn, ped, p1)
end

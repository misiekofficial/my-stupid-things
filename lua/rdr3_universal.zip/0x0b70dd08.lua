local fn = _gn(0xBAE08F00021BFFB2)
--- _H* - _I*
function Global.HorseAgitate(mount, kickOffRider)
	return _in2(fn, mount, kickOffRider)
end

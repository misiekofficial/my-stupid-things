local fn = _gn(0x87344305778E5415)
--- _SET_DRAFT_VEHICLE_ALLOW_DRAFT_ANIMAL_AUTO_CREATION
function Global.SetDraftVehicleAllowDraftAnimalAutoCreation(vehicle, allow)
	return _in2(fn, vehicle, allow)
end

local fn = _gn(0x2A6D1DAAB9EBB262)
--- 0x2A6D1DAAB9EBB262
function Global.N_0x2a6d1daab9ebb262(p0)
	return _in2(fn, p0, _ri)
end

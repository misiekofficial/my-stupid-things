local fn = _gn(0xD0B0B044112BF424)
--- UPDATE_WANTED_POSITION_THIS_FRAME
function Global.N_0xd0b0b044112bf424(player)
	return _in2(fn, player)
end

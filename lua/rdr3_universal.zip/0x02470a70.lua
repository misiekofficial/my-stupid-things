local fn = _gn(0xFC094EF26DD153FA)
--- _UI_PROMPT_DISABLE_PROMPT_TYPE_THIS_FRAME
function Global.UiPromptDisablePromptTypeThisFrame(p0)
	return _in2(fn, p0)
end

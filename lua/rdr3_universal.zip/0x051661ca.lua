local fn = _gn(0xA6F67BEC53379A32)
--- _REMOVE_PED_BLACKBOARD_BOOL
function Global.N_0xa6f67bec53379a32(ped, variableName)
	return _in2(fn, ped, _ts(variableName))
end

local fn = _gn(0xD7F6781A0ABAF6FB)
--- _NET_TO_ANIM_SCENE
function Global.NetToAnimScene(netId)
	return _in2(fn, netId, _ri)
end

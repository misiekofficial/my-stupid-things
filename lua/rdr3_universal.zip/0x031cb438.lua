local fn = _gn(0x49A8447533308BCF)
--- _VIRTUAL_COLLECTION_SET_INTEREST_INDEX
function Global.VirtualCollectionSetInterestIndex(p0, interestIndex)
	return _in2(fn, p0, interestIndex)
end

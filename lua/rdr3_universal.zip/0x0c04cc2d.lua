local fn = _gn(0x0E17378642156790)
--- _REMOVE_PED_BLACKBOARD_HASH
function Global.N_0x0e17378642156790(ped, variableName)
	return _in2(fn, ped, _ts(variableName))
end

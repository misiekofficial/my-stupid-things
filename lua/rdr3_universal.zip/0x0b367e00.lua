local fn = _gn(0x88AD6CC10D8D35B2)
--- Returns true if calling script owns specified entity
function Global.N_0x88ad6cc10d8d35b2(entity)
	return _in2(fn, entity, _ri)
end

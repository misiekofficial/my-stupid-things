local fn = _gn(0x6FB1DA3CA9DA7D90)
--- PLAY_SOUND_FROM_ENTITY
function Global.PlaySoundFromEntity(audioName, entity, audioRef, isNetwork, p4, p5)
	return _in2(fn, _ts(audioName), entity, _ts(audioRef), isNetwork, p4, p5)
end

local fn = _gn(0x77BA37622E22023B)
--- _GET_SHOP_ITEM_COMPONENT_AT_INDEX
function Global.N_0x77ba37622e22023b(ped, index, p2)
	return _in2(fn, ped, index, p2, _i, _i, _ri)
end

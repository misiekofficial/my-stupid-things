local fn = _gn(0x195AEEB13CEFE2EE)
--- TASK_VEHICLE_GOTO_NAVMESH
function Global.TaskVehicleGotoNavmesh(ped, vehicle, x, y, z, speed, behaviorFlag, stoppingRange)
	return _in2(fn, ped, vehicle, x, y, z, speed, behaviorFlag, stoppingRange)
end

local fn = _gn(0xC6258F41D86676E0)
--- coreIndex:
-- enum eAttributeCore
-- {
-- ATTRIBUTE_CORE_HEALTH,
-- ATTRIBUTE_CORE_STAMINA,
-- ATTRIBUTE_CORE_DEADEYE
-- };
function Global.N_0xc6258f41d86676e0(ped, coreIndex, value)
	return _in2(fn, ped, coreIndex, value)
end

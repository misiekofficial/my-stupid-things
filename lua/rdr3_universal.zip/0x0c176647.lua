local fn = _gn(0xD2866CBA797E872E)
--- NativeDB Introduced: v1232
function Global.IsAmmoSilent(ammoHash)
	return _in2(fn, _ch(ammoHash), _r)
end

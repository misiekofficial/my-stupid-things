local fn = _gn(0xFB4891BD7578CDC1)
--- _IS_META_PED_USING_COMPONENT
function Global.N_0xfb4891bd7578cdc1(ped, component)
	return _in2(fn, ped, _ch(component), _ri)
end

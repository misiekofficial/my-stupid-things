local fn = _gn(0x081FB9D6422F804C)
--- doorId: see SET_VEHICLE_DOOR_SHUT
function Global.SetDoorAllowedToBeBrokenOff(vehicle, doorId, isBreakable)
	return _in2(fn, vehicle, doorId, isBreakable)
end

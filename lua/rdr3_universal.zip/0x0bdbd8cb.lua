local fn = _gn(0xD4E5C1E93C466127)
--- _IS_ENTITY_UNDERWATER
function Global.IsEntityUnderwater(entity, p1)
	return _in2(fn, entity, p1, _ri)
end

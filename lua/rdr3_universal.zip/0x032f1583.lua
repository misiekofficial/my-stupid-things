local fn = _gn(0xA2116C1E4ED85C24)
--- _SET_PED_*
function Global.N_0xa2116c1e4ed85c24(ped, inverted)
	return _in2(fn, ped, inverted)
end

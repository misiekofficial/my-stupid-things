local fn = _gn(0x58E0B01D45CA7357)
--- 0x58E0B01D45CA7357
function Global.N_0x58e0b01d45ca7357(p0)
	return _in2(fn, p0)
end

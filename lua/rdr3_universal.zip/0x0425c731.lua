local fn = _gn(0x76610D12A838EBDE)
--- NativeDB Introduced: v1311
function Global.N_0x76610d12a838ebde(p0)
	return _in2(fn, p0, _ri)
end

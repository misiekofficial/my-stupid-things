local fn = _gn(0x6BFF5F84102DF80A)
--- nullsub, doesn't do anything
function Global.NetworkShowChatRestrictionMsc(player)
	return _in2(fn, player)
end

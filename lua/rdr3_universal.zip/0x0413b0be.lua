local fn = _gn(0x513F8AA5BF2F17CF)
--- LOAD_SCENE_START_SPHERE
function Global.N_0x513f8aa5bf2f17cf(x, y, z, radius, p4)
	return _in2(fn, x, y, z, radius, p4, _ri)
end

local fn = _gn(0x95CA12E2C68043E5)
--- 0x95CA12E2C68043E5
function Global.N_0x95ca12e2c68043e5(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

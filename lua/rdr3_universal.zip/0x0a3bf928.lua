local fn = _gn(0xF06C5B66DE20B2B8)
--- Only used in smuggler2 script
function Global.WaterOverrideSetOceanwavemaxamplitude(maxAmplitude)
	return _in2(fn, maxAmplitude)
end

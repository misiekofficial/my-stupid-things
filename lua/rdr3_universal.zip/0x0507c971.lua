local fn = _gn(0xC239DBD9A57D2A71)
--- configHash: https://alloc8or.re/rdr3/doc/enums/eTrainConfig.txt
-- For more information, see trainconfigs.ymt
-- To make the train AI controlled, set conductor to true and set the speed once.
function Global.CreateMissionTrain(configHash, x, y, z, direction, passengers, p6, conductor)
	return _in2(fn, _ch(configHash), x, y, z, direction, passengers, p6, conductor, _ri)
end

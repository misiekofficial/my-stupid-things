local fn = _gn(0xEA8F168A76A0B9BC)
--- Returns true if PromptType is enabled for ped (mount)
-- Params: See 0x0751D461F06E41CE
function Global.GetPlayerUiPromptForPedIsEnabled(player, ped, promptType, promptMode)
	return _in2(fn, player, ped, promptType, promptMode, _ri)
end

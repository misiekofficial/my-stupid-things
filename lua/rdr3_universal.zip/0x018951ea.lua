local fn = _gn(0x0E3BDEED21BEB945)
--- ADD_BOUNTY
function Global.N_0x0e3bdeed21beb945(player, itemValueAmount)
	return _in2(fn, player, itemValueAmount)
end

local fn = _gn(0x86FD10251A7118A4)
--- NETWORK_SET_MP_MISSION_FLAG_ON_CURRENT_SLOT
function Global.N_0x86fd10251a7118a4(enabled, flagIndex)
	return _in2(fn, enabled, flagIndex, _ri)
end

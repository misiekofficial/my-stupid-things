local fn = _gn(0x65E65CA6A0FE59D4)
--- GET_LAUNCH_PARAM_VALUE
function Global.GetLaunchParamValue(paramName)
	return _in2(fn, _ts(paramName), _s)
end

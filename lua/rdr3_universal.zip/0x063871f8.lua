local fn = _gn(0x546E342E01DE71CF)
--- _UI_PROMPT_IS_ACTIVE
function Global.PromptIsActive(prompt)
	return _in2(fn, prompt, _r)
end

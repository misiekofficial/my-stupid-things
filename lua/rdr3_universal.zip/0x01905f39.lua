local fn = _gn(0xE72E5C1289BD1F40)
--- _NETWORK_SESSION_CANCEL_REQUEST
function Global.N_0xe72e5c1289bd1f40(sessionRequestId)
	return _in2(fn, _ii(sessionRequestId) --[[ may be optional ]], _ri)
end

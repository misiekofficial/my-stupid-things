local fn = _gn(0x4E76CB57222A00E5)
--- GET_SEAT_PED_IS_USING
function Global.N_0x4e76cb57222a00e5(ped)
	return _in2(fn, ped, _ri)
end

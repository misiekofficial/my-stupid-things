local fn = _gn(0x4791899615D70FA2)
--- Params: p1 = 2; p2 = 3 in R* Script net_main_offline
function Global.N_0x4791899615d70fa2(player, p1, p2)
	return _in2(fn, player, p1, p2)
end

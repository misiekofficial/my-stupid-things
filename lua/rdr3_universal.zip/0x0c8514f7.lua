local fn = _gn(0xC8B29D18022EA2B7)
--- _IS_PED_DUELLING
function Global.N_0xc8b29d18022ea2b7(ped)
	return _in2(fn, ped, _ri)
end

local fn = _gn(0x27E3F2B57209FA54)
--- 0x27E3F2B57209FA54
function Global.N_0x27e3f2b57209fa54(p0, p1)
	return _in2(fn, p0, p1)
end

local fn = _gn(0x57639FD876B68A91)
--- SAVE_HIGH_QUALITY_PHOTO
function Global.N_0x57639fd876b68a91(unused)
	return _in2(fn, unused, _ri)
end

local fn = _gn(0x129567F0C05F81B9)
--- _PARSEDDATA_UNLOAD_FILE
function Global.DatafileUnload(fileHandle)
	return _in2(fn, fileHandle)
end

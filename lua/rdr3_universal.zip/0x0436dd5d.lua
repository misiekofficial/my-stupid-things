local fn = _gn(0xE956C2340A76272E)
--- 0xE956C2340A76272E
function Global.N_0xe956c2340a76272e(p0)
	return _in2(fn, p0, _ri)
end

local fn = _gn(0x0C9DBF48C6BA6E4C)
--- HAS_ENTITY_CLEAR_LOS_TO_COORD
function Global.HasEntityClearLosToCoord(entity, x, y, z, flags)
	return _in2(fn, entity, x, y, z, flags, _ri)
end

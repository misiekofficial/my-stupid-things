local fn = _gn(0x264E9A5CD78C338F)
--- 0x264E9A5CD78C338F
function Global.N_0x264e9a5cd78c338f(p0)
	return _in2(fn, p0)
end

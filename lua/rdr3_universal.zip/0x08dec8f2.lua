local fn = _gn(0xEC116EDB683AD479)
--- Only used for Special Event (XMAS).
-- _SET_P*
function Global.N_0xec116edb683ad479(p0)
	return _in2(fn, p0)
end

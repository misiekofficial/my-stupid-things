local fn = _gn(0xF6B82FCE03B43A37)
--- configHash: see pedhealth.meta
function Global.N_0xf6b82fce03b43a37(ped, configHash)
	return _in2(fn, ped, _ch(configHash))
end

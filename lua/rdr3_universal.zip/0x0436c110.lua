local fn = _gn(0x59DE03442B6C9598)
--- _GET_WEAPON_COMPONENT_TYPE_MODEL
function Global.GetWeaponComponentTypeModel(componentHash)
	return _in2(fn, _ch(componentHash), _ri)
end

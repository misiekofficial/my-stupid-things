local fn = _gn(0xE0884C184728C75B)
--- _SET_PAUSEMAP_COORDS_WITH_RADIUS
function Global.N_0xe0884c184728c75b(x, y, z, radius)
	return _in2(fn, x, y, z, radius)
end

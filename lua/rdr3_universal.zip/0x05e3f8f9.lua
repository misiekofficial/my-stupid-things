local fn = _gn(0xE0447DEF81CCDFD2)
--- SET_PLAYER_SIMULATE_AIMING
function Global.SetPlayerSimulateAiming(player, toggle)
	return _in2(fn, player, toggle)
end

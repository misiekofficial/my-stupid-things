local fn = _gn(0xD297F68928A58130)
--- NativeDB Introduced: v1232
function Global.N_0xd297f68928a58130(collectableCategory, p1)
	return _in2(fn, _ch(collectableCategory), p1, _ri)
end

local fn = _gn(0xFEFDDC6E8FDF8A75)
--- _SET_GAMEPLAY_P* - _SET_GAMEPLAY_V*
function Global.N_0xfefddc6e8fdf8a75(shakeName, intensity)
	return _in2(fn, _ts(shakeName), intensity)
end

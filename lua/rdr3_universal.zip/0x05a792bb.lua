local fn = _gn(0x002BABE0B7D53136)
--- _SET_DISPATCH_MULTIPLIER_OVERRIDE
function Global.N_0x002babe0b7d53136(multiplier)
	return _in2(fn, multiplier)
end

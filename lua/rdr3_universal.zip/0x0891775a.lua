local fn = _gn(0x665161D250850A9F)
--- _NETWORK_IS_FRIEND_HANDLE_IN_SAME_TITLE
function Global.N_0x665161d250850a9f(gamerHandle)
	return _in2(fn, _ii(gamerHandle) --[[ may be optional ]], _r)
end

local fn = _gn(0x71215ACCFDE075EE)
--- _UI_PROMPT_SET_VISIBLE
function Global.UiPromptSetVisible(prompt, toggle)
	return _in2(fn, prompt, toggle)
end

local fn = _gn(0x2C729F2B94CEA911)
--- _DOES_TEXT_BLOCK_EXIST
function Global.DoesTextBlockExist(textDatabase)
	return _in2(fn, _ts(textDatabase), _ri)
end

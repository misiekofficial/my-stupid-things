local fn = _gn(0x59643424B68D52B5)
--- _IS_PED_CLIMBING_LADDER
function Global.N_0x59643424b68d52b5(ped)
	return _in2(fn, ped, _ri)
end

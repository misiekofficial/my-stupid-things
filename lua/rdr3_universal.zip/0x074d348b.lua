local fn = _gn(0x33281167E4942E4F)
--- ease - smooth transition between the camera's positions
-- easeTime - Time in milliseconds for the transition to happen
-- If you have created a script (rendering) camera, and want to go back to the
-- character (gameplay) camera, call this native with render set to FALSE.
-- Setting ease to TRUE will smooth the transition.
function Global.RenderScriptCams(render, ease, easeTime, p3, p4, p5)
	return _in2(fn, render, ease, easeTime, p3, p4, p5)
end

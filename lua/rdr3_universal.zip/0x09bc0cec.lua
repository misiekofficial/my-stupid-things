local fn = _gn(0xA691C10054275290)
--- 0xA691C10054275290
function Global.N_0xa691c10054275290(mount, player, dismountedTimestamp)
	return _in2(fn, mount, player, dismountedTimestamp)
end

local fn = _gn(0x58F2244C1286D09A)
--- _GET_BREAKABLE_VEHICLE_LOCK_OBJECT
function Global.N_0x58f2244c1286d09a(vehicle, index)
	return _in2(fn, vehicle, index, _ri)
end

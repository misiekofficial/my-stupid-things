local fn = _gn(0x535384D6067BA42E)
--- Returns true when either Pause Menu, a Frontend Menu, Online Policies menu or Social Club menu is active.
function Global.IsPauseMenuActive()
	return _in2(fn, _r)
end

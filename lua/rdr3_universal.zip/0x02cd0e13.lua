local fn = _gn(0x3B390A939AF0B5FC)
--- Returns weaponObject, attachPoint: see SET_CURRENT_PED_WEAPON
function Global.GetCurrentPedWeaponEntityIndex(ped, attachPoint)
	return _in2(fn, ped, attachPoint, _ri)
end

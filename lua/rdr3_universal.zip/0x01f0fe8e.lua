local fn = _gn(0xA95470DA137587F5)
--- 0xA95470DA137587F5
function Global.N_0xa95470da137587f5(p0)
	return _in2(fn, p0)
end

local fn = _gn(0x5A34CD9C3C5BEC44)
--- UGC_RELEASE_CACHED_DESCRIPTION
function Global.UgcReleaseCachedDescription(description)
	return _in2(fn, _ch(description), _r)
end

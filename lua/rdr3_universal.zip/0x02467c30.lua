local fn = _gn(0x018F30D762E62DF8)
--- 0x018F30D762E62DF8
function Global.N_0x018f30d762e62df8(ped, p1)
	return _in2(fn, ped, _ii(p1) --[[ may be optional ]], _ri)
end

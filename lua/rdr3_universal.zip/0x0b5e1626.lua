local fn = _gn(0x53D05D60E5F5B40C)
--- 0x53D05D60E5F5B40C
function Global.N_0x53d05d60e5f5b40c(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3)
end

local fn = _gn(0x8FDF221F13537936)
--- RESET_ANIM_SCENE
function Global.ResetAnimScene(animScene, playbackListName)
	return _in2(fn, animScene, _ts(playbackListName))
end

local fn = _gn(0x5AAAF40E9B224F5E)
--- _ITEMDATABASE_GET_NUMBER_OF_MODIFIED_PRICES
function Global.ItemdatabaseGetNumberOfModifiedPrices(p0)
	return _in2(fn, p0, _ri)
end

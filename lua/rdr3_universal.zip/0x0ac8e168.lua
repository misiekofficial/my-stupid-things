local fn = _gn(0xDF01B1F7A886B42D)
--- _PARSEDDATA_RQ_GET_NUM_NODES
function Global.DatafileGetNumNodes(p0)
	return _in2(fn, p0, _ri)
end

local fn = _gn(0x91FE941F9FCFB702)
--- Returns requestId
-- Params: p1 = 1 in R* Scripts
function Global.RequestMetaPedAssetBundle(asset, p1)
	return _in2(fn, _ch(asset), p1, _ri)
end

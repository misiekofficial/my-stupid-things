local fn = _gn(0x1D97DA8ACB5D2582)
--- 0x1D97DA8ACB5D2582
function Global.N_0x1d97da8acb5d2582(ropeId, p1)
	return _in2(fn, ropeId, p1)
end

local fn = _gn(0x83B8D50EB9446BBA)
--- _SET_ALLOW_DUAL_WIELD
function Global.SetAllowDualWield(ped, allow)
	return _in2(fn, ped, allow)
end

local fn = _gn(0x6569F31A01B4C097)
--- https://github.com/Halen84/RDR3-Native-Flags-And-Enums/tree/main/CLootingFlags__Flags
-- https://github.com/femga/rdr3_discoveries/tree/master/AI/LOOTING_FLAGS
-- lootFlag:
-- enum eLootFlag
-- {
-- LOOT_FLAG_IS_CRITICAL_LOOT_TARGET = 7,
-- LOOT_FLAG_IGNORE_WATER_CHECKS = 8,
-- LOOT_FLAG_ANIMAL_FLAGGED_FOR_TAGGING = 23,
-- };
function Global.N_0x6569f31a01b4c097(ped, lootFlag, enabled)
	return _in2(fn, ped, lootFlag, enabled)
end

local fn = _gn(0x7EC0D68233E391AC)
--- 0x7EC0D68233E391AC
function Global.N_0x7ec0d68233e391ac(p0)
	return _in2(fn, p0, _ri)
end

local fn = _gn(0x0AC679B2342F14F2)
--- Params: percentWeather2: 0f - 0.75f in R* Scripts
function Global.GetWeatherTypeTransition()
	return _in2(fn, _i, _i, _f)
end

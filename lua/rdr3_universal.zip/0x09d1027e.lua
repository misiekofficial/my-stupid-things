local fn = _gn(0x815C4065AE6E6071)
--- Example: https://pastebin.com/JygJShNU
function Global.UiStickyFeedCreateDeathFailMessage(p2)
	return _in2(fn, _i, _i, p2, _ri)
end

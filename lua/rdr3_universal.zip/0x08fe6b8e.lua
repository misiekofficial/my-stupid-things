local fn = _gn(0xD0498AD30E16B6BD)
--- NETWORK_HAS_PENDING_INVITE_FAILURE
function Global.NetworkHasPendingInviteFailure()
	return _in2(fn, _ri)
end

local fn = _gn(0x1148F706CF4EBDDA)
--- _CAN_PED_SEE* - _CAN_PED_USE_(SCENARIO_HASH?)*
function Global.N_0x1148f706cf4ebdda(ped, p1, p2)
	return _in2(fn, ped, _ch(p1), p2, _r)
end

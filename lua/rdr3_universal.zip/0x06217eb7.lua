local fn = _gn(0x188313616D184213)
--- _PERSISTENCE_IS_SCENARIO_MARKED_AS_LOOTED_AT_COORDS_WITH_MODEL
function Global.N_0x188313616d184213(x, y, z, model)
	return _in2(fn, x, y, z, _ch(model), _ri)
end

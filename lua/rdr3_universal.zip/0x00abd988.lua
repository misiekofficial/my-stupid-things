local fn = _gn(0x7DFB49BCDB73089A)
--- https://imgur.com/a/I2swSDJ
function Global.N_0x7dfb49bcdb73089a(object, toggle)
	return _in2(fn, object, toggle)
end

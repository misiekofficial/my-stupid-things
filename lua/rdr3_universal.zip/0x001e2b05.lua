local fn = _gn(0x0CC28C08613BA9E5)
--- nullsub, doesn't do anything
function Global.N_0x0cc28c08613ba9e5(p0)
	return _in2(fn, p0)
end

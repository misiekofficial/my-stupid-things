local fn = _gn(0x2E036F0480B8BF02)
--- Returns GET_GAME_TIMER() / 1000
-- Only used in rcm_pearson1.ysc
function Global.N_0x2e036f0480b8bf02()
	return _in2(fn, _ri)
end

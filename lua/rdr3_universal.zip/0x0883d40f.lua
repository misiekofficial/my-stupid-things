local fn = _gn(0xF89AA2BD01FC06B7)
--- CREATE_PED_ON_MOUNT
function Global.CreatePedOnMount(mount, modelHash, index, p3, p4, p5, p6)
	return _in2(fn, mount, _ch(modelHash), index, p3, p4, p5, p6, _ri)
end

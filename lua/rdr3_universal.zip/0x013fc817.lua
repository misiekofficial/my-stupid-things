local fn = _gn(0xBBC67A6F965C688A)
--- _HAS_PED_GOT_WEAPON_COMPONENT
function Global.HasPedGotWeaponComponent(ped, componentHash, weaponHash)
	return _in2(fn, ped, _ch(componentHash), _ch(weaponHash), _ri)
end

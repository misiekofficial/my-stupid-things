local fn = _gn(0xA7DC9266ED6A4E51)
--- _CLEAR_PED_B* - _CLEAR_PED_C*
function Global.N_0xa7dc9266ed6a4e51(ped)
	return _in2(fn, ped)
end

local fn = _gn(0xB72999D3120599DF)
--- Returns false if pedshot push failed
function Global.N_0xb72999d3120599df(texture, personaPhotoType, formatIndex)
	return _in2(fn, _ts(texture), personaPhotoType, formatIndex, _ri)
end

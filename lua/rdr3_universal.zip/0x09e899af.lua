local fn = _gn(0xC0B1C05B313693D1)
--- Only used in R* SP Script short_update
function Global.N_0xc0b1c05b313693d1(player, timer)
	return _in2(fn, player, timer)
end

local fn = _gn(0x4F056E1AFFEF17AB)
--- motionStateHash: see FORCE_PED_MOTION_STATE
function Global.TaskForceMotionState(ped, motionStateHash, p2)
	return _in2(fn, ped, _ch(motionStateHash), p2)
end

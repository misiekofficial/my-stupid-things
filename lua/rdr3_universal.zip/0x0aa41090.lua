local fn = _gn(0xC04F47D488EF9EBA)
--- _INVENTORY_COPY_ITEM_TO_INVENTORY
function Global.InventoryCopyItemToInventory(inventoryId, inventoryIdCloned, p3)
	return _in2(fn, inventoryId, inventoryIdCloned, _i, p3)
end

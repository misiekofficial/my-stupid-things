local fn = _gn(0x12FB95FE3D579238)
--- Equips a weapon from a weaponItem, similar to GIVE_WEAPON_TO_PED
function Global.SetCurrentPedWeaponByGuid(ped, p2, p3, p4, p5)
	return _in2(fn, ped, _i, p2, p3, p4, p5)
end

local fn = _gn(0x16E9ABDD34DDD931)
--- 0x16E9ABDD34DDD931
function Global.N_0x16e9abdd34ddd931()
	return _in2(fn)
end

local fn = _gn(0x1096603B519C905F)
--- _SET_MISSION_NAME_*(FOR_ACTIVITY?/MINIGAME?)
function Global.N_0x1096603b519c905f(name)
	return _in2(fn, _ts(name))
end

local fn = _gn(0x86CCAF7CE493EFBE)
--- CLEAR_FOCUS
function Global.ClearFocus()
	return _in2(fn)
end

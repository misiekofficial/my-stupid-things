local fn = _gn(0xD55DB4466D00A258)
--- Used in Script Function LA_CHECK_ALERTED
-- _GET_IS_PED_*
function Global.N_0xd55db4466d00a258(legendaryAnimal)
	return _in2(fn, legendaryAnimal, _r)
end

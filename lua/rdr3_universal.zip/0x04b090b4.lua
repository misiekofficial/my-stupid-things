local fn = _gn(0xCE71C2F9BAA3F975)
--- Used with 'P_BODYPARTARMFLOAT02X' model in fishing_core.c
function Global.N_0xce71c2f9baa3f975(ped, object)
	return _in2(fn, ped, object)
end

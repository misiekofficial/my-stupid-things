local fn = _gn(0x12DF6E0D2E736749)
--- IS_ENTITY_ATTACHED_TO_ANY_VEHICLE
function Global.IsEntityAttachedToAnyVehicle(entity)
	return _in2(fn, entity, _r)
end

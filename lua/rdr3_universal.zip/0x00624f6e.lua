local fn = _gn(0xA3A9299C4F2ADB98)
--- SET_PED_SHOULD_PLAY_NORMAL_SCENARIO_EXIT
function Global.SetPedShouldPlayNormalScenarioExit(ped)
	return _in2(fn, ped)
end

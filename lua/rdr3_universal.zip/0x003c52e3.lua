local fn = _gn(0xAFA14F98327791CE)
--- 0xAFA14F98327791CE
function Global.N_0xafa14f98327791ce(sessionRequestId)
	return _in2(fn, _ii(sessionRequestId) --[[ may be optional ]], _r)
end

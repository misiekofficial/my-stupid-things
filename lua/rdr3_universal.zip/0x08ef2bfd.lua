local fn = _gn(0x53764309C4618087)
--- 0x53764309C4618087
function Global.N_0x53764309c4618087(p0)
	return _in2(fn, p0, _ri)
end

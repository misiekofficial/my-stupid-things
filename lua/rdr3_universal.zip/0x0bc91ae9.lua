local fn = _gn(0x9297DACF3A2CDFF7)
--- Returns value of the '-benchmarkPass' command line option.
function Global.GetBenchmarkPass()
	return _in2(fn, _ri)
end

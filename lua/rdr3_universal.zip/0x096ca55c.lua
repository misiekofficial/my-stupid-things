local fn = _gn(0x2CD41AC000E6F611)
--- nullsub, doesn't do anything
function Global.N_0x2cd41ac000e6f611()
	return _in2(fn)
end

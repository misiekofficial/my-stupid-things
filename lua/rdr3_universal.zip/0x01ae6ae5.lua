local fn = _gn(0x51C3B71591811485)
--- NativeDB Introduced: v1311
function Global.RemoveWeaponFromPedByGuid(ped, removeReason)
	return _in2(fn, ped, _i, _ch(removeReason))
end

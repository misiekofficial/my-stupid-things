local fn = _gn(0xF97C34C33487D569)
--- Returns requestId
-- Params: p1 = 1 in R* Scripts (Used in SP only)
function Global.N_0xf97c34c33487d569(model, p1)
	return _in2(fn, _ch(model), p1, _ri)
end

local fn = _gn(0x95B8E397B8F4360F)
--- _GET_HEALTH_RECHARGE_MULTIPLIER
function Global.N_0x95b8e397b8f4360f(ped)
	return _in2(fn, ped, _rf)
end

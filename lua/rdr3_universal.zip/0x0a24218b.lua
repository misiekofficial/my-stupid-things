local fn = _gn(0xAE72E7DF013AAA61)
--- Params: p3 = 0, 1; p5 = 0.0f, -1.0f
-- https://github.com/femga/rdr3_discoveries/tree/master/tasks/TASK_ITEM_INTERACTION
function Global.TaskItemInteraction(ped, itemHash, interactionAnimHash, p3, flag, p5)
	return _in2(fn, ped, _ch(itemHash), _ch(interactionAnimHash), p3, flag, p5)
end

local fn = _gn(0x391073B9D3CCE2BA)
--- Tasks vehicle towards owner
function Global.TaskVehicleDriveToDestination_2(vehicle, x, y, z, speed, p5, p6, p7, p8)
	return _in2(fn, vehicle, x, y, z, speed, p5, p6, p7, p8)
end

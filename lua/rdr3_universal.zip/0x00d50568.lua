local fn = _gn(0x4776EFD78F75C23F)
--- _ITEMDATABASE_FILLOUT_SATCHEL_DATA
function Global.ItemDatabaseFilloutSatchelData(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

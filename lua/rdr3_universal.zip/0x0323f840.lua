local fn = _gn(0xFE53B1F8D43F19BF)
--- 0xFE53B1F8D43F19BF
function Global.N_0xfe53b1f8d43f19bf(player1, player2)
	return _in2(fn, player1, player2, _ri)
end

local fn = _gn(0xD9C24F53631F2372)
--- _PEDSHOT_GENERATE_PERSONA_PHOTO
function Global.N_0xd9c24f53631f2372(texture, ped, playerSlot)
	return _in2(fn, _ts(texture), ped, playerSlot, _r)
end

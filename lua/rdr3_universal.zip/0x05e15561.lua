local fn = _gn(0x12E09E278C6C29B7)
--- 0x12E09E278C6C29B7
function Global.N_0x12e09e278c6c29b7(p0)
	return _in2(fn, p0)
end

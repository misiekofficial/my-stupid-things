local fn = _gn(0x6A6E79FBE8678C98)
--- 0x6A6E79FBE8678C98
function Global.N_0x6a6e79fbe8678c98()
	return _in2(fn)
end

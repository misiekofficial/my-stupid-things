local fn = _gn(0xC59AB6A04333C502)
--- _GET_LAUNCH_PARAM_STRING
function Global.GetLaunchParamString()
	return _in2(fn, _s)
end

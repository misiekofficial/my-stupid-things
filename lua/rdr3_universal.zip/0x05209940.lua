local fn = _gn(0x5E72022914CE3C38)
--- GET_FRAME_TIME
function Global.GetFrameTime()
	return _in2(fn, _rf)
end

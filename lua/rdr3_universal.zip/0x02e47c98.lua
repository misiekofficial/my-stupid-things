local fn = _gn(0x5C885E0978B6AD60)
--- _CREATE_WAYPOINT_PATH
function Global.CreateWaypointPath(pathName, nodes, p3)
	return _in2(fn, _ts(pathName), _i, nodes, p3, _ri)
end

local fn = _gn(0x078076AB50FB117F)
--- If returned true: There are enemy peds near friendly turn in ped. Going to aggro.
-- If returned false: Moving back to idle as there aren't any remaining enemy peds near ped
-- _IS_PED_IN_*
function Global.N_0x078076ab50fb117f(ped, x, y, z, radius, p5)
	return _in2(fn, ped, x, y, z, radius, p5, _r)
end

local fn = _gn(0xB729679356A889AE)
--- _GET_VEHICLE_OWNER
function Global.GetVehicleOwner(vehicle)
	return _in2(fn, vehicle, _ri)
end

local fn = _gn(0xDDBD560745B1EE9C)
--- CHAL_ADD_GOAL_PROGRESS_INT_BY_SCORE_ID
function Global.ChalAddGoalProgressIntByScoreId(p0, value)
	return _in2(fn, _ch(p0), value)
end

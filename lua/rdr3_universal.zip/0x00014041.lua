local fn = _gn(0xB90411F480457A6C)
--- SET_CINEMATIC_BUTTON_ACTIVE
function Global.SetCinematicButtonActive(p0)
	return _in2(fn, p0)
end

local fn = _gn(0xAC806C4CAB973517)
--- SET_FADE_IN_AFTER_LOAD
function Global.SetFadeInAfterLoad(toggle)
	return _in2(fn, toggle)
end

local fn = _gn(0x275F255ED201B937)
--- GET_PLAYER_PED
function Global.GetPlayerPed(player)
	return _in2(fn, player, _ri)
end

local fn = _gn(0x992187D975635DF5)
--- NativeDB Introduced: v1311
function Global.N_0x992187d975635df5(p0, p1)
	return _in2(fn, p0, p1)
end

local fn = _gn(0x3B7519720C9DCB45)
--- _UIFLOWBLOCK_ENTER
function Global.EnterFlowBlock(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

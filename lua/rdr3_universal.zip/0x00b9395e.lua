local fn = _gn(0x914071FF93AF2692)
--- Sets Player's Defense against AI modifier
function Global.N_0x914071ff93af2692(player, modifier)
	return _in2(fn, player, modifier)
end

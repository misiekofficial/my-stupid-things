local fn = _gn(0xF34EE736CF047844)
--- Rounds a float value down to the next whole number
function Global.Floor(value)
	return _in2(fn, value, _ri)
end

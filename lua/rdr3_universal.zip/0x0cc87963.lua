local fn = _gn(0xE689C1B1432BB8AF)
--- START_PARTICLE_FX_LOOPED_ON_PED_BONE
function Global.StartParticleFxLoopedOnPedBone(effectName, ped, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis)
	return _in2(fn, _ts(effectName), ped, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis, _ri)
end

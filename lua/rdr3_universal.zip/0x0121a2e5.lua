local fn = _gn(0x3F73AED12A5EF0FF)
--- _BOUNTY_REQUEST_SERVED_FULL_JAIL_SENTENCE
function Global.N_0x3f73aed12a5ef0ff(outRpcGuid)
	return _in2(fn, _ii(outRpcGuid) --[[ may be optional ]], _ri)
end

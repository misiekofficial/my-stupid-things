local fn = _gn(0x7DE4643157AD646C)
--- _REQUEST_THREAD_EXIT
function Global.N_0x7de4643157ad646c(threadId)
	return _in2(fn, threadId)
end

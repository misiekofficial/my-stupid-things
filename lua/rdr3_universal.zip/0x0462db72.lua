local fn = _gn(0x72068021F498E6E3)
--- _DOES_PROP_SET_OF_TYPE_EXIST_NEAR_COORDS
function Global.N_0x72068021f498e6e3(propsetHash, x, y, z)
	return _in2(fn, _ch(propsetHash), x, y, z, _ri)
end

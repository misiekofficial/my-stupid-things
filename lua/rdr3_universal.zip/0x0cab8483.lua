local fn = _gn(0x4B39D8F9D0FE7749)
--- TASK_AMBIENT_ANIMAL_HUNT
function Global.TaskAmbientAnimalHunt(ped, p1, p2)
	return _in2(fn, ped, p1, p2)
end

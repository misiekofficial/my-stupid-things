local fn = _gn(0x765E60A1DCB8B1CE)
--- _NETWORK_SPAWN_CONFIG_SET_CANCEL_SEARCH
function Global.NetworkSpawnConfigSetCancelSearch()
	return _in2(fn)
end

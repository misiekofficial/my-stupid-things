local fn = _gn(0xAE99FB955581844A)
--- nmTaskMessageParameterName: See physicstasks.ymt. Search for DraggedByCart or 0xD00820D7 (Used in R* SP Script marston8)
function Global.SetPedToRagdoll(ped, timeMin, timeMax, ragdollType, abortIfInjured, abortIfDead, nmTaskMessageParameterName)
	return _in2(fn, ped, timeMin, timeMax, ragdollType, abortIfInjured, abortIfDead, _ts(nmTaskMessageParameterName), _r)
end

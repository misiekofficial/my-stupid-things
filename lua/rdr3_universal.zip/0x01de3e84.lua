local fn = _gn(0x4662BFE01938D98D)
--- _SET_TASK_MOVE_NETWORK_SIGNAL_VECTOR
function Global.N_0x4662bfe01938d98d(ped, signalName, x, y, z)
	return _in2(fn, ped, _ts(signalName), x, y, z)
end

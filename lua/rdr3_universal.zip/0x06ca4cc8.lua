local fn = _gn(0x88CBB5CEB96B7BD2)
--- Not implemented.
function Global.SetPedStealthMovement(ped, toggle, p2, p3)
	return _in2(fn, ped, toggle, p2, p3)
end

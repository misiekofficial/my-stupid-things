local fn = _gn(0xB16FC7B364D86585)
--- nullsub, doesn't do anything
function Global.N_0xb16fc7b364d86585()
	return _in2(fn)
end

local fn = _gn(0x4A47E38EA3D60939)
--- statId: see STAT_ID_IS_VALID
function Global.StatIdIncrementFloat(value)
	return _in2(fn, _i, value)
end

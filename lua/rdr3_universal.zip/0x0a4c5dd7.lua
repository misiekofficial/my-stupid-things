local fn = _gn(0x27AF48C62B281341)
--- 0x27AF48C62B281341
function Global.N_0x27af48c62b281341()
	return _in2(fn, _ri)
end

local fn = _gn(0xDDCF6FEA5D7ACC17)
--- -1 - HORSE_ASSIST__NO_CHANGE
-- 0 - HORSE_ASSIST__MANUAL
-- 1 - HORSE_ASSIST__SEMIASSIST
-- 2 - HORSE_ASSIST__FULLASSIST
function Global.SetHorseAvoidanceLevel(horse, avoidanceLevel)
	return _in2(fn, horse, avoidanceLevel)
end

local fn = _gn(0x99C6EA66DFE73757)
--- Params: tag = TAG_ITEM_PROPERTY (tagType(?))
function Global.N_0x99c6ea66dfe73757(bundle, tag, tagType)
	return _in2(fn, _ch(bundle), _ch(tag), _ch(tagType), _ri)
end

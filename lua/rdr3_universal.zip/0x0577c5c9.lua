local fn = _gn(0x6A648D42BF271DC7)
--- eventType: https://alloc8or.re/rdr3/doc/enums/eEventType.txt
function Global.N_0x6a648d42bf271dc7(eventType, x, y, z, radius, p5)
	return _in2(fn, _ch(eventType), x, y, z, radius, p5)
end

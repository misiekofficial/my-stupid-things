local fn = _gn(0x669E223E64B1903C)
--- _NETWORK_CLOCK_TIME_OVERRIDE
function Global.NetworkClockTimeOverride(hour, minute, second, transitionTime, pauseClock)
	return _in2(fn, hour, minute, second, transitionTime, pauseClock)
end

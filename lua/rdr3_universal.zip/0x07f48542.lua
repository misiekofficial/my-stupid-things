local fn = _gn(0xC93A9A45430D484E)
--- 0xC93A9A45430D484E
function Global.N_0xc93a9a45430d484e(p0)
	return _in2(fn, p0, _ri)
end

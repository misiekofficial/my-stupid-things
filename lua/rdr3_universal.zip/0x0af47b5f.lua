local fn = _gn(0x9700E8EFC4AB9089)
--- INVENTORY_GET_INVENTORY_ITEM
function Global.InventoryGetInventoryItem(inventoryId, p3)
	return _in2(fn, inventoryId, _i, _i, p3, _ri)
end

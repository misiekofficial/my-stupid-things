local fn = _gn(0xCEC6A41E8910486A)
--- Returns docData.iNumTotalLabelTypes
function Global.ItemDatabaseLocalizationGetNumLabelTypes(p0)
	return _in2(fn, p0, _ri)
end

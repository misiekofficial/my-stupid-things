local fn = _gn(0x60B85BED6577A35B)
--- SET_PARTICLE_FX_NON_LOOPED_COLOUR
function Global.SetParticleFxNonLoopedColour(r, g, b)
	return _in2(fn, r, g, b)
end

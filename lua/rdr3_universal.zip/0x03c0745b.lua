local fn = _gn(0x7D4E70A67A651C71)
--- _UNRESERVE_AMBIENT_PEDS
function Global.UnreserveAmbientPeds(numPeds)
	return _in2(fn, numPeds)
end

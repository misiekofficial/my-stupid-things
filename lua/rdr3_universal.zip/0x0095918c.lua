local fn = _gn(0x6BFBDC46139C45AB)
--- HAS_COLLISION_LOADED_AROUND_POSITION
function Global.N_0x6bfbdc46139c45ab(xPos, yPos, zPos)
	return _in2(fn, xPos, yPos, zPos, _ri)
end

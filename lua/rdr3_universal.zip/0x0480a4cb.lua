local fn = _gn(0xF3A21BCD95725A4A)
--- IS_CONTROL_PRESSED
function Global.IsControlPressed(control, action)
	return _in2(fn, control, _ch(action), _r)
end

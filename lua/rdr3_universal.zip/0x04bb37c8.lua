local fn = _gn(0x90237103F27F7937)
--- eventData: see EVENTS_UI_GET_MESSAGE
function Global.EventsUiPeekMessage(hash, eventData)
	return _in2(fn, _ch(hash), _ii(eventData) --[[ may be optional ]], _r)
end

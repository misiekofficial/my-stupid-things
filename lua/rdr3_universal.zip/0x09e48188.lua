local fn = _gn(0xD04241BBF6D03A5E)
--- GET_RANSACK_SCENARIO_POINT_PED_IS_USING
function Global.N_0xd04241bbf6d03a5e(ped)
	return _in2(fn, ped, _ri)
end

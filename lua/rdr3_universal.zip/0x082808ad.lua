local fn = _gn(0xFCCC886EDE3C63EC)
--- Unequip current weapon and set current weapon to WEAPON_UNARMED.
-- p0 usually 2 in R* scripts. Doesn't seem to have any effect if changed....
-- immediately: if true it will instantly switch to unarmed
function Global.HidePedWeapons(ped, p0, immediately)
	return _in2(fn, ped, p0, immediately)
end

local fn = _gn(0x62BE3ECC79FBD004)
--- _GET_NUM_RESERVED_MISSION_PICKUPS
function Global.GetNumReservedMissionPickups(p0)
	return _in2(fn, p0, _ri)
end

local fn = _gn(0xC369E2234E34A0CA)
--- 0xC369E2234E34A0CA
function Global.N_0xc369e2234e34a0ca(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

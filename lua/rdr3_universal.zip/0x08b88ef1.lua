local fn = _gn(0x79482C12482A860D)
--- Params: moveBlendRatio commonly 1.25f, p5 is always 0 in R* Scripts
function Global.TaskMoveInTraffic_4(ped, moveBlendRatio, x, y, z, p5)
	return _in2(fn, ped, moveBlendRatio, x, y, z, p5)
end

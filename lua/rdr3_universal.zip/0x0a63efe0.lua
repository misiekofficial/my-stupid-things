local fn = _gn(0x3FE141FDB990E3D1)
--- NETWORK_ACTIVITY_RESET_TO_IDLE
function Global.NetworkActivityResetToIdle()
	return _in2(fn)
end

local fn = _gn(0xC3544AD0522E69B4)
--- _SET_WEAPON_SCALE
function Global.SetWeaponScale(weaponObject, scale)
	return _in2(fn, weaponObject, scale)
end

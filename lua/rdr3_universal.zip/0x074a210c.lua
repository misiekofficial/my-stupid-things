local fn = _gn(0xD9F8455409B525E9)
--- eventType: https://alloc8or.re/rdr3/doc/enums/eEventType.txt
-- https://github.com/femga/rdr3_discoveries/blob/master/AI/EVENTS
function Global.AddShockingEventAtPosition(eventType, x, y, z, p4, p5, p6, p7, p8, p9, p10)
	return _in2(fn, _ch(eventType), x, y, z, p4, p5, p6, p7, p8, p9, p10, _ri)
end

--- DELETE_FUNCTION_REFERENCE
function Global.DeleteFunctionReference(referenceIdentity)
	return _in(0x1e86f206, _ts(referenceIdentity))
end

--- GET_NUM_RESOURCES
function Global.GetNumResources()
	return _in(0x863f27b, _ri)
end

--- STOP_RESOURCE
function Global.StopResource(resourceName)
	return _in(0x21783161, _ts(resourceName), _r)
end

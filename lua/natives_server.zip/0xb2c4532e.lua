--- GET_VEHICLE_CUSTOM_PRIMARY_COLOUR
function Global.GetVehicleCustomPrimaryColour(vehicle)
	return _in(0x1c2b9fef, vehicle, _i, _i, _i)
end

--- GET_VEHICLE_DOOR_STATUS
-- @return A number from 0 to 7.
function Global.GetVehicleDoorStatus(vehicle)
	return _in(0x6e35c49c, vehicle, _ri)
end

--- GET_VEHICLE_RADIO_STATION_INDEX
function Global.GetVehicleRadioStationIndex(vehicle)
	return _in(0x57037960, vehicle, _ri)
end

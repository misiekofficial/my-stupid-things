--- GET_RESOURCE_BY_FIND_INDEX
-- @param findIndex The index of the resource (starting at 0)
-- @return The resource name as a `string`
function Global.GetResourceByFindIndex(findIndex)
	return _in(0x387246b7, findIndex, _s)
end

--- GET_PLAYER_TEAM
-- @param playerSrc The player handle
function Global.GetPlayerTeam(playerSrc)
	return _in(0x9873e404, _ts(playerSrc), _ri)
end

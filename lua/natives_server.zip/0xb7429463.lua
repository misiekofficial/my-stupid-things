--- SET_PLAYER_WANTED_LEVEL
-- @param player the target player
-- @param wantedLevel the wanted level 1-5
-- @param delayedResponse false = 0-10sec police spawn response time, true = 10-20sec police spawn response time
function Global.SetPlayerWantedLevel(player, wantedLevel, delayedResponse)
	return _in(0xb7a0914b, _ts(player), wantedLevel, delayedResponse)
end

--- GET_ENTITY_SCRIPT
function Global.GetEntityScript(entity)
	return _in(0xb7f70784, entity, _s)
end

--- GET_ENTITY_MODEL
function Global.GetEntityModel(entity)
	return _in(0xdafcb3ec, entity, _ri)
end

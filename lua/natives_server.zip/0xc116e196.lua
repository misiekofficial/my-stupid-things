--- GET_ENTITY_ROTATION
function Global.GetEntityRotation(entity)
	return _in(0x8ff45b04, entity, _rv)
end

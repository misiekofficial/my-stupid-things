--- GET_PLAYER_INVINCIBLE
-- @param playerSrc The player handle
-- @return A boolean to tell if the player is invincible.
function Global.GetPlayerInvincible(playerSrc)
	return _in(0x680c90ee, _ts(playerSrc), _r)
end

local fn = _gn(0x97A28E63F0BA5631)
function Global.TaskUseNearestScenarioChainToCoordWarp(p0, p1, p2, p3, p4, p5)
	return _in2(fn, p0, p1, p2, p3, p4, p5)
end

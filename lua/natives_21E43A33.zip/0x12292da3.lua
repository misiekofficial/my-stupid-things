local fn = _gn(0xEEA5AC2EDA7C33E8)
function Global.N_0xeea5ac2eda7c33e8(p0, p1, p2)
	return _in2(fn, p0, p1, p2, _r)
end

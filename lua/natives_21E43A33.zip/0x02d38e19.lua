local fn = _gn(0x38D5B0FEBB086F75)
function Global.NetworkGetPresenceInviteHandle(p0, p1)
	return _in2(fn, p0, _ii(p1) --[[ may be optional ]], _r)
end

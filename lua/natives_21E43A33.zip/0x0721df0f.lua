local fn = _gn(0xCAA15F13EBD417FF)
function Global.SetNumberOfParkedVehicles(value)
	return _in2(fn, value, _ri)
end

local fn = _gn(0x617F49C2668E6155)
function Global.N_0x617f49c2668e6155()
	return _in2(fn, _ri)
end

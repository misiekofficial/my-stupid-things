local fn = _gn(0xA7A1127490312C36)
function Global.N_0xa7a1127490312c36(p0)
	return _in2(fn, p0)
end

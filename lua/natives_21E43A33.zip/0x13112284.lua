local fn = _gn(0x36C6984C3ED0C911)
function Global.N_0x36c6984c3ed0c911(p0)
	return _in2(fn, p0)
end

local fn = _gn(0xBBCCE00B381F8482)
function Global.IsPedFleeing(ped)
	return _in2(fn, ped, _r)
end

local fn = _gn(0xDDF803377F94AAA8)
function Global.SetPedGestureGroup(ped, p1)
	return _in2(fn, ped, _ii(p1) --[[ may be optional ]])
end

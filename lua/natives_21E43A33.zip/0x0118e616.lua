local fn = _gn(0x595B5178E412E199)
function Global.AddTrevorRandomModifier(p0)
	return _in2(fn, p0, _r)
end

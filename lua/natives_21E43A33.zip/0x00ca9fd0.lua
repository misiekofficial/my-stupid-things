local fn = _gn(0x1C6CD14A876FFE39)
function Global.TaskPutPedDirectlyIntoMelee(ped, meleeTarget, p2, p3, p4, p5)
	return _in2(fn, ped, meleeTarget, p2, p3, p4, p5)
end

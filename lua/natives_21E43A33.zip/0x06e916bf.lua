local fn = _gn(0xE6869BECDD8F2403)
function Global.N_0xe6869becdd8f2403(p0, p1)
	return _in2(fn, p0, p1)
end

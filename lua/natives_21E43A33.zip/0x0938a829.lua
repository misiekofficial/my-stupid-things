local fn = _gn(0x578C752848ECFA0C)
function Global.SetWeatherTypeTransition(p0, p1, time)
	return _in2(fn, p0, p1, time)
end

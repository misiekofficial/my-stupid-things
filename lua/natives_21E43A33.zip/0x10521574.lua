local fn = _gn(0x53CAE13E9B426993)
function Global.N_0x53cae13e9b426993(p0)
	return _in2(fn, p0)
end

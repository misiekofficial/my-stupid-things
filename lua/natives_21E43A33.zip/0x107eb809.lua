local fn = _gn(0x29439776AAA00A62)
function Global.GetVehicleClass(vehicle)
	return _in2(fn, vehicle, _ri)
end

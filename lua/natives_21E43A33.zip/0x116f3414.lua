local fn = _gn(0x026FB97D0A425F84)
function Global.SetCamActive(cam, active)
	return _in2(fn, cam, active)
end

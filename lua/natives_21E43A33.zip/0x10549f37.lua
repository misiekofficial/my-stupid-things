local fn = _gn(0x39A5FB7EAF150840)
function Global.N_0x39a5fb7eaf150840(p0, p1)
	return _in2(fn, p0, p1)
end

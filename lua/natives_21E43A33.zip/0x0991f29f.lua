local fn = _gn(0xB2092A1EAA7FD45F)
function Global.N_0xb2092a1eaa7fd45f(p0)
	return _in2(fn, p0, _ri)
end

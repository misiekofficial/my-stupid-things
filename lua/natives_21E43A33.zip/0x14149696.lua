local fn = _gn(0x8609C75EC438FB3B)
function Global.AddCamSplineNode(camera, x, y, z, xRot, yRot, zRot, p7, p8, p9)
	return _in2(fn, camera, x, y, z, xRot, yRot, zRot, p7, p8, p9)
end

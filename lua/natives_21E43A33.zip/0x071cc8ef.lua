local fn = _gn(0xF1AE5DCDBFCA2721)
function Global.N_0xf1ae5dcdbfca2721()
	return _in2(fn, _i, _i, _i, _r)
end

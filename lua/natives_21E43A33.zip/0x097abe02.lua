local fn = _gn(0x5486A79D9FBD342D)
function Global.GetJackTarget(p0)
	return _in2(fn, p0, _ri)
end

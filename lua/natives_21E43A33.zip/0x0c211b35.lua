local fn = _gn(0x655B91F1495A9090)
function Global.NetworkPlayerIsCheater()
	return _in2(fn, _ri)
end

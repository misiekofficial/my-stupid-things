local fn = _gn(0x629526ABA383BCAA)
function Global.N_0x629526aba383bcaa()
	return _in2(fn)
end

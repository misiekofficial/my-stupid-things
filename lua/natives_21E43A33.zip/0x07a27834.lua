local fn = _gn(0x26D83693ED99291C)
function Global.SetPedHelmetPropIndex(ped, propIndex)
	return _in2(fn, ped, propIndex)
end

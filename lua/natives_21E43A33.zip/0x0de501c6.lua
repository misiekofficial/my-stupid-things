local fn = _gn(0xC396F5B86FF9FEBD)
function Global.SetPedLegIkMode(ped, mode)
	return _in2(fn, ped, mode)
end

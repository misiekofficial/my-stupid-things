local fn = _gn(0x57C5DB656185EAC4)
function Global.SetEntityTrafficlightOverride(entity, state)
	return _in2(fn, entity, state)
end

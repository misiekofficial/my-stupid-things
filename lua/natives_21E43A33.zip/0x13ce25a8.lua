local fn = _gn(0x9E8C908F41584ECD)
function Global.SetPedMoveAnimsBlendOut(ped)
	return _in2(fn, ped)
end

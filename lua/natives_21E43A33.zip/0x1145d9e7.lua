local fn = _gn(0xA00EFE4082C4056E)
function Global.ScInboxMessageGetDataInt(p0)
	return _in2(fn, p0, _i, _i, _r)
end

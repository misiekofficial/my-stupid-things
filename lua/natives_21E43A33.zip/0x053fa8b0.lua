local fn = _gn(0x5BCA583A583194DB)
function Global.DrawSpotLightWithShadow(x, y, z, dirVectorX, dirVectorY, dirVectorZ, r, g, b, distance, brightness, roundness, radius, fadeout, shadow)
	return _in2(fn, x, y, z, dirVectorX, dirVectorY, dirVectorZ, r, g, b, distance, brightness, roundness, radius, fadeout, shadow)
end

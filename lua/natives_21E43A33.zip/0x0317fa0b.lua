local fn = _gn(0x0EDEC3C276198689)
function Global.PedToNet(ped)
	return _in2(fn, ped, _ri)
end

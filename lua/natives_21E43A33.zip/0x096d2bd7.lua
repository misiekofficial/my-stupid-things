local fn = _gn(0xE41885592B08B097)
function Global.TaskVehicleAimAtPed(ped, target)
	return _in2(fn, ped, target)
end

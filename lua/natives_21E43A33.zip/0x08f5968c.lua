local fn = _gn(0x6F6981D2253C208F)
function Global.HidePedWeaponForScriptedCutscene(ped, toggle)
	return _in2(fn, ped, toggle)
end

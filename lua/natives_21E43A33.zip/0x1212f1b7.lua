local fn = _gn(0xE4973DBDBE6E44B3)
function Global.UpdateTaskSweepAimEntity(ped, entity)
	return _in2(fn, ped, entity)
end

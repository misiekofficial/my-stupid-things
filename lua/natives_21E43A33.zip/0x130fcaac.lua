local fn = _gn(0x18F621F7A5B1F85D)
function Global.SetNightvision(Toggle)
	return _in2(fn, Toggle)
end

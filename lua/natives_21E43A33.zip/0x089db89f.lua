local fn = _gn(0x271401846BD26E92)
function Global.N_0x271401846bd26e92(p0, p1)
	return _in2(fn, p0, p1)
end

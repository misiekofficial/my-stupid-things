local fn = _gn(0xF9C1681347C8BD15)
function Global.N_0xf9c1681347c8bd15(object)
	return _in2(fn, object)
end

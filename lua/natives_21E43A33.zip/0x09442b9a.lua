local fn = _gn(0x2FBF47B1B36D36F9)
function Global.NetworkSessionCancelInvite()
	return _in2(fn)
end

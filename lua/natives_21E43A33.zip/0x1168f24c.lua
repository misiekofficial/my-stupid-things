local fn = _gn(0xFF266D1D0EB1195D)
function Global.N_0xff266d1d0eb1195d()
	return _in2(fn)
end

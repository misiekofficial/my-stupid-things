local fn = _gn(0x7b0d00c5)
--- A getter for [SET_RANDOM_VEHICLE_DENSITY_MULTIPLIER_THIS_FRAME](#\_0xB3B3359379FE77D3).
-- Same as vehicle density multiplier.
-- @return Returns random vehicle density multiplier value.
function Global.GetRandomVehicleDensityMultiplier()
	return _in2(fn, _rf)
end

local fn = _gn(0x7A1ADEEF01740A24)
function Global.NetworkGetDestroyerOfNetworkId(p0, p1)
	return _in2(fn, p0, _ii(p1) --[[ may be optional ]], _ri)
end

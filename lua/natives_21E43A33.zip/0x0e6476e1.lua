local fn = _gn(0x5BC9495F0B3B6FA6)
function Global.NetworkHasControlOfPickup(p0)
	return _in2(fn, p0, _r)
end

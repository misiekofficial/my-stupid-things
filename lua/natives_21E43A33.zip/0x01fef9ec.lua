local fn = _gn(0xCC9682B8951C5229)
function Global.N_0xcc9682b8951c5229(p0, p1, p2, p3, p4)
	return _in2(fn, p0, p1, p2, p3, p4)
end

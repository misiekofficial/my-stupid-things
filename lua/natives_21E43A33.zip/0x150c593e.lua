local fn = _gn(0x43286D561B72B8BF)
function Global.SetPoliceRadarBlips(toggle)
	return _in2(fn, toggle)
end

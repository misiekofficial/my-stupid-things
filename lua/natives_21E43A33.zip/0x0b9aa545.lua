local fn = _gn(0x09693B0312F91649)
function Global.TaskRappelFromHeli(ped, p1)
	return _in2(fn, ped, p1)
end

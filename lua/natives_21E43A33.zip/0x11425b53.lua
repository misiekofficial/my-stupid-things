local fn = _gn(0x4e129dbf)
--- FIND_NEXT_OBJECT
function Global.FindNextObject(findHandle, outEntity)
	return _in2(fn, findHandle, _ii(outEntity) --[[ may be optional ]], _r)
end

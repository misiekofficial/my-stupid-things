local fn = _gn(0x3B3CAD6166916D87)
function Global.PreloadScriptConversation(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3)
end

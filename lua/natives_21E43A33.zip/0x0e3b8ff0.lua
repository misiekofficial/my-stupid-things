local fn = _gn(0xDCD4EA924F42D01A)
function Global.SetWidescreenBorders(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

local fn = _gn(0xAD5FDF34B81BFE79)
function Global.N_0xad5fdf34b81bfe79()
	return _in2(fn)
end

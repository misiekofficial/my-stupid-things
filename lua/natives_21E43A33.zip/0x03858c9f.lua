local fn = _gn(0x3F892CAF67444AE7)
function Global.CreateIncident(x, y, z, radius)
	return _in2(fn, _i, x, y, z, _i, radius, _i, _r)
end

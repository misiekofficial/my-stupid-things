local fn = _gn(0xB16FCE9DDC7BA182)
function Global.IsScreenFadedOut()
	return _in2(fn, _r)
end

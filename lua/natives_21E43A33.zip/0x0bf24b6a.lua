local fn = _gn(0x80ad144c)
--- This native allows you to update the bounds of a specified water quad index.
-- @param waterQuad The water quad index
-- @param minX The minX coordinate
-- @param minY The minY coordinate
-- @param maxX The maxX coordinate
-- @param maxY The maxY coordinate
-- @return Returns true on success.
function Global.SetWaterQuadBounds(waterQuad, minX, minY, maxX, maxY)
	return _in2(fn, waterQuad, minX, minY, maxX, maxY, _r)
end

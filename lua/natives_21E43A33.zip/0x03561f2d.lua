local fn = _gn(0x1B1E2A40A65B8521)
function Global.SetAiWeaponDamageModifier(value)
	return _in2(fn, value)
end

local fn = _gn(0xA51C4B86B71652AE)
function Global.N_0xa51c4b86b71652ae(p0)
	return _in2(fn, p0)
end

local fn = _gn(0x437138B6A830166A)
function Global.N_0x437138b6a830166a()
	return _in2(fn)
end

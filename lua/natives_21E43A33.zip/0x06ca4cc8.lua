local fn = _gn(0x88CBB5CEB96B7BD2)
function Global.SetPedStealthMovement(ped, p1, action)
	return _in2(fn, ped, p1, _ts(action))
end

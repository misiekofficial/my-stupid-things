local fn = _gn(0xdf62cfe2)
--- Resets whether or not peds can stand on top of the specified vehicle.
-- Note this flag is not replicated automatically, you will have to manually do so.
-- @param vehicle The vehicle.
function Global.ResetVehiclePedsCanStandOnTopFlag(vehicle)
	return _in2(fn, vehicle)
end

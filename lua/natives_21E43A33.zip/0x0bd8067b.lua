local fn = _gn(0xED712CA327900C8A)
function Global.SetWeatherTypeNowPersist(weatherType)
	return _in2(fn, _ts(weatherType))
end

local fn = _gn(0x726256CC1EEB182F)
function Global.ClearFacialIdleAnimOverride(p0)
	return _in2(fn, p0)
end

local fn = _gn(0x15C40837039FFAF7)
function Global.GetFrameTime()
	return _in2(fn, _rf)
end

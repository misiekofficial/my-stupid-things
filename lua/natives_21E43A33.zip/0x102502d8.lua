local fn = _gn(0x61E1DD6125A3EEE6)
function Global.IsAnyVehicleNearPoint(x, y, z, radius)
	return _in2(fn, x, y, z, radius, _r)
end

local fn = _gn(0xEEED8FAFEC331A70)
function Global.N_0xeeed8fafec331a70(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3, _ri)
end

local fn = _gn(0x0E48D1C262390950)
function Global.GetTotalDurationOfVehicleRecording(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

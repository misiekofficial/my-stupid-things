local fn = _gn(0x608207E7A8FB787C)
function Global.SetAllLowPriorityVehicleGeneratorsActive(active)
	return _in2(fn, active)
end

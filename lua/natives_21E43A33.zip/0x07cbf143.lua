local fn = _gn(0x3dd8130f)
--- Gets the selected entity at the current mouse cursor position, and changes the current selection depth. This function supports SDK infrastructure and is not intended to be used directly from your code.
-- @param hitFlags A bit mask of entity types to match.
-- @param precise Whether to do a *precise* test, i.e. of visual coordinates, too.
-- @return An entity handle, or zero.
function Global.SelectEntityAtCursor(hitFlags, precise)
	return _in2(fn, hitFlags, precise, _ri)
end

local fn = _gn(0x129466ED55140F8D)
function Global.N_0x129466ed55140f8d(p0, p1)
	return _in2(fn, p0, p1)
end

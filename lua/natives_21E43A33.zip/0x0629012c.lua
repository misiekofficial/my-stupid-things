local fn = _gn(0xB9BB18E2C40142ED)
function Global.LeaderboardsCacheDataRow(p0)
	return _in2(fn, _ii(p0) --[[ may be optional ]], _r)
end

local fn = _gn(0xB85F26619073E775)
function Global.SetHdArea(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3)
end

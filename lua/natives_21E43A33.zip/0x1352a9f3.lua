local fn = _gn(0x10BD227A753B0D84)
function Global.N_0x10bd227a753b0d84()
	return _in2(fn, _ri)
end

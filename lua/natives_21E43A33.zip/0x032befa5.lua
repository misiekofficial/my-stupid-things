local fn = _gn(0x4EBB7E87AA0DBED4)
function Global.N_0x4ebb7e87aa0dbed4(p0)
	return _in2(fn, p0)
end

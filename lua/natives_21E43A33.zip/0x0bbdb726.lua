local fn = _gn(0x694E00132F2823ED)
function Global.N_0x694e00132f2823ed(p0, p1)
	return _in2(fn, p0, p1)
end

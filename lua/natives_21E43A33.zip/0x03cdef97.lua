local fn = _gn(0xB3924ECD70E095DC)
function Global.GetVehicleModVariation(vehicle, modType)
	return _in2(fn, vehicle, modType, _r)
end

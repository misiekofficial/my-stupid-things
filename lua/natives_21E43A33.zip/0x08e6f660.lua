local fn = _gn(0x3910051CCECDB00C)
function Global.N_0x3910051ccecdb00c(entity, p1)
	return _in2(fn, entity, p1)
end

local fn = _gn(0xc3c93f28)
--- A getter for [SET_VEHICLE_CHEAT_POWER_INCREASE](#\_0xB59E4BD37AE292DB).
-- @param vehicle The target vehicle.
-- @return Returns vehicle's cheat power increase modifier value.
function Global.GetVehicleCheatPowerIncrease(vehicle)
	return _in2(fn, vehicle, _rf)
end

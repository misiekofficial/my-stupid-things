local fn = _gn(0x26695EC767728D84)
function Global.N_0x26695ec767728d84(p0, p1)
	return _in2(fn, p0, p1)
end

local fn = _gn(0x1B7ABE26CBCBF8C7)
function Global.N_0x1b7abe26cbcbf8c7(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

local fn = _gn(0xE57397B4A3429DD0)
function Global.NetworkSessionGetInviter(p0)
	return _in2(fn, _ii(p0) --[[ may be optional ]])
end

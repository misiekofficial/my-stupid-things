local fn = _gn(0xCCF1E97BEFDAE480)
function Global.N_0xccf1e97befdae480(p0)
	return _in2(fn, p0, _r)
end

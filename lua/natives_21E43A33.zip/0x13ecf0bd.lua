local fn = _gn(0x5F7D596BAC2E7777)
function Global.OverridePopscheduleVehicleModel(scheduleId, vehicleHash)
	return _in2(fn, scheduleId, _ch(vehicleHash))
end

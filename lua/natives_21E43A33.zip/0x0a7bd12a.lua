local fn = _gn(0x13AD665062541A7E)
function Global.OverrideTrevorRage(p0)
	return _in2(fn, _ii(p0) --[[ may be optional ]])
end

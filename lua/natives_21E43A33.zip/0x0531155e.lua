local fn = _gn(0xFF4FB7C8CDFA3DA7)
function Global.ClearGpsPlayerWaypoint()
	return _in2(fn)
end

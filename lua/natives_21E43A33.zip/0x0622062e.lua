local fn = _gn(0xA6F6F70FDC6D144C)
function Global.RemoveDecalsFromObjectFacing(obj, x, y, z)
	return _in2(fn, obj, x, y, z)
end

local fn = _gn(0x3CF48F6F96E749DC)
function Global.SetCamDofPlanes(cam, p1, p2, p3, p4)
	return _in2(fn, cam, p1, p2, p3, p4)
end

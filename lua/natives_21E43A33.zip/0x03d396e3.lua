local fn = _gn(0x1CA3E9EAC9D93E5E)
function Global.SetTextDropShadow()
	return _in2(fn)
end

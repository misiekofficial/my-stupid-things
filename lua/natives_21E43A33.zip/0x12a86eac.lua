local fn = _gn(0x5CE587FB5A42C8C4)
function Global.Leaderboards2ReadByRadius(p1)
	return _in2(fn, _i, p1, _i, _r)
end

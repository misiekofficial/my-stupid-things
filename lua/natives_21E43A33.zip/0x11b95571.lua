local fn = _gn(0xEA241BB04110F091)
function Global.SetPlayerAngry(player, IsAngry)
	return _in2(fn, player, IsAngry)
end

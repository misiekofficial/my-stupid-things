local fn = _gn(0x9DCFF2AFB68B3476)
function Global.NetworkGetFoundGamer(p1)
	return _in2(fn, _i, p1, _r)
end

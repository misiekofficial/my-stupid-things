local fn = _gn(0x957E790EA1727B64)
function Global.ClearCloudHat()
	return _in2(fn)
end

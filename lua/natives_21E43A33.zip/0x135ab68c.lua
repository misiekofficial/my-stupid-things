local fn = _gn(0x9C00E77AF14B2DFF)
function Global.TaskGetOffBoat(p0, p1)
	return _in2(fn, p0, p1)
end

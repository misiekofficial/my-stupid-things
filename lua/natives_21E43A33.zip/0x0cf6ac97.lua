local fn = _gn(0x428BACCDF5E26EAD)
function Global.N_0x428baccdf5e26ead(p0, p1)
	return _in2(fn, p0, p1)
end

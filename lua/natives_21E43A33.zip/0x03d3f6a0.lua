local fn = _gn(0x3F4D00167E41E0AD)
function Global.N_0x3f4d00167e41e0ad(p0, p1, p2, p3, p4, p5, p6, p7, p8)
	return _in2(fn, p0, p1, p2, p3, p4, p5, p6, p7, p8)
end

local fn = _gn(0x218297BF0CFD853B)
function Global.N_0x218297bf0cfd853b(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

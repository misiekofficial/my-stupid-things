local fn = _gn(0x551DF99658DB6EE8)
function Global.N_0x551df99658db6ee8(p0, p1, p2)
	return _in2(fn, p0, p1, p2, _ri)
end

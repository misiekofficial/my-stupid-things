local fn = _gn(0x4F7D8A9BFB0B43E9)
function Global.SetBlipRoute(blip, enabled)
	return _in2(fn, blip, enabled)
end

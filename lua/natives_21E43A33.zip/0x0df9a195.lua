local fn = _gn(0xBCBFCD9D1DAC19E2)
function Global.N_0xbcbfcd9d1dac19e2(p0, p1)
	return _in2(fn, p0, p1)
end

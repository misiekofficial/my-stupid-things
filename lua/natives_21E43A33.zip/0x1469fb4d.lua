local fn = _gn(0x602E548F46E24D59)
function Global.RollUpWindow(vehicle, windowIndex)
	return _in2(fn, vehicle, windowIndex, _ri)
end

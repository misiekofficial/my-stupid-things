local fn = _gn(0xC91C6C55199308CA)
function Global.N_0xc91c6c55199308ca(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3)
end

local fn = _gn(0x6EB5F71AA68F2E8E)
function Global.RequestScript(scriptName)
	return _in2(fn, _ts(scriptName))
end

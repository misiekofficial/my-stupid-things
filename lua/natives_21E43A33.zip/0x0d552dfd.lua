local fn = _gn(0xF7D82B0D66777611)
function Global.RemoveWeaponComponentFromWeaponObject(p0, p1)
	return _in2(fn, p0, p1)
end

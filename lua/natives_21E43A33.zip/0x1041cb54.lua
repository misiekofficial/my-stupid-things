local fn = _gn(0x97DD4C5944CC2E6A)
function Global.N_0x97dd4c5944cc2e6a(p0, p1)
	return _in2(fn, p0, p1)
end

local fn = _gn(0x55DF6DB45179236E)
function Global.N_0x55df6db45179236e()
	return _in2(fn)
end

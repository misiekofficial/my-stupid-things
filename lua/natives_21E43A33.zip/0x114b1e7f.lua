local fn = _gn(0x729E3401F0430686)
function Global.N_0x729e3401f0430686()
	return _in2(fn, _i, _i, _r)
end

local fn = _gn(0xeeb9b76a)
--- Activates built-in timecycle editing tool.
function Global.ActivateTimecycleEditor()
	return _in2(fn)
end

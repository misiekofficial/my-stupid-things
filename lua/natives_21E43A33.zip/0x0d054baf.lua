local fn = _gn(0x12782CE0A636E9F0)
function Global.ResetReticuleValues()
	return _in2(fn)
end

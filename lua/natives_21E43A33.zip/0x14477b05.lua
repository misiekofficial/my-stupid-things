local fn = _gn(0x5BFF36D6ED83E0AE)
function Global.N_0x5bff36d6ed83e0ae()
	return _in2(fn, _rv)
end

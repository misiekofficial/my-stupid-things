local fn = _gn(0xF8155A7F03DDFC8E)
function Global.N_0xf8155a7f03ddfc8e(p0)
	return _in2(fn, p0)
end

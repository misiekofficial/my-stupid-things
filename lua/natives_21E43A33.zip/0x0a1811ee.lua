local fn = _gn(0x1da4791)
--- Resets the water to the games default water.xml.
function Global.ResetWater()
	return _in2(fn)
end

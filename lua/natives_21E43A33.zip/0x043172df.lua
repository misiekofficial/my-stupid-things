local fn = _gn(0xF113E3AA9BC54613)
function Global.SpecialAbilityChargeMedium(player, p1, p2)
	return _in2(fn, player, p1, p2)
end

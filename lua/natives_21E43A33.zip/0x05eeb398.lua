local fn = _gn(0xEB2BF817463DFA28)
function Global.N_0xeb2bf817463dfa28(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

local fn = _gn(0xB2C086CC1BF8F2BF)
function Global.IsPedDoingDriveby(ped)
	return _in2(fn, ped, _r)
end

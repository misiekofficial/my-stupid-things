local fn = _gn(0x346EF3ECAAAB149E)
function Global.N_0x346ef3ecaaab149e()
	return _in2(fn)
end

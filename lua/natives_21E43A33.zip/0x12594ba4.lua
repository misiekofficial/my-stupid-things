local fn = _gn(0x99974721)
--- Gets the door count for the specified train.
-- @param train The train to obtain the door count for.
-- @return The door count.
function Global.GetTrainDoorCount(train)
	return _in2(fn, train, _ri)
end

local fn = _gn(0x59BF8C3D52C92F66)
function Global.SetVehicleCanBreak(vehicle, Toggle)
	return _in2(fn, vehicle, Toggle, _ri)
end

local fn = _gn(0x1201E8A3290A3B98)
function Global.N_0x1201e8a3290a3b98(p0, p1)
	return _in2(fn, p0, p1)
end

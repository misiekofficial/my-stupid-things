local fn = _gn(0x3ff5e5f8)
--- SET_NUI_FOCUS_KEEP_INPUT
function Global.SetNuiFocusKeepInput(keepInput)
	return _in2(fn, keepInput)
end

local fn = _gn(0x90532EDF0D2BDD86)
function Global.DetachVehicleFromTrailer(vehicle)
	return _in2(fn, vehicle)
end

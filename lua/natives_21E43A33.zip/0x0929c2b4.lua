local fn = _gn(0x92C47782FDA8B2A3)
function Global.CreateModelSwap(p0, p1, p2, p3, p4, p5, p6)
	return _in2(fn, p0, p1, p2, p3, p4, p5, p6)
end

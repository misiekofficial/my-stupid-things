local fn = _gn(0xF33AB75780BA57DE)
function Global.StopCamPointing(cam)
	return _in2(fn, cam)
end

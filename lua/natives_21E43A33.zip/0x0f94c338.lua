local fn = _gn(0x8E02D73914064223)
function Global.NetworkAddFriend()
	return _in2(fn, _i, _i, _r)
end

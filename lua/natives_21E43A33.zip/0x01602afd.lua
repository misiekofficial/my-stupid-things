local fn = _gn(0xEB709A36958ABE0D)
function Global.N_0xeb709a36958abe0d(p0)
	return _in2(fn, p0, _r)
end

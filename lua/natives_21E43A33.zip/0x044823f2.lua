local fn = _gn(0x6D0858B8EDFD2B7D)
function Global.SetGameplayCamRelativePitch(x, Value2)
	return _in2(fn, x, Value2, _ri)
end

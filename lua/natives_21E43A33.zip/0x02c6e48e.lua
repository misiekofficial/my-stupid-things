local fn = _gn(0xE902EF951DCE178F)
function Global.GetPlayerRgbColour(player)
	return _in2(fn, player, _i, _i, _i)
end

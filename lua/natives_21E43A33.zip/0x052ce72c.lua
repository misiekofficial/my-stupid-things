local fn = _gn(0x40763EA7B9B783E7)
function Global.N_0x40763ea7b9b783e7(p0, p1, p2)
	return _in2(fn, p0, p1, p2, _ri)
end

local fn = _gn(0x1B1AB132A16FDA55)
function Global.ClearReplayStats()
	return _in2(fn)
end

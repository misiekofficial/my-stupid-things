local fn = _gn(0x2B6D467DAB714E8D)
function Global.N_0x2b6d467dab714e8d(blip, toggle)
	return _in2(fn, blip, toggle)
end

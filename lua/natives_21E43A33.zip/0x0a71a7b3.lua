local fn = _gn(0xE7FFAE5EBF23D890)
function Global.DrawSprite(textureDict, textureName, screenX, screenY, scaleX, scaleY, heading, colorR, colorG, colorB, colorA)
	return _in2(fn, _ts(textureDict), _ts(textureName), screenX, screenY, scaleX, scaleY, heading, colorR, colorG, colorB, colorA)
end

local fn = _gn(0xEDF7F927136C224B)
function Global.N_0xedf7f927136c224b()
	return _in2(fn, _ri)
end

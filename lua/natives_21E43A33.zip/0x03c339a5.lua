local fn = _gn(0x68B2B5F33BA63C41)
function Global.PointCamAtPedBone(cam, ped, boneIndex, x, y, z, p6)
	return _in2(fn, cam, ped, boneIndex, x, y, z, p6)
end

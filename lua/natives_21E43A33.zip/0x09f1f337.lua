local fn = _gn(0xB0034A223497FFCB)
function Global.IsPauseMenuActive()
	return _in2(fn, _r)
end

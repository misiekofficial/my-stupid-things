local fn = _gn(0x07F1BE2BCCAA27A7)
function Global.FindAnimEventPhase(animDict, animation, p2)
	return _in2(fn, _ts(animDict), _ts(animation), _ts(p2), _i, _i, _r)
end

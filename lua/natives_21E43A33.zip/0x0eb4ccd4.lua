local fn = _gn(0x1F2E4E06DEA8992B)
function Global.N_0x1f2e4e06dea8992b(p0, p1)
	return _in2(fn, p0, p1)
end

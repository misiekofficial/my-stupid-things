local fn = _gn(0x395BF71085D1B1D9)
function Global.SetAggressiveHorns(toggle)
	return _in2(fn, toggle)
end

local fn = _gn(0x63C6CCA8E68AE8C8)
function Global.CreateMissionTrain(variation, x, y, z, direction)
	return _in2(fn, variation, x, y, z, direction, _ri)
end

local fn = _gn(0x820E9892A77E97CD)
function Global.N_0x820e9892a77e97cd(p0, p1)
	return _in2(fn, p0, p1)
end

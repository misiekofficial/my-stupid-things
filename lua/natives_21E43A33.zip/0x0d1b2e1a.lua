local fn = _gn(0x755D6D5267CBBD7E)
function Global.N_0x755d6d5267cbbd7e(p0)
	return _in2(fn, p0, _r)
end

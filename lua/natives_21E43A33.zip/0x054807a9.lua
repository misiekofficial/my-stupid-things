local fn = _gn(0x6806C51AD12B83B8)
function Global.HideHudComponentThisFrame(id)
	return _in2(fn, id)
end

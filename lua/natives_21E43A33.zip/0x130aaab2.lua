local fn = _gn(0x40b16551)
--- Gets the ratio that a door is open for on a train.
-- @param train The train to obtain the door ratio for.
-- @param doorIndex Zero-based door index.
-- @return A value between 0.0 (fully closed) and 1.0 (fully open).
function Global.GetTrainDoorOpenRatio(train, doorIndex)
	return _in2(fn, train, doorIndex, _rf)
end

local fn = _gn(0xB4C7A93837C91A1F)
function Global.GetLiveryName(vehicle, livery)
	return _in2(fn, vehicle, _ts(livery), _s)
end

local fn = _gn(0x8B6A4DD0AF9CE215)
function Global.N_0x8b6a4dd0af9ce215(p0, p1)
	return _in2(fn, p0, p1)
end

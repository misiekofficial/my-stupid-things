local fn = _gn(0x5D517B27CF6ECD04)
function Global.N_0x5d517b27cf6ecd04(p0)
	return _in2(fn, p0)
end

local fn = _gn(0xCE5F689CF5A0A49D)
function Global.NetworkGetPlayerFromGamerHandle(p0)
	return _in2(fn, _ii(p0) --[[ may be optional ]], _ri)
end

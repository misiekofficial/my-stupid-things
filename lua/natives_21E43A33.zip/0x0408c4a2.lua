local fn = _gn(0x01A358D9128B7A86)
function Global.N_0x01a358d9128b7a86()
	return _in2(fn, _ri)
end

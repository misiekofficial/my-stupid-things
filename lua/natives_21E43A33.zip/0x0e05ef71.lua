local fn = _gn(0xA6DB27D19ECBB7DA)
function Global.DoesBlipExist(blip)
	return _in2(fn, blip, _r)
end

local fn = _gn(0xD76632D99E4966C8)
function Global.SetPedToRagdollWithFall(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13)
	return _in2(fn, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, _ri)
end

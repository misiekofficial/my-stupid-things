local fn = _gn(0xD801CC02177FA3F1)
function Global.N_0xd801cc02177fa3f1()
	return _in2(fn)
end

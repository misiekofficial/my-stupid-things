local fn = _gn(0xA0696A65F009EE18)
function Global.ResetSpecialAbilityControlsCinematic(player, p1, p2)
	return _in2(fn, player, p1, p2)
end

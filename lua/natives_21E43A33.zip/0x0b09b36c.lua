local fn = _gn(0x29A16F8D621C4508)
function Global.AttachVehicleToTowTruck(towTruck, vehicle, p2, x, y, z)
	return _in2(fn, towTruck, vehicle, p2, x, y, z)
end

local fn = _gn(0x61767F73EACEED21)
function Global.N_0x61767f73eaceed21(p0)
	return _in2(fn, p0, _r)
end

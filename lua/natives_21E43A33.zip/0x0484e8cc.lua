local fn = _gn(0x920D853F3E17F1DA)
function Global.N_0x920d853f3e17f1da(p0, p1)
	return _in2(fn, p0, p1)
end

local fn = _gn(0x26143A59EF48B262)
function Global.SetParticleFxNonLoopedColour(r, g, b)
	return _in2(fn, r, g, b)
end

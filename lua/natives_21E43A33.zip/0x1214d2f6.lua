local fn = _gn(0xBE3E347A87ACEB82)
function Global.N_0xbe3e347a87aceb82(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3, _r)
end

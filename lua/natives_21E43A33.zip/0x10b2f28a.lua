local fn = _gn(0xF166E48407BAC484)
function Global.TaskCombatPed(ped, targetPed, p2, p3)
	return _in2(fn, ped, targetPed, p2, p3)
end

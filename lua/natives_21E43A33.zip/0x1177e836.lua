local fn = _gn(0xE26CCFF8094D8C74)
function Global.UsingNetworkWeapontype(p0)
	return _in2(fn, p0, _r)
end

local fn = _gn(0x2F395D61F3A1F877)
function Global.GetPlayerCurrentStealthNoise(player)
	return _in2(fn, player, _rf)
end

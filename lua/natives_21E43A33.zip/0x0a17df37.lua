local fn = _gn(0x2902843FCD2B2D79)
function Global.GetEventData(p0, eventIndex, p3)
	return _in2(fn, p0, eventIndex, _i, p3, _r)
end

local fn = _gn(0x121F0593E0A431D7)
function Global.VehicleWaypointPlaybackOverrideSpeed(p0, p1)
	return _in2(fn, p0, p1)
end

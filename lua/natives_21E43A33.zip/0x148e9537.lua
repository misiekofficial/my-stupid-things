local fn = _gn(0xFB71170B7E76ACBA)
function Global.GetEntityBoneIndexByName(entity, boneName)
	return _in2(fn, entity, _ts(boneName), _ri)
end

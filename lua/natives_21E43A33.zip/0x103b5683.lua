local fn = _gn(0xB1CC1B9EC3007A2A)
function Global.N_0xb1cc1b9ec3007a2a(p0)
	return _in2(fn, p0)
end

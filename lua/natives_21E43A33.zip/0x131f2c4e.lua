local fn = _gn(0xAEEDAD1420C65CC0)
function Global.SetForcePedFootstepsTracks(enabled)
	return _in2(fn, enabled)
end

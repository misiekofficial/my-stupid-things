local fn = _gn(0x5F43D83FD6738741)
function Global.N_0x5f43d83fd6738741()
	return _in2(fn, _ri)
end

local fn = _gn(0x419615486BBF1956)
function Global.N_0x419615486bbf1956(p0)
	return _in2(fn, p0)
end

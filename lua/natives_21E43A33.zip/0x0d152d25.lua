local fn = _gn(0x20510814175EA477)
function Global.ResetPedStrafeClipset(ped)
	return _in2(fn, ped)
end

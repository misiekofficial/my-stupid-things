local fn = _gn(0xF3BBE884A14BB413)
function Global.GetWeatherTypeTransition()
	return _in2(fn, _i, _i, _f)
end

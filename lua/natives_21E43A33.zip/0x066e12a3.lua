local fn = _gn(0x2468dbe8)
--- Sets the ratio that a door is open for on a train.
-- @param train The train to set the door ratio for.
-- @param doorIndex Zero-based door index.
-- @param ratio A value between 0.0 (fully closed) and 1.0 (fully open).
function Global.SetTrainDoorOpenRatio(train, doorIndex, ratio)
	return _in2(fn, train, doorIndex, ratio)
end

local fn = _gn(0x06FAACD625D80CAA)
--- NETWORK_REGISTER_ENTITY_AS_NETWORKED
function Global.N_0x06faacd625d80caa(entity)
	return _in2(fn, entity)
end

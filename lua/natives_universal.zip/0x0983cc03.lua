local fn = _gn(0xBA751764F0821256)
--- SUPPRESS_FRONTEND_RENDERING_THIS_FRAME
function Global.N_0xba751764f0821256()
	return _in2(fn)
end

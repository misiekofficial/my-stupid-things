local fn = _gn(0x534E36D4DB9ECC5D)
--- Checks if vehicle tyre at index exists. Also returns false if tyre was removed.
-- ```
-- ```
-- NativeDB Introduced: v1493
function Global.DoesVehicleTyreExist(vehicle, tyreIndex)
	return _in2(fn, vehicle, tyreIndex, _r)
end

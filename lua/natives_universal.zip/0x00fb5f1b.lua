local fn = _gn(0x806058BBDC136E06)
--- Stops audio for the current cutscene.
function Global.StopCutsceneAudio()
	return _in2(fn)
end

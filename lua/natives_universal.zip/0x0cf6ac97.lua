local fn = _gn(0x428BACCDF5E26EAD)
--- SET_VEHICLE_CAN_SAVE_IN_GARAGE
function Global.N_0x428baccdf5e26ead(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

local fn = _gn(0xE2BB399D90942091)
--- NativeDB Introduced: v2189
function Global.N_0xe2bb399d90942091(p0, p1)
	return _in2(fn, p0, p1)
end

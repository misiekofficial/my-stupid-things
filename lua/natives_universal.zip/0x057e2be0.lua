local fn = _gn(0xACB5DCCA1EC76840)
--- GET_VEHICLE_DEFAULT_HORN_IGNORE_MODS
-- @return Returns the horn sound hash ignoring any horn mods applied to the car
function Global.GetVehicleDefaultHornIgnoreMods(vehicle)
	return _in2(fn, vehicle, _ri)
end

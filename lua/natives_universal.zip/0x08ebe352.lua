local fn = _gn(0xE5608CA7BC163A5F)
--- NETWORK_ACCESS_TUNABLE_FLOAT
function Global.N_0xe5608ca7bc163a5f(tunableContext, tunableName, value)
	return _in2(fn, _ts(tunableContext), _ts(tunableName), _fi(value) --[[ may be optional ]], _r)
end

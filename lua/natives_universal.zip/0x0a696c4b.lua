local fn = _gn(0x4D79439A6B55AC67)
--- IS_HELP_MESSAGE_BEING_DISPLAYED
function Global.IsHelpMessageBeingDisplayed()
	return _in2(fn, _r)
end

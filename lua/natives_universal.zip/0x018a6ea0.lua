local fn = _gn(0x35A1B3E1D1315CFA)
--- Note: only one of the arguments can be set to true at a time
function Global.NetGameserverGetBalance(inventory, playerbalance)
	return _in2(fn, inventory, playerbalance, _r)
end

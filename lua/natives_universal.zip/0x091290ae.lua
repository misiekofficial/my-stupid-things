local fn = _gn(0x10BD227A753B0D84)
--- Actually returns the version (TUNABLE_VERSION)
function Global.NetworkGetTunableCloudCrc()
	return _in2(fn, _ri)
end

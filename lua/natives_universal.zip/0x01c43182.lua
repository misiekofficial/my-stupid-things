local fn = _gn(0x80FE4F3AB4E1B62A)
--- THEFEED_CLEAR_FROZEN_POST
function Global.ThefeedClearFrozenPost()
	return _in2(fn)
end

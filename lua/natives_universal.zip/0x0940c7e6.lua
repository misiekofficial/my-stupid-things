local fn = _gn(0x3353D13F09307691)
--- Sets (almost, not sure) all Rockstar Editor values (bIsRecording etc) to 0.
function Global.ResetEditorValues()
	return _in2(fn)
end

local fn = _gn(0x17FCA7199A530203)
--- 0x17FCA7199A530203
function Global.N_0x17fca7199a530203()
	return _in2(fn)
end

local fn = _gn(0xD9F8455409B525E9)
--- eventType: https://alloc8or.re/gta5/doc/enums/eEventType.txt
function Global.AddShockingEventAtPosition(eventType, x, y, z, duration)
	return _in2(fn, eventType, x, y, z, duration, _ri)
end

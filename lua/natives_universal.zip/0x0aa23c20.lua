local fn = _gn(0xDEADC0DEDEADC0DE)
--- UPDATE_LIGHTS_ON_ENTITY
function Global.UpdateLightsOnEntity(entity)
	return _in2(fn, entity)
end

local fn = _gn(0x89023FBBF9200E9F)
--- Returns the same value as [`GetNetworkTime`](#\_0x7A5487FE9FAA6B48) in freemode, but as opposed to `GetNetworkTime` it always gets the most recent time, instead of once per tick.
-- Could be used for benchmarking since it can return times in ticks.
-- @return Returns the network time as an integer
function Global.GetNetworkTimeAccurate()
	return _in2(fn, _ri)
end

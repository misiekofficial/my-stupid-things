local fn = _gn(0x6D0858B8EDFD2B7D)
--- This native sets the camera's pitch (rotation on the x-axis).
-- @param angle the angle to rotate the camera by
-- @param scalingFactor always seems to be set to 1.0 in native calls
function Global.SetGameplayCamRelativePitch(angle, scalingFactor)
	return _in2(fn, angle, scalingFactor)
end

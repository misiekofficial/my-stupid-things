local fn = _gn(0x2597A0D4A4FC2C77)
--- NativeDB Introduced: v1290
function Global.NetworkEarnFromGangopsElite(amount, unk, actIndex)
	return _in2(fn, amount, _ts(unk), actIndex)
end

local fn = _gn(0x70EA8DA57840F9BE)
--- UGC_GET_CONTENT_HAS_PLAYER_RECORD
function Global.UgcGetContentHasPlayerRecord(p0)
	return _in2(fn, p0, _r)
end

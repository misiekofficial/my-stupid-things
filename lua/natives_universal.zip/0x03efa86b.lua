local fn = _gn(0xF8EBCCC96ADB9FB7)
--- Sets the arm position of a bulldozer. Position must be a value between 0.0 and 1.0. Ignored when `p2` is set to false, instead incrementing arm position by 0.1 (or 10%).
function Global.SetVehicleBulldozerArmPosition(vehicle, position, p2)
	return _in2(fn, vehicle, position, p2)
end

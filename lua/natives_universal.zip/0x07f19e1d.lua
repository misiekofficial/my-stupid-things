local fn = _gn(0xE86689E5F82DE429)
--- NativeDB Introduced: v2189
function Global.NetworkSpentIslandHeist(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3)
end

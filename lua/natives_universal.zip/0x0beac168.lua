local fn = _gn(0x0C1F7D49C39D2289)
--- GET_MAX_NUM_NETWORK_PEDS
function Global.N_0x0c1f7d49c39d2289()
	return _in2(fn, _ri)
end

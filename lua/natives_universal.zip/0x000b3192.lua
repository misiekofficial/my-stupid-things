local fn = _gn(0x9D26502BB97BFE62)
--- NETWORK_SPENT_REQUEST_HEIST
function Global.NetworkSpentRequestHeist(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

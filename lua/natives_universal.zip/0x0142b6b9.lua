local fn = _gn(0x75632C5ECD7ED843)
--- Starts a task to check an entered string for profanity on the ROS/Social Club services.
-- See also: [`SC_PROFANITY_GET_CHECK_IS_VALID`](#\_0x1753344C770358AE) and [`SC_PROFANITY_GET_CHECK_IS_PENDING`](#\_0x82E4A58BABC15AE7).
function Global.ScProfanityCheckString(string, token)
	return _in2(fn, _ts(string), _ii(token) --[[ may be optional ]], _r)
end

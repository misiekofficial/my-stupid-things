local fn = _gn(0xB3E6360DDE733E82)
--- WATER_OVERRIDE_SET_OCEANWAVEMAXAMPLITUDE
function Global.WaterOverrideSetOceanwavemaxamplitude(maxAmplitude)
	return _in2(fn, maxAmplitude)
end

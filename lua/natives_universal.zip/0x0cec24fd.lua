local fn = _gn(0x0350E7E17BA767D0)
--- NativeDB Introduced: v1365
function Global.N_0xcda42c4bb9bde779(vehicle, value)
	return _in2(fn, vehicle, value)
end

local fn = _gn(0x438822C279B73B93)
--- _SET_BEAST_MODE_ACTIVE
function Global.SetBeastModeActive(player)
	return _in2(fn, player)
end

local fn = _gn(0x22EF8FF8778030EB)
--- RESET_PED_IN_VEHICLE_CONTEXT
function Global.ResetPedInVehicleContext(ped)
	return _in2(fn, ped)
end

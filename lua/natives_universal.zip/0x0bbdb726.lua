local fn = _gn(0x694E00132F2823ED)
--- SET_ENTITY_R*
function Global.N_0x694e00132f2823ed(entity, toggle)
	return _in2(fn, entity, toggle)
end

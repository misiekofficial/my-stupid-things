local fn = _gn(0x887FA38787DE8C72)
--- NativeDB Introduced: v1365
function Global.N_0x887fa38787de8c72(vehicle)
	return _in2(fn, vehicle)
end

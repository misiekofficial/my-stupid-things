local fn = _gn(0x098AB65B9ED9A9EC)
--- _FACEBOOK_SET_HEIST_COMPLETE
function Global.N_0x098ab65b9ed9a9ec(heistName, cashEarned, xpEarned)
	return _in2(fn, _ts(heistName), cashEarned, xpEarned, _r)
end

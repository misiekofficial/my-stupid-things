local fn = _gn(0x8821196D91FA2DE5)
--- NativeDB Introduced: v1290
function Global.N_0x8821196d91fa2de5(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

local fn = _gn(0xA6575914D2A0B450)
--- GET_ROOM_KEY_FOR_GAME_VIEWPORT
function Global.GetRoomKeyForGameViewport()
	return _in2(fn, _ri)
end

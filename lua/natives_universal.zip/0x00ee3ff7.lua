local fn = _gn(0xAFF4710E2A0A6C12)
--- DROP_AMBIENT_PROP
function Global.DropAmbientProp(ped)
	return _in2(fn, ped)
end

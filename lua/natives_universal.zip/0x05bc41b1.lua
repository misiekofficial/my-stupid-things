local fn = _gn(0x95C5D356CDA6E85F)
--- APP_SAVE_DATA
function Global.AppSaveData()
	return _in2(fn)
end

local fn = _gn(0x6ADAABD3068C5235)
--- HAS_VEHICLE_PHONE_EXPLOSIVE_DEVICE
function Global.N_0x6adaabd3068c5235()
	return _in2(fn, _r)
end

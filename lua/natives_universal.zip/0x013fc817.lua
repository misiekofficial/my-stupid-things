local fn = _gn(0xC593212475FAE340)
--- HAS_PED_GOT_WEAPON_COMPONENT
function Global.HasPedGotWeaponComponent(ped, weaponHash, componentHash)
	return _in2(fn, ped, _ch(weaponHash), _ch(componentHash), _r)
end

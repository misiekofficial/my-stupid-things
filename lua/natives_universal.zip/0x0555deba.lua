local fn = _gn(0x26AA915AD89BFB4B)
--- IS_ENTITY_ATTACHED_TO_ANY_VEHICLE
function Global.IsEntityAttachedToAnyVehicle(entity)
	return _in2(fn, entity, _r)
end

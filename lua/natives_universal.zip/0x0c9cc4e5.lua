local fn = _gn(0x1A9205C1B9EE827F)
--- SET_ENTITY_COLLISION
function Global.SetEntityCollision(entity, toggle, keepPhysics)
	return _in2(fn, entity, toggle, keepPhysics)
end

local fn = _gn(0xB3924ECD70E095DC)
--- Only used for wheels(ModType = 23/24) Returns true if the wheels are custom wheels
-- @param modType Refer to eVehicleModType in [`SET_VEHICLE_MOD`](#\_0x6AF0636DDEDCB6DD).
function Global.GetVehicleModVariation(vehicle, modType)
	return _in2(fn, vehicle, modType, _r)
end

local fn = _gn(0x2F794A877ADD4C92)
--- STOP_ALL_ALARMS
-- @param instantStop Whether to kill the alarm instantly, or to let the audio system turn it off when it becomes inaudible
function Global.StopAllAlarms(instantStop)
	return _in2(fn, instantStop)
end

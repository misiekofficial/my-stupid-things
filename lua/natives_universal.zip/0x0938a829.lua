local fn = _gn(0x578C752848ECFA0C)
--- Refer to [`SET_WEATHER_TYPE_NOW_PERSIST`](#\_0xED712CA327900C8A) for weather types.
-- ```
-- Mixes two weather types. If percentWeather2 is set to 0.0f, then the weather will be entirely of weatherType1, if it is set to 1.0f it will be entirely of weatherType2. If it's set somewhere in between, there will be a mixture of weather behaviors. To test, try this in the RPH console, and change the float to different values between 0 and 1:
-- execute "NativeFunction.Natives.x578C752848ECFA0C(Game.GetHashKey(""RAIN""), Game.GetHashKey(""SMOG""), 0.50f);
-- ```
function Global.SetWeatherTypeTransition(weatherType1, weatherType2, percentWeather2)
	return _in2(fn, _ch(weatherType1), _ch(weatherType2), percentWeather2)
end

local fn = _gn(0x7B3703D2D32DFA18)
--- w is the correct parameter name!
function Global.GetEntityQuaternion(entity)
	return _in2(fn, entity, _f, _f, _f, _f)
end

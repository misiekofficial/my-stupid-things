local fn = _gn(0xB0034A223497FFCB)
--- IS_PAUSE_MENU_ACTIVE
function Global.IsPauseMenuActive()
	return _in2(fn, _r)
end

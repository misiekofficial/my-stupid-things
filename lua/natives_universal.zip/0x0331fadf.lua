local fn = _gn(0x8B6817B71B85EBF0)
--- IS_STREAMING_ADDITIONAL_TEXT
function Global.IsStreamingAdditionalText(p0)
	return _in2(fn, p0, _r)
end

local fn = _gn(0x0218BA067D249DEA)
--- 0x0218BA067D249DEA
function Global.N_0x0218ba067d249dea()
	return _in2(fn)
end

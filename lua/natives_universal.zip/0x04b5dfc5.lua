local fn = _gn(0x6f4acba)
--- GET_WATER_QUAD_NO_STENCIL
-- @param waterQuad The water quad index
-- @return Returns if the given water quad has no stencil.
function Global.GetWaterQuadNoStencil(waterQuad, noStencil)
	return _in2(fn, waterQuad, _ii(noStencil) --[[ may be optional ]], _r)
end

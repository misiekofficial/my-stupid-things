local fn = _gn(0x1DB21A44B09E8BA3)
--- If true is passed, the player won't be able to open the multiplayer chat
function Global.SetTextChatUnk(disable)
	return _in2(fn, disable)
end

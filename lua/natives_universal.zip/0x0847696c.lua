local fn = _gn(0xB264C4D2F2B0A78B)
--- This native it's a debug native. Won't do anything.
function Global.AllowAmbientVehiclesToAvoidAdverseConditions(vehicle)
	return _in2(fn, vehicle)
end

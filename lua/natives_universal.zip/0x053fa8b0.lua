local fn = _gn(0x5BCA583A583194DB)
--- _DRAW_SPOT_LIGHT_WITH_SHADOW
function Global.DrawSpotLightWithShadow(posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, roundness, radius, falloff, shadowId)
	return _in2(fn, posX, posY, posZ, dirX, dirY, dirZ, colorR, colorG, colorB, distance, brightness, roundness, radius, falloff, shadowId)
end

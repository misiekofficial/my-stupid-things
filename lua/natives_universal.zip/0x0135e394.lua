local fn = _gn(0x12217d33)
--- GET_HUD_COMPONENT_SIZE
-- @param id The hud component id.
-- @return A Vector3 with the hud component size X and size Y values.
function Global.GetHudComponentSize(id)
	return _in2(fn, id, _rv)
end

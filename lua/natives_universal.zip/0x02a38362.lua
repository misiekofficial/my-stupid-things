local fn = _gn(0x2170813D3DD8661B)
--- GET_TV_VOLUME
function Global.GetTvVolume()
	return _in2(fn, _rf)
end

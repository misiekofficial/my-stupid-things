local fn = _gn(0x77F33F2CCF64B3AA)
--- Overrides a flag on the object which determines if the object should be avoided by a vehicle in task: CTaskVehicleGoToPointWithAvoidanceAutomobile.
-- Tested on vehicles that were created by the vehicle generators.
function Global.SetObjectSomething(object, toggle)
	return _in2(fn, object, toggle)
end

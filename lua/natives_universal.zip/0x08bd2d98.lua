local fn = _gn(0x95CF53B3D687F9FA)
--- in the decompiled scripts, seems to be always called on the vehicle right after being attached to a trailer.
function Global.SetTrailerLegsRaised(vehicle)
	return _in2(fn, vehicle)
end

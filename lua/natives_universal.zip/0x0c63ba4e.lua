local fn = _gn(0x09E7ECA981D9B210)
--- NativeDB Introduced: v1290
function Global.IsPedBodyBlemishValid(colorID)
	return _in2(fn, colorID, _r)
end

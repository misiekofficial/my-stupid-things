local fn = _gn(0x85B6C850546FDDE2)
--- ARE_ENTITIES_ENTIRELY_INSIDE_GARAGE
function Global.AreEntitiesEntirelyInsideGarage(garageHash, p1, p2, p3, p4)
	return _in2(fn, _ch(garageHash), p1, p2, p3, p4, _r)
end

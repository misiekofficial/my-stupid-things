local fn = _gn(0x32C27A11307B01CC)
--- NativeDB Introduced: v2372
function Global.N_0x32c27a11307b01cc(ped, p1)
	return _in2(fn, ped, p1, _ri)
end

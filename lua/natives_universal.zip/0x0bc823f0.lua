local fn = _gn(0x0E3A041ED6AC2B45)
--- Same as _NETWORK_GET_AVERAGE_LATENCY_FOR_PLAYER (0xD414BE129BB81B32)
-- ```
-- ```
-- NativeDB Introduced: v323
function Global.N_0x0e3a041ed6ac2b45(player)
	return _in2(fn, player, _rf)
end

local fn = _gn(0x77C3CEC46BE286F6)
--- NativeDB Introduced: v2372
function Global.N_0x77c3cec46be286f6()
	return _in2(fn, _ri)
end

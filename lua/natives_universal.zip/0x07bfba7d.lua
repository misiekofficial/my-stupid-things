local fn = _gn(0x1093408B4B9D1146)
--- SET_VEHICLE_TURRET_SPEED_THIS_FRAME
function Global.SetVehicleTurretSpeedThisFrame(vehicle, speed)
	return _in2(fn, vehicle, speed)
end

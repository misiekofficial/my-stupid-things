local fn = _gn(0xF6829842C06AE524)
--- Retrieves the depth of the water beneath the specified position, accounting for the waves.
-- **Note:** The result might vary depending on the specific frame when this command is executed due to wave fluctuations.
-- @param x The coordinate at which to test at for water.
-- @param y The coordinate at which to test at for water.
-- @param z The coordinate at which to test at for water.
-- @param height The height at which to test at for water.
-- @return Returns `false` when land at the tested coordinates is higher than water, `true` otherwise.
function Global.GetWaterHeight(x, y, z, height)
	return _in2(fn, x, y, z, _fi(height) --[[ may be optional ]], _r)
end

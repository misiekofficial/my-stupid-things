local fn = _gn(0x29A16F8D621C4508)
--- HookOffset defines where the hook is attached. leave at 0 for default attachment.
function Global.AttachVehicleToTowTruck(towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)
	return _in2(fn, towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)
end

local fn = _gn(0xA7A1127490312C36)
--- WATER_OVERRIDE_SET_SHOREWAVEMAXAMPLITUDE
function Global.N_0xa7a1127490312c36(maxAmplitude)
	return _in2(fn, maxAmplitude)
end

local fn = _gn(0xA6F6F70FDC6D144C)
--- REMOVE_DECALS_FROM_OBJECT_FACING
function Global.RemoveDecalsFromObjectFacing(obj, x, y, z)
	return _in2(fn, obj, x, y, z)
end

local fn = _gn(0x700569DBA175A77C)
--- Gets number of plates in the response of the get license plates request.
-- Range: \[0, count) can be used as second argument to \_0x1D4446A62D35B0D0 and \_0x2E89990DDFF670C3
function Global.N_0x700569dba175a77c(token)
	return _in2(fn, token, _ri)
end

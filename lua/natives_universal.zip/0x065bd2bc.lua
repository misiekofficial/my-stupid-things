local fn = _gn(0x0378C08504160D0D)
--- NativeDB Introduced: v1365
function Global.IsObjectAPortablePickup(object)
	return _in2(fn, object, _r)
end

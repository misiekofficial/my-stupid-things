local fn = _gn(0x171BAFB3C60389F4)
--- DOES_POP_MULTIPLIER_SPHERE_EXIST
function Global.DoesPopMultiplierSphereExist(id)
	return _in2(fn, id, _r)
end

local fn = _gn(0x52923C4710DD9907)
--- Forces the particular room in an interior to load incase not teleporting into the portal.
function Global.ForceRoomForEntity(entity, interior, roomHashKey)
	return _in2(fn, entity, interior, _ch(roomHashKey))
end

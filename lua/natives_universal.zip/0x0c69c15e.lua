local fn = _gn(0x45A83257ED02D9BC)
--- Forces the "Are you sure you want to quit Grand Theft Auto V?" warning message (Same as when you Alt+F4) to show.
-- Doesn't work in singleplayer.
function Global.N_0x45a83257ed02d9bc()
	return _in2(fn)
end

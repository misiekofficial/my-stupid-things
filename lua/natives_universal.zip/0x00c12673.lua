local fn = _gn(0x6B50FC8749632EC1)
--- Enables or disables the sonar sweep animation on the minimap.
-- ```
-- NativeDB Introduced: v2189
-- ```
-- @param toggle A boolean value where `true` activates the sonar sweep animation on the minimap, and `false` turns it off.
-- @return This native does not return any value.
function Global.SetMinimapSonarSweep(toggle)
	return _in2(fn, toggle)
end

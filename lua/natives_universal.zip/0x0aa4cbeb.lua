local fn = _gn(0x9A83F5F9963775EF)
--- HAVE_VEHICLE_MODS_STREAMED_IN
function Global.HaveVehicleModsStreamedIn(vehicle)
	return _in2(fn, vehicle, _r)
end

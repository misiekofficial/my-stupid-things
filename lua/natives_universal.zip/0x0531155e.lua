local fn = _gn(0xFF4FB7C8CDFA3DA7)
--- CLEAR_GPS_PLAYER_WAYPOINT
function Global.ClearGpsPlayerWaypoint()
	return _in2(fn)
end

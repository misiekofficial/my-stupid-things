local fn = _gn(0xA7092AFE81944852)
--- NativeDB Introduced: v2189
function Global.N_0xa7092afe81944852()
	return _in2(fn)
end

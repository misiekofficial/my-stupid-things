local fn = _gn(0x311438A071DD9B1A)
--- ADD_POINT_TO_GPS_CUSTOM_ROUTE
function Global.AddPointToGpsCustomRoute(x, y, z)
	return _in2(fn, x, y, z)
end

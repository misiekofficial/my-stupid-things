local fn = _gn(0xE301BD63E9E13CF0)
--- SET_CARGOBOB_PICKUP_MAGNET_REDUCED_STRENGTH
function Global.SetCargobobPickupMagnetReducedStrength(cargobob, vehicle)
	return _in2(fn, cargobob, vehicle)
end

local fn = _gn(0x49B856B1360C47C7)
--- NativeDB Introduced: v2060
function Global.N_0x49b856b1360c47c7(player, wantedLevel, lossTime)
	return _in2(fn, player, wantedLevel, lossTime)
end

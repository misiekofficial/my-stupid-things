local fn = _gn(0x8132C0EB8B2B3293)
--- NETWORK_IS_CLOUD_BACKGROUND_SCRIPT_REQUEST_PENDING
function Global.HasBgScriptBeenDownloaded()
	return _in2(fn, _r)
end

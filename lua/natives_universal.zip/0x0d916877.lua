local fn = _gn(0xBC1D768F2F5D6C05)
--- NETWORK_HASH_FROM_PLAYER_HANDLE
function Global.NetworkHashFromPlayerHandle(player)
	return _in2(fn, player, _ri)
end

local fn = _gn(0xC17AD0E5752BECDA)
--- GET_SHOP_PED_APPAREL_VARIANT_COMPONENT_COUNT
function Global.N_0xc17ad0e5752becda(componentHash)
	return _in2(fn, _ch(componentHash), _ri)
end

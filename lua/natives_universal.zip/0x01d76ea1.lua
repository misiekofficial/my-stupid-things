local fn = _gn(0xC5F0A8EBD3F361CE)
--- Sets an unknown flag used by CScene in determining which entities from CMapData scene nodes to draw, similar to SET_INSTANCE_PRIORITY_MODE.
function Global.SetUnkMapFlag(flag)
	return _in2(fn, flag)
end

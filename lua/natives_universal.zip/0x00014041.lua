local fn = _gn(0x51669F7D1FB53D9F)
--- SET_CINEMATIC_BUTTON_ACTIVE
function Global.SetCinematicButtonActive(p0)
	return _in2(fn, p0)
end

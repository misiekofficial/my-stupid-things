local fn = _gn(0xFA91550DF9318B22)
--- NETWORK_ACCEPT_PRESENCE_INVITE
function Global.NetworkAcceptPresenceInvite(p0)
	return _in2(fn, p0, _r)
end

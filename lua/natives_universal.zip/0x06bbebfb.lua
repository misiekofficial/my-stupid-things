local fn = _gn(0x5E6CC07646BBEAB8)
--- Inhibits the player from using any method of combat including melee and firearms.\
-- NOTE: Only disables the firing for one frame
-- @param player The player for which to disable combat methods.
-- @param toggle Unused, as this native will disable combat regardless of the value of this parameter.
function Global.DisablePlayerFiring(player, toggle)
	return _in2(fn, player, toggle)
end

local fn = _gn(0x1DFEDD15019315A9)
--- NativeDB Introduced: v1493
function Global.SetAbilityBarVisibilityInMultiplayer(visible)
	return _in2(fn, visible)
end

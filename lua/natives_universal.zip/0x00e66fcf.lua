local fn = _gn(0x632106CC96E82E91)
--- TAN
function Global.Tan(p0)
	return _in2(fn, p0, _rf)
end

local fn = _gn(0xE43701C36CAFF1A4)
--- NativeDB Introduced: v1180
function Global.N_0xe43701c36caff1a4(vehicle)
	return _in2(fn, vehicle, _r)
end

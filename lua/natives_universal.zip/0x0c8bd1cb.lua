local fn = _gn(0xE6B7B0ACD4E4B75E)
--- CANCEL_STUNT_JUMP
function Global.CancelStuntJump()
	return _in2(fn)
end

local fn = _gn(0x1201E8A3290A3B98)
--- _SET_CAMBERED_WHEELS_DISABLED
function Global.N_0x1201e8a3290a3b98(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

local fn = _gn(0x72E7C7B9615FA3C3)
--- NativeDB Introduced: v1868
function Global.NetworkEarnCasinoHeist(p0, p1, p2, p3, p4, p5, p6)
	return _in2(fn, p0, p1, p2, p3, p4, p5, p6)
end

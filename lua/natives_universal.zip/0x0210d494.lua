local fn = _gn(0x04456F95153C6BE4)
--- STOP_SAVE_ARRAY
function Global.StopSaveArray()
	return _in2(fn)
end

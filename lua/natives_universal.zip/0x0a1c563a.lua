local fn = _gn(0x4F056E1AFFEF17AB)
--- See [`FORCE_PED_MOTION_STATE`](#\_0xF28965D04F570DCA)
function Global.TaskForceMotionState(ped, state, p2)
	return _in2(fn, ped, _ch(state), p2)
end

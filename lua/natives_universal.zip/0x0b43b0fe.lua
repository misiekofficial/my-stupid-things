local fn = _gn(0x015C49A93E3E086E)
--- Toggles the selfie mode on the cellphone camera. Only visible when the cell phone camera is active.
-- @param toggle True to activate and false to deactivate the selfie mode.
function Global.DisablePhoneThisFrame(toggle)
	return _in2(fn, toggle)
end

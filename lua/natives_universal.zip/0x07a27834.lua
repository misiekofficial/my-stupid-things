local fn = _gn(0x26D83693ED99291C)
--- NativeDB Added Parameter 3: BOOL p2
-- @param ped The ped handle.
-- @param propIndex The prop index to set the helmet to. Refer to [SET_PED_PROP_INDEX](#\_0x93376B65A266EB5F).
function Global.SetPedHelmetPropIndex(ped, propIndex)
	return _in2(fn, ped, propIndex)
end

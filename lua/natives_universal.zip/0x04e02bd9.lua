local fn = _gn(0x4C2330E61D3DEB56)
--- Only used once in the entire game scripts.
-- Does not actually return anything.
function Global.N_0x4c2330e61d3deb56(interior)
	return _in2(fn, interior, _ri)
end

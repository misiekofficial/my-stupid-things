local fn = _gn(0x01BB4D577D38BD9E)
--- Vehicle will make a 'rattling' noise when decelerating
-- @param vehicle Vehicle to modify
-- @param intensity A value 0.0 - 1.0. Higher the value, the more likely the vehicle is to make the sound while decelerating
function Global.SetVehicleAudioBodyDamageFactor(vehicle, intensity)
	return _in2(fn, vehicle, intensity)
end

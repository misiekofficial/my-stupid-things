local fn = _gn(0xD8C3BE3EE94CAF2D)
--- Min and max are usually 100.0 and 200.0
function Global.N_0xd8c3be3ee94caf2d(x, y, z, min, max)
	return _in2(fn, x, y, z, min, max)
end

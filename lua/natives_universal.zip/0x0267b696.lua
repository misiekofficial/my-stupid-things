local fn = _gn(0xEFFB25453D8600F9)
--- NETWORK_IS_CABLE_CONNECTED
function Global.NetworkIsCableConnected()
	return _in2(fn, _r)
end

local fn = _gn(0xB21B89501CFAC79E)
--- NETWORK_SPENT_PROSTITUTES
function Global.NetworkSpentProstitutes(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

local fn = _gn(0x29DA3CA8D8B2692D)
--- NativeDB Introduced: v1493
function Global.N_0x29da3ca8d8b2692d(ped, enabled)
	return _in2(fn, ped, enabled)
end

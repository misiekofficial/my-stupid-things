local fn = _gn(0x1398582B7F72B3ED)
--- 0x1398582B7F72B3ED
function Global.N_0x1398582b7f72b3ed(p0)
	return _in2(fn, p0)
end

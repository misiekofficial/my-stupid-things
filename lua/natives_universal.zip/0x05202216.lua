local fn = _gn(0xD6D09A6F32F49EF1)
--- NETWORK_SESSION_GET_KICK_VOTE
function Global.NetworkSessionGetKickVote(player)
	return _in2(fn, player, _r)
end

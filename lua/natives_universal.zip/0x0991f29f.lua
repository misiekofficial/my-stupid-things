local fn = _gn(0xB2092A1EAA7FD45F)
--- _IS_DAMAGE_TRACKER_ACTIVE_ON_PLAYER
function Global.N_0xb2092a1eaa7fd45f(player)
	return _in2(fn, player, _r)
end

local fn = _gn(0x8881C98A31117998)
--- NativeDB Added Parameter 2: Any p1
function Global.N_0x8881c98a31117998(p0)
	return _in2(fn, p0)
end

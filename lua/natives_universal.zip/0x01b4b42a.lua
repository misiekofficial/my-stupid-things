local fn = _gn(0xD9B71952F78A2640)
--- Includes networking check: ownership vs. or the door itself **isn't** networked.
-- @param doorHash Door system identifier
function Global.N_0xd9b71952f78a2640(doorHash, toggle)
	return _in2(fn, _ch(doorHash), toggle)
end

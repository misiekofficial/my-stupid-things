local fn = _gn(0x560A43136EB58105)
--- Sets whether a pedestrian should wear a helmet.
-- @param ped Ped index.
-- @param bEnable Boolean value that indicates whether the helmet should be worn or not.
function Global.SetPedHelmet(ped, bEnable)
	return _in2(fn, ped, bEnable)
end

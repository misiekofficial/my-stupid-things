local fn = _gn(0xF3D78F59DFE18D79)
--- SET_FADE_IN_AFTER_LOAD
function Global.SetFadeInAfterLoad(toggle)
	return _in2(fn, toggle)
end

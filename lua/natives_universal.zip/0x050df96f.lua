local fn = _gn(0x65499865FCA6E5EC)
--- DOOR_SYSTEM_GET_OPEN_RATIO
function Global.N_0x65499865fca6e5ec(doorHash)
	return _in2(fn, _ch(doorHash), _rf)
end

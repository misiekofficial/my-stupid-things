local fn = _gn(0xF7F203E31F96F6A1)
--- IS_SEAT_WARP_ONLY
-- @param vehicle The vehicle to check.
-- @param seatIndex See eSeatPosition declared in [`IS_VEHICLE_SEAT_FREE`](#\_0x22AC59A870E6A669).
function Global.N_0xf7f203e31f96f6a1(vehicle, seatIndex)
	return _in2(fn, vehicle, seatIndex, _r)
end

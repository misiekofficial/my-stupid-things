local fn = _gn(0x40763EA7B9B783E7)
--- This is marked as a deprecated function internally, please use [HINT_SCRIPT_AUDIO_BANK](#\_0xFB380A29641EC31A) instead.
function Global.N_0x40763ea7b9b783e7(bankName, bOverNetwork, playerBits)
	return _in2(fn, _ts(bankName), bOverNetwork, playerBits, _r)
end

local fn = _gn(0xBB7454BAFF08FE25)
--- Override the area where the camera will render the terrain.
-- p3, p4 and p5 are usually set to 0.0
function Global.SetFocusPosAndVel(x, y, z, offsetX, offsetY, offsetZ)
	return _in2(fn, x, y, z, offsetX, offsetY, offsetZ)
end

local fn = _gn(0x64E5C4CC82847B73)
--- Hardcoded to return false.
-- ```
-- NativeDB Introduced: v1734
-- ```
function Global.N_0x64e5c4cc82847b73()
	return _in2(fn, _r)
end

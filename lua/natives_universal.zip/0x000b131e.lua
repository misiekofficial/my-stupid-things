local fn = _gn(0x75627043C6AA90AD)
--- Disables collision for this vehicle (maybe it also supports other entities, not sure).
-- Only world/building/fixed world objects will have their collisions disabled, props, peds, or any other entity still collides with the vehicle.
-- [Example video](https://streamable.com/6n45d5)
-- Not sure if there is a native (and if so, which one) that resets the collisions.
-- @param vehicle the vehicle to disable world collisions for
function Global.N_0x75627043c6aa90ad(vehicle)
	return _in2(fn, vehicle)
end

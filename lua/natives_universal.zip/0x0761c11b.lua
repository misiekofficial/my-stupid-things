local fn = _gn(0x17E0198B3882C2CB)
--- NETWORK_START_SOLO_TUTORIAL_SESSION
function Global.NetworkStartSoloTutorialSession()
	return _in2(fn)
end

local fn = _gn(0x99C82F8A139F3E4E)
--- SET_VEHICLE_KERS_ALLOWED
function Global.SetVehicleHudSpecialAbilityBarActive(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

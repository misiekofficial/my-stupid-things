local fn = _gn(0x873C9F3104101DD3)
--- Returns current screen resolution.
function Global.GetScreenActiveResolution()
	return _in2(fn, _i, _i)
end

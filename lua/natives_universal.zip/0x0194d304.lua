local fn = _gn(0xFE99B66D079CF6BC)
--- [Control values and meaning](https://docs.fivem.net/docs/game-references/controls/#controls)
-- Example: `CONTROLS::DISABLE_CONTROL_ACTION(2, 19, true)` disables the switching UI from appearing both when using a keyboard and Xbox 360 controller. Needs to be executed each frame.
-- Control group 1 and 0 gives the same results as 2. Same results for all players.
function Global.DisableControlAction(padIndex, control, disable)
	return _in2(fn, padIndex, control, disable)
end

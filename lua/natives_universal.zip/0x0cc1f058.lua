local fn = _gn(0x17430B918701C342)
--- _THEFEED_SET_ANIMPOSTFX_COLOR
function Global.ThefeedSetAnimpostfxColor(red, green, blue, alpha)
	return _in2(fn, red, green, blue, alpha)
end

local fn = _gn(0xF7D82B0D66777611)
--- REMOVE_WEAPON_COMPONENT_FROM_WEAPON_OBJECT
function Global.RemoveWeaponComponentFromWeaponObject(weaponObject, addonHash)
	return _in2(fn, weaponObject, _ch(addonHash))
end

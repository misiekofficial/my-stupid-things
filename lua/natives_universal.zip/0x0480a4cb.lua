local fn = _gn(0xF3A21BCD95725A4A)
--- Returns whether a control is currently pressed.
-- @param padIndex The control system instance to use. See [`ENABLE_ALL_CONTROL_ACTIONS`](#\_0xA5FFE9B05F199DE7).
-- @param control The [control ID](https://docs.fivem.net/docs/game-references/controls/#controls) to check.
-- @return True if the control was pressed.
function Global.IsControlPressed(padIndex, control)
	return _in2(fn, padIndex, control, _r)
end

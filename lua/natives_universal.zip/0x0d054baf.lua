local fn = _gn(0x12782CE0A636E9F0)
--- RESET_RETICULE_VALUES
function Global.ResetReticuleValues()
	return _in2(fn)
end

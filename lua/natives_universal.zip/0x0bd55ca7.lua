local fn = _gn(0xC79196DCB36F6121)
--- CLEAR_PED_*
function Global.N_0xc79196dcb36f6121(ped)
	return _in2(fn, ped)
end

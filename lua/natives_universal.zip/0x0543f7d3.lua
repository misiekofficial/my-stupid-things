local fn = _gn(0x8410C5E0CD847B9D)
--- NativeDB Introduced: v1290
function Global.N_0x8410c5e0cd847b9d()
	return _in2(fn)
end

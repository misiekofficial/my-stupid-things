local fn = _gn(0x6ACF6B7225801CD7)
--- SET_SYNCHRONIZED_SCENE_ORIGIN
function Global.SetSynchronizedSceneOrigin(sceneID, x, y, z, roll, pitch, yaw, p7)
	return _in2(fn, sceneID, x, y, z, roll, pitch, yaw, p7)
end

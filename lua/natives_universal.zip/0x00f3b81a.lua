local fn = _gn(0xDBC966A01C02BCA7)
--- _NETWORK_SPENT_PAY_BOSS
function Global.NetworkSpentPayBoss(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

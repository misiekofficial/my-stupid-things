local fn = _gn(0x2CE056FF3723F00B)
--- STAT_GET_NUMBER_OF_SECONDS
function Global.StatGetNumberOfSeconds(statName)
	return _in2(fn, _ch(statName), _ri)
end

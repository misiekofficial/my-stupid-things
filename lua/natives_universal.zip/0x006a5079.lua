local fn = _gn(0x36492C2F0D134C56)
--- Returns a float value between 0.0 and 3.0 related to its slipstream draft (boost/speedup).
-- GET_VEHICLE_*
function Global.GetVehicleCurrentSlipstreamDraft(vehicle)
	return _in2(fn, vehicle, _rf)
end

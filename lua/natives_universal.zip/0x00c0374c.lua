local fn = _gn(0xA65568121DF2EA26)
--- _NET_GAMESERVER_BASKET_END
function Global.N_0xe547e9114277098f()
	return _in2(fn, _r)
end

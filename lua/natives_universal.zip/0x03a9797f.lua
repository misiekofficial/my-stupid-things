local fn = _gn(0xFC481C641EBBD27D)
--- IS_OBJECT_A_PICKUP
function Global.IsObjectAPickup(object)
	return _in2(fn, object, _r)
end

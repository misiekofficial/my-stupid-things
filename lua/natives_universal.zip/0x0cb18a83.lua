local fn = _gn(0x6E4361FF3E8CD7CA)
--- 0x6E4361FF3E8CD7CA
function Global.N_0x6e4361ff3e8cd7ca(p0)
	return _in2(fn, p0, _ri)
end

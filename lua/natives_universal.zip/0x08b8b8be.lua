local fn = _gn(0x4D89D607CB3DD1D2)
--- Overrides the climbing/blocking flags of the object, used in the native scripts mostly for "prop_dock_bouy_*"
function Global.SetObjectAllowLowLodBuoyancy(object, toggle)
	return _in2(fn, object, toggle)
end

local fn = _gn(0x62A456AA4769EF34)
--- PLAY_VEHICLE_DOOR_CLOSE_SOUND
function Global.PlayVehicleDoorCloseSound(vehicle, doorIndex)
	return _in2(fn, vehicle, doorIndex)
end

local fn = _gn(0xDFF49EE984E7AAE8)
--- NativeDB Introduced: v1734
function Global.NetworkEarnFromRcTimeTrial(amount)
	return _in2(fn, amount)
end

local fn = _gn(0x152D90E4C1B4738A)
--- UGC_COPY_CONTENT
function Global.N_0x152d90e4c1b4738a()
	return _in2(fn, _i, _i, _r)
end

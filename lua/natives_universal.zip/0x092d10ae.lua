local fn = _gn(0x673ED815D6E323B7)
--- IS_ANY_ENTITY_ENTIRELY_INSIDE_GARAGE
function Global.IsAnyEntityEntirelyInsideGarage(garageHash, p1, p2, p3, p4)
	return _in2(fn, _ch(garageHash), p1, p2, p3, p4, _r)
end

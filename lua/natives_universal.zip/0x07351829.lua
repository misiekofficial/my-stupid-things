local fn = _gn(0x0B568201DD99F0EB)
--- Sets whether or not scripted conversation flow should be controlled by anim triggers
-- @param enable Pass in true to set conversation flow to be controlled by animation triggers.
function Global.N_0x0b568201dd99f0eb(enable)
	return _in2(fn, enable)
end

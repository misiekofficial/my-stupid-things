local fn = _gn(0xAD2A7A6DFF55841B)
--- Returns the total number of DLC weapon components that are available in SP.
-- ```
-- NativeDB Introduced: v2060
-- ```
function Global.GetNumDlcWeaponComponentsSp(dlcWeaponIndex)
	return _in2(fn, dlcWeaponIndex, _ri)
end

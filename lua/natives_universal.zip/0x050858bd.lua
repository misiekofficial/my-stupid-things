local fn = _gn(0xA0696A65F009EE18)
--- normalizedValue is from 0.0 - 1.0
-- p2 is always 1
-- ```
-- ```
-- NativeDB Added Parameter 4: Any p3
function Global.ResetSpecialAbilityControlsCinematic(player, normalizedValue, p2)
	return _in2(fn, player, normalizedValue, p2)
end

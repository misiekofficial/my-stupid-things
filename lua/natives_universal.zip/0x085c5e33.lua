local fn = _gn(0x61E111E323419E07)
--- GET_PACKED_INT_STAT_KEY
function Global.N_0x61e111e323419e07(index, spStat, charStat, character)
	return _in2(fn, index, spStat, charStat, character, _ri)
end

local fn = _gn(0xc79f44bf)
--- Starts listening to the specified channel, when available.
-- @param channel A game voice channel ID.
function Global.MumbleAddVoiceChannelListen(channel)
	return _in2(fn, channel)
end

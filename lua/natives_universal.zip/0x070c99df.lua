local fn = _gn(0x668FD40BCBA5DE48)
--- Used one time in fmmc_launcher.c instead of CLONE_PED because ?
function Global.ClonePedEx(ped, heading, isNetwork, bScriptHostPed, p4)
	return _in2(fn, ped, heading, isNetwork, bScriptHostPed, p4, _ri)
end

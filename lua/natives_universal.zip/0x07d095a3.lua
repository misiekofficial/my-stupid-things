local fn = _gn(0x8974647ED222EA5F)
--- Flags are identical to START_SHAPE_TEST\*, however, 128 is automatically set.
-- @param flag See [`START_SHAPE_TEST_LOS_PROBE`](#\_0x7EE9F5D83DD4F90E)
function Global.TestProbeAgainstAllWater(x1, y1, z1, x2, y2, z2, flag, result)
	return _in2(fn, x1, y1, z1, x2, y2, z2, flag, _v, _r)
end

local fn = _gn(0x71B0892EC081D60A)
--- Sets a vehicle to be strongly resistant to explosions. p0 is the vehicle; set p1 to false to toggle the effect on/off.
function Global.SetVehicleExplodesOnHighExplosionDamage(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

local fn = _gn(0xE679E3E06E363892)
--- Overrides the game clock time for the local player, allowing for manipulation of the in-game time. This native is effective in both multiplayer and singleplayer modes.
-- **Note:** Passing wrong data (e.g. hours above 23) will cause the game to crash.
-- @param hours The hour to set (0-23).
-- @param minutes The minute to set (0-59).
-- @param seconds The second to set (0-59).
function Global.NetworkOverrideClockTime(hours, minutes, seconds)
	return _in2(fn, hours, minutes, seconds)
end

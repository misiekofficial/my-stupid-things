local fn = _gn(0x3C606747B23E497B)
--- Define the scope within which the ped will engage in combat with the target.
-- ```cpp
-- enum eCombatRange {
-- CR_NEAR = 0, // keeps within 5-15m
-- CR_MEDIUM, // keeps within 7-30m
-- CR_FAR, // keeps within 15-40m
-- CR_VERY_FAR // keeps within 22-45m
-- };
-- ```
-- @param ped Ped index
-- @param range See `eCombatRange` enum.
function Global.SetPedCombatRange(ped, range)
	return _in2(fn, ped, range)
end

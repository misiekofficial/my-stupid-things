local fn = _gn(0x09693B0312F91649)
--- Only appears twice in the scripts.
-- TASK::TASK_RAPPEL_FROM_HELI(PLAYER::PLAYER_PED_ID(), 0x41200000);
-- TASK::TASK_RAPPEL_FROM_HELI(a_0, 0x41200000);
function Global.TaskRappelFromHeli(ped, unused)
	return _in2(fn, ped, unused)
end

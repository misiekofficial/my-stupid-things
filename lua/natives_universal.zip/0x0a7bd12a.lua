local fn = _gn(0x13AD665062541A7E)
--- This native enables the audio flag "TrevorRageIsOverridden" and sets the voice effect to `voiceEffect`
-- To clear the override use [RESET_TREVOR_RAGE](#\_0xE78503B10C4314E0)
function Global.OverrideTrevorRage(voiceEffect)
	return _in2(fn, _ts(voiceEffect))
end

local fn = _gn(0x3BD770D281982DB5)
--- NativeDB Introduced: v1604
function Global.N_0x3bd770d281982db5(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

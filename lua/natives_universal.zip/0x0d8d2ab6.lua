local fn = _gn(0x02C40BF885C567B6)
--- Returns a local synchronized scene handle of a networked synchronised scene.
-- @param netSceneId Network synchronised scene ID (returned by [`NETWORK_CREATE_SYNCHRONISED_SCENE`](#\_0x7CD6BC4C2BBDD526)).
-- @return Local synchronized scene ID. This value can be used with natives such as: [`GET_SYNCHRONIZED_SCENE_PHASE`](#\_0xE4A310B1D7FA73CC), [`GET_SYNCHRONIZED_SCENE_RATE`](#\_0xD80932D577274D40), [`IS_SYNCHRONIZED_SCENE_RUNNING`](#\_0x25D39B935A038A26) and more.
function Global.N_0x02c40bf885c567b6(netSceneId)
	return _in2(fn, netSceneId, _ri)
end

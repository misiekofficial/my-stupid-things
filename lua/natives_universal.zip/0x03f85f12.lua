local fn = _gn(0xB16FCE9DDC7BA182)
--- IS_SCREEN_FADED_OUT
function Global.IsScreenFadedOut()
	return _in2(fn, _r)
end

local fn = _gn(0x1461B28A06717D68)
--- Use [`SetPedIlluminatedClothingGlowIntensity`](#\_0x4E90D746056E273D) to set the illuminated clothing glow intensity for a specific ped.
-- @param ped The ped to get the glow intensity from.
-- @return A float between 0.0 and 1.0 representing the current illuminated clothing glow intensity.
function Global.GetPedEmissiveIntensity(ped)
	return _in2(fn, ped, _rf)
end

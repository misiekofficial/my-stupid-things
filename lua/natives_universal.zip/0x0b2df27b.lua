local fn = _gn(0xDDF3CB5A0A4C0B49)
--- NativeDB Introduced: v2372
function Global.SetAnimPhase(entity, p1, p2, p3)
	return _in2(fn, entity, p1, p2, p3)
end

local fn = _gn(0x3910051CCECDB00C)
--- True means it can be deleted by the engine when switching lobbies/missions/etc, false means the script is expected to clean it up.
function Global.N_0x3910051ccecdb00c(entity, toggle)
	return _in2(fn, entity, toggle)
end

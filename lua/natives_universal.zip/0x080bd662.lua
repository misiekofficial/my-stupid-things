local fn = _gn(0xC3C221ADDDE31A11)
--- WATER_OVERRIDE_FADE_OUT
function Global.N_0xc3c221addde31a11(p0)
	return _in2(fn, p0)
end

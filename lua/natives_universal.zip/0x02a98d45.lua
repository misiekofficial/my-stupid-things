local fn = _gn(0x87EB7A3FFCB314DB)
--- _NETWORK_IS_FRIEND_HANDLE_ONLINE
function Global.NetworkIsFriendOnline_2(networkHandle)
	return _in2(fn, _ii(networkHandle) --[[ may be optional ]], _r)
end

local fn = _gn(0x08C2D6C52A3104BB)
--- GET_PLAYER_SWITCH_INTERP_OUT_DURATION
function Global.N_0x08c2d6c52a3104bb()
	return _in2(fn, _ri)
end

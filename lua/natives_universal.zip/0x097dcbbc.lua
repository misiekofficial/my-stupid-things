local fn = _gn(0xA1A9FC1C76A6730D)
--- _IS_THIS_MODEL_AN_AMPHIBIOUS_QUADBIKE
function Global.IsThisModelAnAmphibiousQuadbike(model)
	return _in2(fn, _ch(model), _r)
end

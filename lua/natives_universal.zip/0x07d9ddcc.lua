local fn = _gn(0x052837721A854EC7)
--- See [`START_SHAPE_TEST_LOS_PROBE`](#\_0x7EE9F5D83DD4F90E) for flags.
function Global.N_0x052837721a854ec7(entity, flags1, flags2)
	return _in2(fn, entity, flags1, flags2, _ri)
end

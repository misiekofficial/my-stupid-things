local fn = _gn(0x1B7ABE26CBCBF8C7)
--- SET_PED_RACE_AND_VOICE_GROUP
-- @param pvgHash PedVoiceGroup hash, defaults to 0
function Global.SetPedRaceAndVoiceGroup(ped, pedRace, pvgHash)
	return _in2(fn, ped, pedRace, pvgHash)
end

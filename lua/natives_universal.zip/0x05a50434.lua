local fn = _gn(0x6F2135B6129620C1)
--- Sets bit 3 in GtaThread+0x150
-- SET_T*
function Global.N_0x6f2135b6129620c1(toggle)
	return _in2(fn, toggle)
end

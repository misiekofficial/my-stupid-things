local fn = _gn(0x4EC12697209F2196)
--- Returns true if the player is riding a train.
function Global.IsPlayerRidingTrain(player)
	return _in2(fn, player, _r)
end

local fn = _gn(0xD1110739EEADB592)
--- _NETWORK_IS_THIS_SCRIPT_MARKED
function Global.NetworkIsThisScriptMarked(p0, p1, p2)
	return _in2(fn, p0, p1, p2, _r)
end

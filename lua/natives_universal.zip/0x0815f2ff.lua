local fn = _gn(0x983765856F2564F9)
--- SET_VEHICLE_ENGINE_CAN_DEGRADE
function Global.SetVehicleEngineCanDegrade(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

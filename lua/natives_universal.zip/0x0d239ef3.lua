local fn = _gn(0x313CE5879CEB6FCD)
--- GET_RANDOM_FLOAT_IN_RANGE
function Global.GetRandomFloatInRange(startRange, endRange)
	return _in2(fn, startRange, endRange, _rf)
end

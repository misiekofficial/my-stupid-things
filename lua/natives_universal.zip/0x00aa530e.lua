local fn = _gn(0xB6E6FBA95C7324AC)
--- Sets the ajar angle of a door.
-- Ranges from -1.0 to 1.0, and 0.0 is closed / default.
-- @param doorHash Door system identifier
-- @param forceUpdate On true invokes [DOOR_SYSTEM_SET_DOOR_STATE](#\_0x6BAB9442830C7F53); otherwise requestDoor is unused.
function Global.N_0xb6e6fba95c7324ac(doorHash, ajar, requestDoor, forceUpdate)
	return _in2(fn, _ch(doorHash), ajar, requestDoor, forceUpdate)
end

local fn = _gn(0xAE2206545888AE49)
--- LEADERBOARDS2_WRITE_DATA
function Global.Leaderboards2WriteData(p0)
	return _in2(fn, _ii(p0) --[[ may be optional ]], _r)
end

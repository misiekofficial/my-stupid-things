local fn = _gn(0x9F97DA93681F87EA)
--- B\*
-- ```
-- NativeDB Introduced: v1734
-- ```
function Global.N_0x9f97da93681f87ea()
	return _in2(fn)
end

local fn = _gn(0x93AA4165CB67E925)
--- NativeDB Introduced: v2372
function Global.N_0x93aa4165cb67e925(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3)
end

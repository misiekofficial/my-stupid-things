local fn = _gn(0xF1211889DF15A763)
--- Allows locking the hover/non-hover mode of a vehicle, such as the flying mode of the `Deluxo`. In the decompiled scripts, this native is used on `oppressor2` but couldn't get it to work on it.
-- @param vehicle The vehicle to which the locking state will be applied.
-- @param toggle Boolean parameter where setting `false` locks the current state of the vehicle, preventing transitions such as the `Deluxo` or Oppressor switching between their flying and driving modes. Setting it to `true` allows changing the vehicle state as usual.
function Global.N_0xf1211889df15a763(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

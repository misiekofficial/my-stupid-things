local fn = _gn(0x5FFE9B4144F9712F)
--- Formerly incorrectly named `USE_PLAYER_COLOUR_INSTEAD_OF_TEAM_COLOUR` due to incorrect treatment of console vs. PC native registration.
-- Native name guessed through ordering.
-- ```
-- NativeDB Added Parameter 2: BOOL p1
-- ```
function Global.SetLocalPlayerAsGhost(toggle)
	return _in2(fn, toggle)
end

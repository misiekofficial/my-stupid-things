local fn = _gn(0x5B9E023DC6EBEDC0)
--- NETWORK_CLAN_DOWNLOAD_MEMBERSHIP_PENDING
function Global.NetworkClanDownloadMembershipPending(p0)
	return _in2(fn, _ii(p0) --[[ may be optional ]], _r)
end

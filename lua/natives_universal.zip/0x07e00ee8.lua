local fn = _gn(0xBCEDB009461DA156)
--- 0xBCEDB009461DA156
function Global.N_0xbcedb009461da156()
	return _in2(fn, _ri)
end

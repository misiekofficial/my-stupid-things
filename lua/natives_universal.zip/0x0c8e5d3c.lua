local fn = _gn(0x9A53DED9921DE990)
--- Sets the specified ped to use a specific voice different to the one associated with their model.
function Global.SetAmbientVoiceNameHash(ped, hash)
	return _in2(fn, ped, _ch(hash))
end

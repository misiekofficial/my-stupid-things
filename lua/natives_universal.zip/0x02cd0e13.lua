local fn = _gn(0x3B390A939AF0B5FC)
--- NativeDB Added Parameter 2: Any p1
function Global.GetCurrentPedWeaponEntityIndex(ped)
	return _in2(fn, ped, _ri)
end

local fn = _gn(0x9BEA350D7C48061B)
--- NativeDB Introduced: v2372
function Global.N_0x9bea350d7c48061b(p0, p1, p2, p3, p4)
	return _in2(fn, p0, p1, p2, p3, p4)
end

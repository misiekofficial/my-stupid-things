local fn = _gn(0x442E0A7EDE4A738A)
--- GET_THIS_SCRIPT_NAME
function Global.GetThisScriptName()
	return _in2(fn, _s)
end

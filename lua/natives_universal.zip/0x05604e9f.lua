local fn = _gn(0x4D610C6B56031351)
--- parachuteModel = 230075693
function Global.SetVehicleParachuteModel(vehicle, modelHash)
	return _in2(fn, vehicle, _ch(modelHash))
end

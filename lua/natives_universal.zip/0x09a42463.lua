local fn = _gn(0xE2A99A9B524BEFFF)
--- _NET_GAMESERVER_END_SERVICE
function Global.NetGameserverEndService(transactionId)
	return _in2(fn, transactionId, _r)
end

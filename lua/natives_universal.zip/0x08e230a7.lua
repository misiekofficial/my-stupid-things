local fn = _gn(0xE6AC6C45FBE83004)
--- Performs the same type of trace as START_SHAPE_TEST_CAPSULE, but with some different hardcoded parameters.
-- @param x1 Starting X coordinate.
-- @param y1 Starting Y coordinate.
-- @param z1 Starting Z coordinate.
-- @param x2 Ending X coordinate.
-- @param y2 Ending Y coordinate.
-- @param z2 Ending Z coordinate.
-- @param flags See [`START_SHAPE_TEST_LOS_PROBE`](#\_0x7EE9F5D83DD4F90E)
-- @param entity An entity to ignore, or 0.
-- @param p9 A bit mask with bits 1, 2, 4, or 7 relating to collider types. 4 and 7 are usually used.
function Global.StartShapeTestSweptSphere(x1, y1, z1, x2, y2, z2, radius, flags, entity, p9)
	return _in2(fn, x1, y1, z1, x2, y2, z2, radius, flags, entity, p9, _ri)
end

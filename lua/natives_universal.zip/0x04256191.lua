local fn = _gn(0x2C83A9DA6BFFC4F9)
--- Gets the number of instances of the specified script is currently running.
-- Actually returns numRefs - 1.
-- if (program)
-- v3 = rage::scrProgram::GetNumRefs(program) - 1;
-- return v3;
function Global.GetNumberOfInstancesOfScriptWithNameHash(scriptHash)
	return _in2(fn, _ch(scriptHash), _ri)
end

local fn = _gn(0xE6869BECDD8F2403)
--- REMOVE_POP_MULTIPLIER_SPHERE
function Global.RemovePopMultiplierSphere(id, p1)
	return _in2(fn, id, p1)
end

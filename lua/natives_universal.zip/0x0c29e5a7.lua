local fn = _gn(0x66E49BF55B4B1874)
--- IS_MISSION_NEWS_STORY_UNLOCKED
-- @return Returns true of the specific story is available to be played back
function Global.IsMissionNewsStoryUnlocked(newsStory)
	return _in2(fn, newsStory, _r)
end

local fn = _gn(0xFC18DB55AE19E046)
--- NETWORK_SET_IN_FREE_CAM_MODE
function Global.NetworkSetInFreeCamMode(toggle)
	return _in2(fn, toggle)
end

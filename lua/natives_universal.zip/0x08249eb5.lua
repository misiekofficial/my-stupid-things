local fn = _gn(0x27F9D613092159CF)
--- Pickup hashes can be found [here](https://gist.github.com/4mmonium/1eabfb6b3996e3aa6b9525a3eccf8a0b).
function Global.RemoveAllPickupsOfType(pickupHash)
	return _in2(fn, _ch(pickupHash))
end

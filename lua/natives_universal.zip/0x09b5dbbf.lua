local fn = _gn(0xDADFADA5A20143A8)
--- Starts a new iteration of the current threads.
-- Call this first, then SCRIPT_THREAD_ITERATOR_GET_NEXT_THREAD_ID (0x30B4FA1C82DD4B9F)
function Global.ScriptThreadIteratorReset()
	return _in2(fn)
end

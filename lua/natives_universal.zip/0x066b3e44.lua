local fn = _gn(0x7A983AA9DA2659ED)
--- DATADICT_GET_ARRAY
function Global.ObjectValueGetArray(key)
	return _in2(fn, _i, _ts(key), _ri)
end

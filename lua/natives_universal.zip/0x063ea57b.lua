local fn = _gn(0xB088E9A47AE6EDD5)
--- _SET_DISABLE_SUPERDUMMY_MODE
function Global.SetDisableSuperdummyMode(vehicle, p1)
	return _in2(fn, vehicle, p1)
end

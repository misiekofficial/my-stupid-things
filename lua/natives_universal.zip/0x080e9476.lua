local fn = _gn(0x28579D1B8F8AAC80)
--- Raycast from point to point, where the ray has a radius.
-- @param x1 Starting X coordinate.
-- @param y1 Starting Y coordinate.
-- @param z1 Starting Z coordinate.
-- @param x2 Ending X coordinate.
-- @param y2 Ending Y coordinate.
-- @param z2 Ending Z coordinate.
-- @param flags See [`START_SHAPE_TEST_LOS_PROBE`](#\_0x7EE9F5D83DD4F90E)
-- @param entity Entity to ignore, or 0.
-- @param p9 A bit mask with bits 1, 2, 4, or 7 relating to collider types. 4 and 7 are usually used.
function Global.StartShapeTestCapsule(x1, y1, z1, x2, y2, z2, radius, flags, entity, p9)
	return _in2(fn, x1, y1, z1, x2, y2, z2, radius, flags, entity, p9, _ri)
end

local fn = _gn(0x5E7AE8AABE8B7C0D)
--- NativeDB Introduced: v1604
function Global.NetworkEarnFromAssassinateTargetKilled_2(amount)
	return _in2(fn, amount)
end

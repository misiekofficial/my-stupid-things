local fn = _gn(0xD43D95C7A869447F)
--- TASK_SEEK_COVER_TO_COVER_POINT
function Global.TaskSeekCoverToCoverPoint(p0, p1, p2, p3, p4, p5, p6)
	return _in2(fn, p0, p1, p2, p3, p4, p5, p6)
end

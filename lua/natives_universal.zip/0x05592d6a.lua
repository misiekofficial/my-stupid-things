local fn = _gn(0x5835D9CD92E83184)
--- NETWORK_CLAN_GET_EMBLEM_TXD_NAME
function Global.N_0x5835d9cd92e83184(txdName)
	return _in2(fn, _i, _ts(txdName), _r)
end

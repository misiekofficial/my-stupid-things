local fn = _gn(0xBCC29F935ED07688)
--- SET_VARIABLE_ON_*
function Global.SetVariableOnCutsceneAudio(variableName, value)
	return _in2(fn, _ts(variableName), value)
end

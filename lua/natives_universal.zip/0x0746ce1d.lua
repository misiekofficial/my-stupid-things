local fn = _gn(0x2B626A0150E4D449)
--- GET_REPLAY_STAT_MISSION_TYPE
function Global.GetReplayStatMissionType()
	return _in2(fn, _ri)
end

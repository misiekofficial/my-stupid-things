local fn = _gn(0xB7A628320EFF8E47)
--- Calculates distance between vectors but does not perform Sqrt operations. Its way faster than [`VDIST`](#\_0x2A488C176D52CCA5), but it's not faster than direct mathematical calculations.
-- ```
-- NativeDB Introduced: v323
-- ```
-- @param x1 X coordinate of the first point.
-- @param y1 Y coordinate of the first point.
-- @param z1 Z coordinate of the first point. Represents the height or elevation at the first point.
-- @param x2 X coordinate of the second point.
-- @param y2 Y coordinate of the second point.
-- @param z2 Z coordinate of the second point. Represents the height or elevation at the second point.
-- @return Returns the distance as a float between the two points (`x1`, `y1`, `z1`) and (`x2`, `y2`, `z2`) in the game world.
function Global.Vdist2(x1, y1, z1, x2, y2, z2)
	return _in2(fn, x1, y1, z1, x2, y2, z2, _rf)
end

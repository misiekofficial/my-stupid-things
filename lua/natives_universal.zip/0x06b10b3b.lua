local fn = _gn(0xBB0527EC6341496D)
--- See [`GET_TIMECYCLE_MODIFIER_INDEX`](#\_0xFDF3D97C674AFB66) for use, works the same just for the secondary timecycle modifier.
-- @return An integer representing the Timecycle modifier
function Global.N_0xbb0527ec6341496d()
	return _in2(fn, _ri)
end

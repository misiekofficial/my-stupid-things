local fn = _gn(0x121F0593E0A431D7)
--- VEHICLE_WAYPOINT_PLAYBACK_OVERRIDE_SPEED
function Global.VehicleWaypointPlaybackOverrideSpeed(vehicle, speed)
	return _in2(fn, vehicle, speed)
end

local fn = _gn(0x52C1EADAF7B10302)
--- NETWORK_GET_*
-- NativeDB Introduced: v323
function Global.NetworkGetOldestResendCountForPlayer(player)
	return _in2(fn, player, _ri)
end

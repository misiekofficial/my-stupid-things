local fn = _gn(0x70B8EC8FC108A634)
--- Overrides wind elevation sounds
function Global.N_0x70b8ec8fc108a634(override, windElevationHashName)
	return _in2(fn, override, _ch(windElevationHashName))
end

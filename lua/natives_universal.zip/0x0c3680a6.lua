local fn = _gn(0xF9E1CCAE8BA4C281)
--- UGC_GET_FRIEND_CONTENT
function Global.UgcGetFriendContent(p0, p1)
	return _in2(fn, p0, p1, _i, _i, _r)
end

local fn = _gn(0xACFB2463CC22BED2)
--- SET_LAST_DRIVEN_VEHICLE
function Global.SetLastDrivenVehicle(vehicle)
	return _in2(fn, vehicle)
end

local fn = _gn(0x477D9DB48F889591)
--- This disables the radio station completely - it won't be selectable on the radio wheel or ever be heard coming from a vehicle/ambient emitter
-- ```
-- NativeDB Introduced: v1493
-- ```
function Global.SetRadioStationDisabled(radioStationName, toggle)
	return _in2(fn, _ts(radioStationName), toggle)
end

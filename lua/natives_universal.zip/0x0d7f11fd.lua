local fn = _gn(0xAC3A74E8384A9919)
--- Sets the the raw wind speed value.
function Global.SetWind(speed)
	return _in2(fn, speed)
end

local fn = _gn(0x991251AFC3981F84)
--- IS_CUTSCENE_ACTIVE
function Global.IsCutsceneActive()
	return _in2(fn, _r)
end

local fn = _gn(0x6F697A66CE78674E)
--- NETWORK_OVERRIDE_TEAM_RESTRICTIONS
function Global.NetworkOverrideTeamRestrictions(team, toggle)
	return _in2(fn, team, toggle)
end

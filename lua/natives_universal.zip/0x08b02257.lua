local fn = _gn(0xF660602546D27BA8)
--- _RAISE_RETRACTABLE_WHEELS
function Global.RaiseRetractableWheels(vehicle)
	return _in2(fn, vehicle)
end

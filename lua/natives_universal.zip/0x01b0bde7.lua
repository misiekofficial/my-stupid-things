local fn = _gn(0xA635C11B8C44AFC2)
--- SPAWNPOINTS_GET_NUM_SEARCH_RESULTS
function Global.N_0xa635c11b8c44afc2()
	return _in2(fn, _ri)
end

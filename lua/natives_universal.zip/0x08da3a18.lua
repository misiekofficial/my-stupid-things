local fn = _gn(0x0A60017F841A54F2)
--- Initializes a script race in GTA:Online and sets up the helper split time system.
-- ```
-- NativeDB Introduced: v323
-- ```
-- @param numCheckpoints The total number of checkpoints in the race
-- @param numLaps The total number of laps in the race.
-- @param numPlayers The total number of players participating in the race.
-- @param localPlayer Local player in the race.
function Global.N_0x0a60017f841a54f2(numCheckpoints, numLaps, numPlayers, localPlayer)
	return _in2(fn, numCheckpoints, numLaps, numPlayers, localPlayer)
end

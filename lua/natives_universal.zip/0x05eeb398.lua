local fn = _gn(0xEB2BF817463DFA28)
--- _SC_PROFANITY_CHECK_UGC_STRING
function Global.N_0xeb2bf817463dfa28(string, token)
	return _in2(fn, _ts(string), _ii(token) --[[ may be optional ]], _r)
end

local fn = _gn(0x6F6981D2253C208F)
--- Hides the players weapon during a cutscene.
function Global.HidePedWeaponForScriptedCutscene(ped, toggle)
	return _in2(fn, ped, toggle)
end

local fn = _gn(0x480142959D337D00)
--- Drive randomly with no destination set.
-- @param ped Ped id for the task.
-- @param vehicle Vehicle entity id for the task.
-- @param speed Speed of driving.
-- @param drivingStyle More info can be found [here](https://vespura.com/fivem/drivingstyle/)
function Global.TaskVehicleDriveWander(ped, vehicle, speed, drivingStyle)
	return _in2(fn, ped, vehicle, speed, drivingStyle)
end

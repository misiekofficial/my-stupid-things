local fn = _gn(0xC61B86C9F61EB404)
--- Toggles a value (bool) for cutscenes.
-- SET_*
function Global.N_0xc61b86c9f61eb404(toggle)
	return _in2(fn, toggle)
end

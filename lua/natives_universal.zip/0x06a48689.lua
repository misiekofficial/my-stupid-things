local fn = _gn(0x2BF66D2E7414F686)
--- 0x2BF66D2E7414F686
function Global.N_0x2bf66d2e7414f686()
	return _in2(fn, _ri)
end

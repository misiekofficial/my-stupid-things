local fn = _gn(0x755D6D5267CBBD7E)
--- ARE_PLANE_PROPELLERS_INTACT
function Global.N_0x755d6d5267cbbd7e(plane)
	return _in2(fn, plane, _r)
end

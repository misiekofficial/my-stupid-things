local fn = _gn(0xC4BB08EE7907471E)
--- GET_PACKED_TU_BOOL_STAT_KEY
function Global.GetPackedTuBoolStatKey(index, spStat, charStat, character)
	return _in2(fn, index, spStat, charStat, character, _ri)
end

local fn = _gn(0x655B91F1495A9090)
--- NETWORK_PLAYER_IS_CHEATER
function Global.NetworkPlayerIsCheater()
	return _in2(fn, _r)
end

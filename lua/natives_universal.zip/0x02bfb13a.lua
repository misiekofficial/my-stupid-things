local fn = _gn(0x93028F1DB42BFD08)
--- SC_INBOX_GET_MESSAGE_IS_READ_AT_INDEX
function Global.ScInboxGetMessageIsReadAtIndex(msgIndex)
	return _in2(fn, msgIndex, _r)
end

local fn = _gn(0xFCFACD0DB9D7A57D)
--- _SET_PED_AI_BLIP_SPRITE
function Global.N_0xfcfacd0db9d7a57d(ped, spriteId)
	return _in2(fn, ped, spriteId)
end

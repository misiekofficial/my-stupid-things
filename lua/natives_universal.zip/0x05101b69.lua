local fn = _gn(0x551DF99658DB6EE8)
--- Add a BLIP_GALLERY at the specific coordinate. Used in fm_maintain_transition_players to display race track points.
function Global.N_0x551df99658db6ee8(x, y, z)
	return _in2(fn, x, y, z, _ri)
end

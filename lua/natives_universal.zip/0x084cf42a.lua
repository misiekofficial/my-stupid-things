local fn = _gn(0x8A694D7A68F8DC38)
--- Handles conversation interrupts and pauses, using the code-side system for improved timing and to minimize unfriendly logic interactions.
-- @param interrupterPed the ped speaking
-- @param context the line to use
-- @param voiceName the voicename for the audio asset
function Global.InterruptConversationAndPause(interrupterPed, context, voiceName)
	return _in2(fn, interrupterPed, _ts(context), _ts(voiceName))
end

local fn = _gn(0x7D1464D472D32136)
--- _GET_VEHICLE_INTERIOR_COLOR
function Global.GetVehicleInteriorColor(vehicle, color)
	return _in2(fn, vehicle, _ii(color) --[[ may be optional ]])
end

local fn = _gn(0xa80ffe99)
--- cpp
-- enum eRopeFlags
-- {
-- DrawShadowEnabled = 2,
-- Breakable = 4,
-- RopeUnwindingFront = 8,
-- RopeWinding = 32
-- }
-- @param rope The rope to get the flags for.
-- @return The rope's flags.
function Global.GetRopeFlags(rope)
	return _in2(fn, rope, _ri)
end

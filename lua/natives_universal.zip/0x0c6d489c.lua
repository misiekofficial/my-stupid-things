local fn = _gn(0x129466ED55140F8D)
--- SET_FORCE_FOOTSTEP_UPDATE
function Global.N_0x129466ed55140f8d(ped, toggle)
	return _in2(fn, ped, toggle)
end

local fn = _gn(0x9E5B5E4D2CCD2259)
--- Smashes a vehicles window. See eWindowId declared in [`IS_VEHICLE_WINDOW_INTACT`](#\_0x46E571A0E20D01F1).
-- @param vehicle The vehicle id.
-- @param windowIndex Windows to smash index.
function Global.SmashVehicleWindow(vehicle, windowIndex)
	return _in2(fn, vehicle, windowIndex)
end

local fn = _gn(0x8204DA7934DF3155)
--- NETWORK_SPENT_REQUEST_JOB
function Global.N_0x8204da7934df3155(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

local fn = _gn(0xD3A6A0EF48823A8C)
--- Gets the next zone that has been disabled using SET_GPS_DISABLED_ZONE_AT_INDEX.
-- ```
-- NativeDB Removed Parameter 1: int index
-- ```
-- @return The disabled zone index
function Global.N_0xd3a6a0ef48823a8c(index)
	return _in2(fn, index, _ri)
end

local fn = _gn(0xF3BBE884A14BB413)
--- Refer to [`SET_WEATHER_TYPE_NOW_PERSIST`](#\_0xED712CA327900C8A) for weather types.
function Global.GetWeatherTypeTransition()
	return _in2(fn, _i, _i, _f)
end

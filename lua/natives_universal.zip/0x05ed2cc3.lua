local fn = _gn(0x7D7D2B47FA788E85)
--- WAYPOINT_PLAYBACK_OVERRIDE_SPEED
function Global.WaypointPlaybackOverrideSpeed(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

local fn = _gn(0x1DD2139A9A20DCE8)
--- BEGIN_TAKE_MISSION_CREATOR_PHOTO
function Global.BeginTakeMissionCreatorPhoto()
	return _in2(fn, _r)
end

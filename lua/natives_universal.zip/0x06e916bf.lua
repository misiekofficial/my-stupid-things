local fn = _gn(0xE6869BECDD8F2403)
--- REMOVE_POP_MULTIPLIER_SPHERE
function Global.N_0xe6869becdd8f2403(id, p1)
	return _in2(fn, id, p1)
end

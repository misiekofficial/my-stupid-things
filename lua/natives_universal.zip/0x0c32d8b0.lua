local fn = _gn(0x31B73D1EA9F01DA2)
--- CLEAR_FOCUS
function Global.ClearFocus()
	return _in2(fn)
end

local fn = _gn(0x2CE544C68FB812A0)
--- ADD_ROAD_NODE_SPEED_ZONE
function Global.AddSpeedZoneForCoord(x, y, z, radius, speed, p5)
	return _in2(fn, x, y, z, radius, speed, p5, _ri)
end

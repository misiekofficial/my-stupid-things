local fn = _gn(0x4EBB7E87AA0DBED4)
--- If toggle is true, the ped's head is shown in the pause menu
-- If toggle is false, the ped's head is not shown in the pause menu
function Global.N_0x4ebb7e87aa0dbed4(toggle)
	return _in2(fn, toggle)
end

local fn = _gn(0xEA14EEF5B7CD2C30)
--- IS_COMMERCE_DATA_VALID
function Global.IsCommerceDataValid()
	return _in2(fn, _r)
end

local fn = _gn(0xA29177F7703B5644)
--- NETWORK_SESSION_FORCE_CANCEL_INVITE
function Global.N_0xa29177f7703b5644()
	return _in2(fn)
end

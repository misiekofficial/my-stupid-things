local fn = _gn(0xF34EE736CF047844)
--- FLOOR
function Global.Floor(value)
	return _in2(fn, value, _ri)
end

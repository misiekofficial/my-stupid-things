local fn = _gn(0x186E5D252FA50E7D)
--- GET_WAYPOINT_BLIP_ENUM_ID
function Global.GetWaypointBlipEnumId()
	return _in2(fn, _ri)
end

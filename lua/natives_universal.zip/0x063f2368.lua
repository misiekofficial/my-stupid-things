local fn = _gn(0xD2DCCD8E16E20997)
--- Resets the override for [SET_VEHICLE_STARTUP_REV_SOUND](#\_0xF1F8157B8C3F171C)
function Global.N_0xd2dccd8e16e20997(vehicle)
	return _in2(fn, vehicle)
end

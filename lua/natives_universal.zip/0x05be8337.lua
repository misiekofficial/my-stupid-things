local fn = _gn(0xBFFE53AE7E67FCDC)
--- NativeDB Introduced: v1290
function Global.N_0xbffe53ae7e67fcdc(p0, p1)
	return _in2(fn, p0, p1)
end

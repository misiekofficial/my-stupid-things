local fn = _gn(0xB7ED70C49521A61D)
--- GRAPHICS::UNPATCH_DECAL_DIFFUSE_MAP(9123);
-- GRAPHICS::SET_STREAMED_TEXTURE_DICT_AS_NO_LONGER_NEEDED("MPMissMarkers256");
function Global.UnpatchDecalDiffuseMap(decalType)
	return _in2(fn, decalType)
end

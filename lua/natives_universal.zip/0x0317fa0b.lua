local fn = _gn(0x0EDEC3C276198689)
--- gets the network id of a ped
function Global.PedToNet(ped)
	return _in2(fn, ped, _ri)
end

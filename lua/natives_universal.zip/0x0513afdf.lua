local fn = _gn(0x40CF0D12D142A9E8)
--- Calls the same internal function [`_SET_PED_VOICE_GROUP`](#\_0x7CDC8C3B89F661B3) calls, but passes `voiceGroupHash` (defined as a parameter in the referenced native) as `0`.
function Global.SetPedScream(ped)
	return _in2(fn, ped)
end

local fn = _gn(0x07C61676E5BB52CD)
--- Returns true if the add license plate text request is still pending.
function Global.N_0x07c61676e5bb52cd(token)
	return _in2(fn, token, _r)
end

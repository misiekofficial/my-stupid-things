local fn = _gn(0xEC52C631A1831C03)
--- Values:
-- 0 - Dialogue Brief
-- 1 - Help Text Brief
-- 2 - Mission Objective Brief
function Global.ScaleformMovieMethodAddParamLatestBriefString(value)
	return _in2(fn, value)
end

local fn = _gn(0x15C40837039FFAF7)
--- Gets the high precision frame time of the last frame in seconds.
-- *note: the example above is way less precise.*
-- @return The frame time (in seconds) of the last frame.
function Global.GetFrameTime()
	return _in2(fn, _rf)
end

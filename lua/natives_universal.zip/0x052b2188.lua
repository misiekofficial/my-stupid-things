local fn = _gn(0x4851997F37FE9B3C)
--- Example:
-- STATS::STAT_SET_FLOAT(MISC::GET_HASH_KEY("MP0_WEAPON_ACCURACY"), 66.6f, true);
function Global.StatSetFloat(statName, value, save)
	return _in2(fn, _ch(statName), value, save, _r)
end

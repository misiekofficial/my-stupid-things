local fn = _gn(0x061CB768363D6424)
--- 0x061CB768363D6424
function Global.N_0x061cb768363d6424(ped, toggle)
	return _in2(fn, ped, toggle)
end

local fn = _gn(0x606E4D3E3CCCF3EB)
--- NETWORK_HAVE_ROS_SOCIAL_CLUB_PRIV
function Global.NetworkGetRosPrivilege_10()
	return _in2(fn, _r)
end

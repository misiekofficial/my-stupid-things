local fn = _gn(0x5CEC1A84620E7D5B)
--- SET_DISABLE_BREAKING
function Global.SetDisableBreaking(object, toggle)
	return _in2(fn, object, toggle)
end

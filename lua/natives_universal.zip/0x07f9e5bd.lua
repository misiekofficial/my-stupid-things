local fn = _gn(0xB8FBC8B1330CA9B4)
--- Calling this native will keep a vehicle's engine running after exiting.
-- @param vehicle The vehicle handle.
-- @param toggle `true` to keep the engine on, otherwise `false`.
function Global.SetVehicleKeepEngineOnWhenAbandoned(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

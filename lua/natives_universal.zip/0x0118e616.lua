local fn = _gn(0x595B5178E412E199)
--- IS_MP_GAMER_TAG_FREE
function Global.AddTrevorRandomModifier(gamerTagId)
	return _in2(fn, gamerTagId, _r)
end

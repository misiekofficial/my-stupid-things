local fn = _gn(0xE023E8AC4EF7C117)
--- SET_VEHICLE_USE_CUTSCENE_WHEEL_COMPRESSION
function Global.N_0xe023e8ac4ef7c117(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3, _ri)
end

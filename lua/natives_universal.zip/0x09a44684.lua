local fn = _gn(0xA3C0B359DCB848B6)
--- SHOW_NUMBER_ON_BLIP
function Global.ShowNumberOnBlip(blip, number)
	return _in2(fn, blip, number)
end

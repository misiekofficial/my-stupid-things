local fn = _gn(0x407DC5E97DB1A4D3)
--- NativeDB Introduced: v1493
function Global.N_0x407dc5e97db1a4d3(p0, p1)
	return _in2(fn, p0, p1)
end

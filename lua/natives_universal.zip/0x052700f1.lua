local fn = _gn(0xD705740BB0A1CF4C)
--- HAS_PLAYER_BEEN_SPOTTED_IN_STOLEN_VEHICLE
function Global.HasPlayerBeenSpottedInStolenVehicle(player)
	return _in2(fn, player, _r)
end

local fn = _gn(0x1B1E2A40A65B8521)
--- SET_AI_WEAPON_DAMAGE_MODIFIER
function Global.SetAiWeaponDamageModifier(value)
	return _in2(fn, value)
end

local fn = _gn(0x6B0E6172C9A4D902)
--- SET_AMBIENT_PEDS_DROP_MONEY
function Global.SetAmbientPedsDropMoney(p0)
	return _in2(fn, p0)
end

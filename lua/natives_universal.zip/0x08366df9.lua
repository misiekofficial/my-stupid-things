local fn = _gn(0x5B74EA8CFD5E3E7E)
--- IS_SWITCH_SKIPPING_DESCENT
function Global.IsSwitchSkippingDescent()
	return _in2(fn, _r)
end

local fn = _gn(0x19E50EB6E33E1D28)
--- _SEETHROUGH_SET_HI_LIGHT_INTENSITY
function Global.SeethroughSetHiLightIntensity(intensity)
	return _in2(fn, intensity)
end

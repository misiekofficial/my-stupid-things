local fn = _gn(0x9BDA23BF666F0855)
--- Similar to [`_SET_AIRCRAFT_BOMB_COUNT`](#\_0xF4B2ED59DEB5D774), this sets the amount of countermeasures that are present on this vehicle.
-- Use [`_GET_AIRCRAFT_COUNTERMEASURE_COUNT`](#\_0xF846AA63DF56B804) to get the current amount.
-- @param aircraft The vehicle to set the amount of countermeasures on.
-- @param count The amount of countermeasures to set on this vehicle.
function Global.SetAircraftCountermeasureCount(aircraft, count)
	return _in2(fn, aircraft, count)
end

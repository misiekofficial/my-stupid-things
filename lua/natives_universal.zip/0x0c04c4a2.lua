local fn = _gn(0x7912F7FC4F6264B6)
--- IS_PLAYER_TARGETTING_ENTITY
function Global.IsPlayerTargettingEntity(player, entity)
	return _in2(fn, player, entity, _r)
end

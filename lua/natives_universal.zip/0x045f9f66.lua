local fn = _gn(0x84698AB38D0C6636)
--- PAUSE_MENU_IS_CONTEXT_ACTIVE
function Global.PauseMenuIsContextActive(contextHash)
	return _in2(fn, _ch(contextHash), _r)
end

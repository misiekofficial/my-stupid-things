local fn = _gn(0x599E4FA1F87EB5FF)
--- NETWORK_GET_RANDOM_INT
function Global.NetworkGetRandomInt()
	return _in2(fn, _ri)
end

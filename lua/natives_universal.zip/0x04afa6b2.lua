local fn = _gn(0xAA5A7ECE2AA8FE70)
--- SET_PED_DESIRED_HEADING
function Global.SetPedDesiredHeading(ped, heading)
	return _in2(fn, ped, heading)
end

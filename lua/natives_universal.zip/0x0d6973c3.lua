local fn = _gn(0xBB8EA16ECBC976C4)
--- SC_INBOX_GET_MESSAGE_TYPE_AT_INDEX
function Global.ScInboxGetMessageTypeAtIndex(msgIndex)
	return _in2(fn, msgIndex, _ri)
end

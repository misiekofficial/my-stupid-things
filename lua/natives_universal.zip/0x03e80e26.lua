local fn = _gn(0x50A8A36201DBF83E)
--- NativeDB Added Parameter 1: char* p0
-- NativeDB Added Parameter 2: float* p1
-- NativeDB Introduced: v323
function Global.N_0x50a8a36201dbf83e()
	return _in2(fn, _r)
end

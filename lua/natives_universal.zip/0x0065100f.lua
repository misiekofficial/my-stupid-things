local fn = _gn(0x23DFB504655D0CE4)
--- NETWORK_SESSION_WAS_INVITED
function Global.NetworkSessionWasInvited()
	return _in2(fn, _r)
end

local fn = _gn(0x56CE820830EF040B)
--- NETWORK_SESSION_GET_MATCHMAKING_GROUP_FREE
function Global.N_0x56ce820830ef040b(p0)
	return _in2(fn, p0, _ri)
end

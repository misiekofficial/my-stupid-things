local fn = _gn(0x291E373D483E7EE7)
--- IS_ANY_PED_RAPPELLING_FROM_HELI
function Global.AnyPassengersRappeling(vehicle)
	return _in2(fn, vehicle, _r)
end

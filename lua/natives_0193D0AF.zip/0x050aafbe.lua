local fn = _gn(0x8378627201D5497D)
function Global.SetPedChanceOfFiringBlanks(ped, xBias, yBias)
	return _in2(fn, ped, xBias, yBias)
end

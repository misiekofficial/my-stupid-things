local fn = _gn(0x35F7DD45E8C0A16D)
function Global.IsInteriorPropEnabled(interiorID, propName)
	return _in2(fn, interiorID, _ts(propName), _r)
end

local fn = _gn(0xE57397B4A3429DD0)
function Global.NetworkSessionGetInviter(networkHandle)
	return _in2(fn, _ii(networkHandle) --[[ may be optional ]])
end

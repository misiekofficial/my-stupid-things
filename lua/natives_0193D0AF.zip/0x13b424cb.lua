local fn = _gn(0x6F697A66CE78674E)
function Global.N_0x6f697a66ce78674e(team, toggle)
	return _in2(fn, team, toggle)
end

local fn = _gn(0x560A43136EB58105)
function Global.SetPedHelmet(ped, canWearHelmet)
	return _in2(fn, ped, canWearHelmet)
end

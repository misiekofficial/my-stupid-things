local fn = _gn(0x2C83A9DA6BFFC4F9)
function Global.GetNumberOfInstancesOfScriptWithNameHash(scriptHash)
	return _in2(fn, _ch(scriptHash), _ri)
end

local fn = _gn(0x6B1E8E2ED1335B71)
function Global.DecorSetBool(entity, propertyName, value)
	return _in2(fn, entity, _ts(propertyName), value, _r)
end

local fn = _gn(0x7DCF7C708D292D55)
function Global.OverrideCamSplineMotionBlur(cam, p1, p2, p3)
	return _in2(fn, cam, p1, p2, p3)
end

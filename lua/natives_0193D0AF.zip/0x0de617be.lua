local fn = _gn(0x16F46FB18C8009E4)
function Global.N_0x16f46fb18c8009e4(p0, p1, p2, p3, p4)
	return _in2(fn, p0, p1, p2, p3, p4, _ri)
end

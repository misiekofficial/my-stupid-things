local fn = _gn(0xC2B82527CA77053E)
function Global.NetworkClearPropertyId()
	return _in2(fn)
end

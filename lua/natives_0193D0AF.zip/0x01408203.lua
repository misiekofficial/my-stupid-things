local fn = _gn(0xcd949e20)
--- See [SET_SCRIPT_GFX_ALIGN](#\_0xB8A850F20A067EB6) for details about how gfx align works.
-- @param id The hud component id.
function Global.GetHudComponentAlign(id)
	return _in2(fn, id, _i, _i)
end

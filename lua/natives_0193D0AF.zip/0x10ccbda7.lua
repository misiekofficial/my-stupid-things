local fn = _gn(0x05983472F0494E60)
function Global.CreateIncidentWithEntity(incidentType, ped, amountOfPeople, radius, outIncidentID)
	return _in2(fn, incidentType, ped, amountOfPeople, radius, _ii(outIncidentID) --[[ may be optional ]], _r)
end

local fn = _gn(0x936E6168A9BCEDB5)
function Global.GetEventExists(p0, p1)
	return _in2(fn, p0, p1, _r)
end

local fn = _gn(0xF2BFA0430F0A0FCB)
function Global.SetVehicleDoorControl(vehicle, doorIndex, speed, angle)
	return _in2(fn, vehicle, doorIndex, speed, angle)
end

local fn = _gn(0x70B8EC8FC108A634)
function Global.N_0x70b8ec8fc108a634(p0, p1)
	return _in2(fn, p0, p1)
end

local fn = _gn(0x726E0375C7A26368)
function Global.NetworkRemoveAllTransitionInvite()
	return _in2(fn)
end

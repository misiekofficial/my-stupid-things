local fn = _gn(0xC5286FFC176F28A2)
function Global.IsPedRunning(ped)
	return _in2(fn, ped, _r)
end

local fn = _gn(0x291E373D483E7EE7)
function Global.AnyPassengersRappeling(vehicle)
	return _in2(fn, vehicle, _r)
end

local fn = _gn(0xDF2E1F7742402E81)
function Global.AnimateGameplayCamZoom(p0, distance)
	return _in2(fn, p0, distance)
end

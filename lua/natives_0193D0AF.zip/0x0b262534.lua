local fn = _gn(0x061CB768363D6424)
function Global.N_0x061cb768363d6424(p0, p1)
	return _in2(fn, p0, p1)
end

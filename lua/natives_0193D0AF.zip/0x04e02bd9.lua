local fn = _gn(0x4C2330E61D3DEB56)
function Global.N_0x4c2330e61d3deb56(interiorID)
	return _in2(fn, interiorID, _ri)
end

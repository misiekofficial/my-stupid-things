local fn = _gn(0x031ACB6ABA18C729)
function Global.N_0x031acb6aba18c729(radioStation, p1)
	return _in2(fn, _ts(radioStation), _ts(p1))
end

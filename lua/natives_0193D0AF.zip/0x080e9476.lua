local fn = _gn(0x28579D1B8F8AAC80)
function Global.StartShapeTestCapsule(x1, y1, z1, x2, y2, z2, radius, flags, entity, p9)
	return _in2(fn, x1, y1, z1, x2, y2, z2, radius, flags, entity, p9, _ri)
end

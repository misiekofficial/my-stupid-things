local fn = _gn(0x9ECA15ADFE141431)
function Global.N_0x9eca15adfe141431()
	return _in2(fn, _ri)
end

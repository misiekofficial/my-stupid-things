local fn = _gn(0x1185A8087587322C)
function Global.N_0x1185a8087587322c(p0)
	return _in2(fn, p0)
end

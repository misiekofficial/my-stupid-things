local fn = _gn(0x668FD40BCBA5DE48)
function Global.N_0x668fd40bcba5de48(p0, p1, p2, p3, p4)
	return _in2(fn, p0, p1, p2, p3, p4, _ri)
end

local fn = _gn(0x3F892CAF67444AE7)
function Global.CreateIncident(incidentType, x, y, z, p5, radius, outIncidentID)
	return _in2(fn, incidentType, x, y, z, p5, radius, _ii(outIncidentID) --[[ may be optional ]], _r)
end

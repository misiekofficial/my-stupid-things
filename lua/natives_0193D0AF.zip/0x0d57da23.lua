local fn = _gn(0x84A2DD9AC37C35C1)
function Global.IsPedInjured(ped)
	return _in2(fn, ped, _r)
end

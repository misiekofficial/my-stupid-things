local fn = _gn(0xD830567D88A1E873)
function Global.NetworkSetEntityCanBlend(entity, toggle)
	return _in2(fn, entity, toggle)
end

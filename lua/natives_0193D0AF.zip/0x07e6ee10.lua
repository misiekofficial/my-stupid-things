local fn = _gn(0x957838AAF91BD12D)
function Global.ClearAreaOfEverything(x, y, z, radius, p4, p5, p6, p7)
	return _in2(fn, x, y, z, radius, p4, p5, p6, p7)
end

local fn = _gn(0xED5FD7AF10F5E262)
function Global.N_0xed5fd7af10f5e262(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3)
end

local fn = _gn(0x97DD4C5944CC2E6A)
function Global.N_0x97dd4c5944cc2e6a(player, toggle)
	return _in2(fn, player, toggle)
end

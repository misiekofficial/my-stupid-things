local fn = _gn(0x93A3996368C94158)
function Global.SetVehicleEnginePowerMultiplier(vehicle, value)
	return _in2(fn, vehicle, value)
end

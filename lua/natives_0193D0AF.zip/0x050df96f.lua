local fn = _gn(0x65499865FCA6E5EC)
function Global.N_0x65499865fca6e5ec(doorHash)
	return _in2(fn, _ch(doorHash), _rf)
end

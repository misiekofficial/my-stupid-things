local fn = _gn(0x7A1ADEEF01740A24)
function Global.NetworkGetDestroyerOfNetworkId(netId, weaponHash)
	return _in2(fn, netId, _ii(weaponHash) --[[ may be optional ]], _ri)
end

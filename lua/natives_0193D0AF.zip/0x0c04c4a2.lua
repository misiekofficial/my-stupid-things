local fn = _gn(0x7912F7FC4F6264B6)
function Global.IsPlayerTargettingEntity(player, entity)
	return _in2(fn, player, entity, _r)
end

local fn = _gn(0xE679E3E06E363892)
function Global.NetworkOverrideClockTime(Hours, Minutes, Seconds)
	return _in2(fn, Hours, Minutes, Seconds)
end

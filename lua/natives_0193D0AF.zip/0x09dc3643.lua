local fn = _gn(0xFCC228E07217FCAC)
function Global.N_0xfcc228e07217fcac(p0)
	return _in2(fn, p0)
end

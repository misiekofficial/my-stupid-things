local fn = _gn(0xCEA04D83135264CC)
function Global.SetPedArmour(ped, amount)
	return _in2(fn, ped, amount)
end

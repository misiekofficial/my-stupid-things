local fn = _gn(0x8B6A4DD0AF9CE215)
function Global.NetworkSessionSetMaxPlayers(playerType, playerCount)
	return _in2(fn, playerType, playerCount)
end

local fn = _gn(0x015C49A93E3E086E)
function Global.DisablePhoneThisFrame(toggle)
	return _in2(fn, toggle)
end

local fn = _gn(0xB21B89501CFAC79E)
function Global.NetworkSpentProstitutes(p0, p1, p2)
	return _in2(fn, p0, p1, p2)
end

local fn = _gn(0x07F1BE2BCCAA27A7)
function Global.FindAnimEventPhase(animDictionary, animName, p2)
	return _in2(fn, _ts(animDictionary), _ts(animName), _ts(p2), _i, _i, _r)
end

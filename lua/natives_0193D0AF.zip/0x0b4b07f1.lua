local fn = _gn(0x2CE056FF3723F00B)
function Global.StatGetNumberOfSeconds(statName)
	return _in2(fn, _ch(statName), _ri)
end

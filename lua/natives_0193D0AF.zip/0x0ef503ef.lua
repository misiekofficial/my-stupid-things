local fn = _gn(0x1ACCFBA3D8DAB2EE)
function Global.N_0x1accfba3d8dab2ee(p0, p1)
	return _in2(fn, p0, p1, _ri)
end

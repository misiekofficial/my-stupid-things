local fn = _gn(0xBB03C38DD3FB7FFD)
function Global.SetPedAsCop(ped, toggle)
	return _in2(fn, ped, toggle)
end

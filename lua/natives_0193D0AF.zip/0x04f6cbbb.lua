local fn = _gn(0x817B86108EB94E51)
function Global.N_0x817b86108eb94e51(p0)
	return _in2(fn, p0, _i, _i, _i, _i, _i, _i, _i, _i)
end

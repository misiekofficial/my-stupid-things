local fn = _gn(0x3D42B92563939375)
function Global.N_0x3d42b92563939375(p0)
	return _in2(fn, _ts(p0), _r)
end

local fn = _gn(0x761B77454205A61D)
function Global.AddTextComponentAppTitle(p0, p1)
	return _in2(fn, _ts(p0), p1)
end

local fn = _gn(0xD76632D99E4966C8)
function Global.SetPedToRagdollWithFall(ped, time, p2, ragdollType, x, y, z, p7, p8, p9, p10, p11, p12, p13)
	return _in2(fn, ped, time, p2, ragdollType, x, y, z, p7, p8, p9, p10, p11, p12, p13, _r)
end

local fn = _gn(0xEA241BB04110F091)
function Global.SetPlayerAngry(playerPed, disabled)
	return _in2(fn, playerPed, disabled)
end

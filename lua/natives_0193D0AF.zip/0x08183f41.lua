local fn = _gn(0x9A2C8064B6C1E41A)
function Global.ScInboxMessagePush(p0)
	return _in2(fn, p0, _r)
end

local fn = _gn(0x3C606747B23E497B)
function Global.SetPedCombatRange(ped, p1)
	return _in2(fn, ped, p1)
end

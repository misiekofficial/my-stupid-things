local fn = _gn(0xAE99FB955581844A)
function Global.SetPedToRagdoll(ped, time1, time2, ragdollType, p4, p5, p6)
	return _in2(fn, ped, time1, time2, ragdollType, p4, p5, p6, _r)
end

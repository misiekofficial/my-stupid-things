local fn = _gn(0xC9853A2BE3DED1A6)
function Global.AppGetDeletedFileStatus()
	return _in2(fn, _ri)
end

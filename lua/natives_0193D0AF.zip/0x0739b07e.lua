local fn = _gn(0xd7531645)
--- Returns all registered vehicle model names, including non-dlc vehicles and custom vehicles in no particular order.
-- **Example output**
-- ```
-- ["dubsta", "dubsta2", "dubsta3", "myverycoolcar", "sultan", "sultanrs", ...]
-- ```
-- This native will not return vehicles that are unregistered (i.e from a resource being stopped) during runtime.
function Global.GetAllVehicleModels()
	return _in2(fn, _ro)
end

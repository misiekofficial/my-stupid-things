local fn = _gn(0xcc90cbca)
--- Returns the offset of the specified wheel relative to the wheel's axle center.
function Global.GetVehicleWheelXOffset(vehicle, wheelIndex)
	return _in2(fn, vehicle, wheelIndex, _rf)
end

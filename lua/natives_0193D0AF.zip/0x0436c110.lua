local fn = _gn(0x0DB57B41EC1DB083)
function Global.GetWeaponComponentTypeModel(componentHash)
	return _in2(fn, _ch(componentHash), _ri)
end

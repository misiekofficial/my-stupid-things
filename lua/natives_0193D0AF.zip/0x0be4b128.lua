local fn = _gn(0xB4C7A93837C91A1F)
function Global.GetLiveryName(vehicle, liveryIndex)
	return _in2(fn, vehicle, liveryIndex, _s)
end

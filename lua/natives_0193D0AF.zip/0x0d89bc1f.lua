local fn = _gn(0x72BECCF4B829522E)
function Global.N_0x72beccf4b829522e(p0, p1)
	return _in2(fn, p0, p1)
end

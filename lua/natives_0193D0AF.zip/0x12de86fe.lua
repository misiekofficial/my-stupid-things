local fn = _gn(0x74FB3E29E6D10FA9)
function Global.N_0x74fb3e29e6d10fa9()
	return _in2(fn, _ri)
end

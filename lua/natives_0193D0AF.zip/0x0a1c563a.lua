local fn = _gn(0x4F056E1AFFEF17AB)
function Global.TaskForceMotionState(ped, state, p2)
	return _in2(fn, ped, _ch(state), p2)
end

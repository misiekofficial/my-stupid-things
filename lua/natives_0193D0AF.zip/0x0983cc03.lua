local fn = _gn(0xBA751764F0821256)
function Global.N_0xba751764f0821256()
	return _in2(fn)
end

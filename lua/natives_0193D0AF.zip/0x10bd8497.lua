local fn = _gn(0x451294E859ECC018)
function Global.N_0x451294e859ecc018(p0)
	return _in2(fn, p0, _ri)
end

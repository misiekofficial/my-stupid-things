local fn = _gn(0xD1C55B110E4DF534)
function Global.N_0xd1c55b110e4df534(p0)
	return _in2(fn, p0)
end

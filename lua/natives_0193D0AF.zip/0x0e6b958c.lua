local fn = _gn(0x040ADDCBAFA1018A)
function Global.ScInboxGetEmails(offset, limit)
	return _in2(fn, offset, limit)
end

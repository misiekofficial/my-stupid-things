local fn = _gn(0xC7848EFCCC545182)
function Global.SetCamNearClip(cam, nearClip)
	return _in2(fn, cam, nearClip)
end

local fn = _gn(0x8D474C8FAEFF6CDE)
function Global.IsVehicleShopResprayAllowed(vehicle)
	return _in2(fn, vehicle, _r)
end

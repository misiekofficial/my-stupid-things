local fn = _gn(0xEEA929141F699854)
function Global.TaskSynchronizedScene(ped, scene, animDictionary, animationName, speed, speedMultiplier, duration, flag, playbackRate, p9)
	return _in2(fn, ped, scene, _ts(animDictionary), _ts(animationName), speed, speedMultiplier, duration, flag, playbackRate, p9)
end

local fn = _gn(0x814C9D19DFD69679)
function Global.GetMaxRangeOfCurrentPedWeapon(ped)
	return _in2(fn, ped, _rf)
end

local fn = _gn(0x3856d767)
--- GET_VEHICLE_DASHBOARD_OIL_PRESSURE
function Global.GetVehicleDashboardOilPressure()
	return _in2(fn, _rf)
end

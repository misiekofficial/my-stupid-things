local fn = _gn(0x3FA4BF0A7AB7DE2C)
function Global.SetCamNearDof(cam, nearDOF)
	return _in2(fn, cam, nearDOF)
end

local fn = _gn(0xEB078CA2B5E82ADD)
function Global.N_0xeb078ca2b5e82add(p0, p1)
	return _in2(fn, p0, p1)
end

local fn = _gn(0xDBA3C090E3D74690)
function Global.N_0xdba3c090e3d74690(vehicle)
	return _in2(fn, vehicle)
end

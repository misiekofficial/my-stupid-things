local fn = _gn(0xBBF327DED94E4DEB)
function Global.N_0xbbf327ded94e4deb(p0)
	return _in2(fn, _ts(p0))
end

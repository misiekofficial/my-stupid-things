local fn = _gn(0x61767F73EACEED21)
function Global.N_0x61767f73eaceed21(ped)
	return _in2(fn, ped, _r)
end

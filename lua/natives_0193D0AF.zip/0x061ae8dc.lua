local fn = _gn(0x5F43D83FD6738741)
function Global.IsPlayerVehicleRadioEnabled()
	return _in2(fn, _r)
end

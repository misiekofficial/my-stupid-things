local fn = _gn(0xF3D78F59DFE18D79)
function Global.SetFadeInAfterLoad(toggle)
	return _in2(fn, toggle)
end

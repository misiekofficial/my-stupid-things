local fn = _gn(0xD9B71952F78A2640)
function Global.N_0xd9b71952f78a2640(doorHash, p1)
	return _in2(fn, _ch(doorHash), p1)
end

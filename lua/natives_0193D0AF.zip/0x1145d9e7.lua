local fn = _gn(0xA00EFE4082C4056E)
function Global.ScInboxMessageGetDataInt(p0, context, out)
	return _in2(fn, p0, _ts(context), _ii(out) --[[ may be optional ]], _r)
end

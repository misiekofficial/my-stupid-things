local fn = _gn(0x8A1C8B1738FFE87E)
function Global.GetHashOfThisScriptName()
	return _in2(fn, _ri)
end

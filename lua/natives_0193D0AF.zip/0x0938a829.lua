local fn = _gn(0x578C752848ECFA0C)
function Global.SetWeatherTypeTransition(weatherType1, weatherType2, percentWeather2)
	return _in2(fn, _ch(weatherType1), _ch(weatherType2), percentWeather2)
end

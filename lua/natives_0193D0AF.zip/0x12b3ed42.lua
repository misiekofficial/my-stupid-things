local fn = _gn(0x8844BBFCE30AA9E9)
function Global.ClearPedAlternateWalkAnim(ped, p1)
	return _in2(fn, ped, p1)
end

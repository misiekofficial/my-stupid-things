local fn = _gn(0x1E7889778264843A)
function Global.TaskExtendRoute(x, y, z)
	return _in2(fn, x, y, z)
end

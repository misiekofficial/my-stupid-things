local fn = _gn(0x04456F95153C6BE4)
function Global.StopSaveArray()
	return _in2(fn)
end

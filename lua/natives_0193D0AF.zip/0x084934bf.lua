local fn = _gn(0xCD536C4D33DCC900)
function Global.PlayEndCreditsMusic(play)
	return _in2(fn, play)
end

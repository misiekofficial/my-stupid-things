local fn = _gn(0x700569DBA175A77C)
function Global.N_0x700569dba175a77c(p0)
	return _in2(fn, p0, _ri)
end

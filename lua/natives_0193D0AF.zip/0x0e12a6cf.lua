local fn = _gn(0x67AA4D73F0CFA86B)
function Global.EnableScriptBrainSet(brainSet)
	return _in2(fn, brainSet)
end

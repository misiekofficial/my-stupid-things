local fn = _gn(0x845FFC3A4FEEFA3E)
function Global.AudioIsScriptedMusicPlaying()
	return _in2(fn, _ri)
end

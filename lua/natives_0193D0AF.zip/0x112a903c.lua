local fn = _gn(0xF6F5161F4534EDFF)
function Global.GetEntityPopulationType(entity)
	return _in2(fn, entity, _ri)
end

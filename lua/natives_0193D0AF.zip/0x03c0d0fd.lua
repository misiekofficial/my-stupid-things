local fn = _gn(0x7CAEC29ECB5DFEBB)
function Global.RegisterFloatToSave(name)
	return _in2(fn, _i, _ts(name))
end

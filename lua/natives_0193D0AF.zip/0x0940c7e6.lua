local fn = _gn(0x3353D13F09307691)
function Global.ResetEditorValues()
	return _in2(fn)
end

local fn = _gn(0x6D6840CEE8845831)
function Global.N_0x6d6840cee8845831(action)
	return _in2(fn, _ts(action))
end

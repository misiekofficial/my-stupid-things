local fn = _gn(0xD69736AAE04DB51A)
function Global.PushScaleformMovieFunctionParameterFloat(value)
	return _in2(fn, value)
end

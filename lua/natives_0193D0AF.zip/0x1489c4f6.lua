local fn = _gn(0xAA5D6B1888E4DB20)
function Global.DeleteChildRope(rope)
	return _in2(fn, rope, _ri)
end

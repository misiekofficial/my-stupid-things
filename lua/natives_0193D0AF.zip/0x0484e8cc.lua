local fn = _gn(0x920D853F3E17F1DA)
function Global.N_0x920d853f3e17f1da(interiorID, roomHashKey)
	return _in2(fn, interiorID, _ch(roomHashKey))
end

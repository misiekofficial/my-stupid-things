local fn = _gn(0x3F9F16F8E65A7ED7)
function Global.GetPlayerSprintStaminaRemaining(player)
	return _in2(fn, player, _rf)
end

local fn = _gn(0x644546EC5287471B)
function Global.N_0x644546ec5287471b()
	return _in2(fn, _r)
end

local fn = _gn(0x211AB1DD8D0F363A)
function Global.DecorSetFloat(entity, propertyName, value)
	return _in2(fn, entity, _ts(propertyName), value, _r)
end

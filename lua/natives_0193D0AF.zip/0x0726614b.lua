local fn = _gn(0xB2EBE8CBC58B90E9)
function Global.N_0xb2ebe8cbc58b90e9()
	return _in2(fn, _ri)
end

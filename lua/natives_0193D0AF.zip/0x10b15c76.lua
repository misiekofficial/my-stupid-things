local fn = _gn(0xB81656BC81FE24D1)
function Global.SetBlipFriendly(blip, toggle)
	return _in2(fn, blip, toggle)
end

local fn = _gn(0x3EB1FE9E8E908E15)
function Global.TaskCower(ped, duration)
	return _in2(fn, ped, duration)
end

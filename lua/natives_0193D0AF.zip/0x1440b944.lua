local fn = _gn(0x70033C3CC29A1FF4)
function Global.SetAnimLooped(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3)
end

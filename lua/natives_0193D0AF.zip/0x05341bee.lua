local fn = _gn(0x2AA720E4287BF269)
function Global.SetVehicleNeonLightEnabled(vehicle, index, toggle)
	return _in2(fn, vehicle, index, toggle)
end

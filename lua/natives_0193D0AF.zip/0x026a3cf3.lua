local fn = _gn(0xF6829842C06AE524)
function Global.GetWaterHeight(x, y, z, height)
	return _in2(fn, x, y, z, _fi(height) --[[ may be optional ]], _r)
end

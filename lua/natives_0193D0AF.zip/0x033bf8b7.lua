local fn = _gn(0x20C6C7E4EB082A7F)
function Global.N_0x20c6c7e4eb082a7f(p0)
	return _in2(fn, p0)
end

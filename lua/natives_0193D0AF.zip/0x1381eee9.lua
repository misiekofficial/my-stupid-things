local fn = _gn(0x676ED266AADD31E0)
function Global.NetworkIsPartyMember(networkHandle)
	return _in2(fn, _ii(networkHandle) --[[ may be optional ]], _r)
end

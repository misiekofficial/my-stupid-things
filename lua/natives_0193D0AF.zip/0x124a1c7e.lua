local fn = _gn(0x84ED31191CC5D2C9)
function Global.GetIsHidef()
	return _in2(fn, _r)
end

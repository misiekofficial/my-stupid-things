local fn = _gn(0xB32209EFFDC04913)
function Global.ClearAllBrokenGlass()
	return _in2(fn, _ri)
end

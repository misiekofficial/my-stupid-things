local fn = _gn(0x8927CBF9D22261A4)
function Global.Atan2(p0, p1)
	return _in2(fn, p0, p1, _rf)
end

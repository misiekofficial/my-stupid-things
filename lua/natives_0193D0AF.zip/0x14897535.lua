local fn = _gn(0x808519373FD336A3)
function Global.SetDirectorMode(toggle)
	return _in2(fn, toggle)
end

local fn = _gn(0xA2297E18F3E71C2E)
function Global.SetGameplayVehicleHint(p0, p1, p2, p3, p4, p5, p6, p7)
	return _in2(fn, p0, p1, p2, p3, p4, p5, p6, p7)
end

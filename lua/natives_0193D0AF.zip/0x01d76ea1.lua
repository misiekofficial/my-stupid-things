local fn = _gn(0xC5F0A8EBD3F361CE)
function Global.SetUnkMapFlag(flag)
	return _in2(fn, flag)
end

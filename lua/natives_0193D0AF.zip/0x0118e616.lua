local fn = _gn(0x595B5178E412E199)
function Global.AddTrevorRandomModifier(gamerTagId)
	return _in2(fn, gamerTagId, _r)
end

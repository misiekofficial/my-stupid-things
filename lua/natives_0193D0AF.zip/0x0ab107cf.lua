local fn = _gn(0x0FF2862B61A58AF9)
function Global.N_0x0ff2862b61a58af9(p0)
	return _in2(fn, p0)
end

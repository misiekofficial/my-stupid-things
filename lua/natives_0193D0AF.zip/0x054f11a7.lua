local fn = _gn(0xEB1774DF12BB9F12)
function Global.StopSaveStruct()
	return _in2(fn)
end

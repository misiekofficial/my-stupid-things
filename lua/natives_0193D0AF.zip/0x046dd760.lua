local fn = _gn(0x5AFEEDD9BB2899D7)
function Global.SetVehicleProvidesCover(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

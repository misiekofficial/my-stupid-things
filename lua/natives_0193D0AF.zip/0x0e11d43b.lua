local fn = _gn(0x1280804F7CFD2D6C)
function Global.N_0x1280804f7cfd2d6c(p0)
	return _in2(fn, p0)
end

local fn = _gn(0xF36199225D6D8C86)
function Global.SetCloudHatOpacity(opacity)
	return _in2(fn, opacity)
end

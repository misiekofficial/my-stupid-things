local fn = _gn(0x18F621F7A5B1F85D)
function Global.SetNightvision(toggle)
	return _in2(fn, toggle)
end

local fn = _gn(0x22EF8FF8778030EB)
function Global.ResetPedInVehicleContext(ped)
	return _in2(fn, ped)
end

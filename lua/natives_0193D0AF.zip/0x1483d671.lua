local fn = _gn(0xCE5F689CF5A0A49D)
function Global.NetworkGetPlayerFromGamerHandle(networkHandle)
	return _in2(fn, _ii(networkHandle) --[[ may be optional ]], _ri)
end

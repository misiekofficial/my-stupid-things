local fn = _gn(0x62A456AA4769EF34)
function Global.PlayVehicleDoorCloseSound(vehicle, p1)
	return _in2(fn, vehicle, p1)
end

local fn = _gn(0x621C6E4729388E41)
function Global.N_0x621c6e4729388e41(ped)
	return _in2(fn, ped, _r)
end

local fn = _gn(0x1C7302E725259789)
function Global.DoesTextBlockExist(gxt)
	return _in2(fn, _ts(gxt), _r)
end

local fn = _gn(0xB48FCED898292E52)
function Global.GetDesObject(x, y, z, rotation, name)
	return _in2(fn, x, y, z, rotation, _ts(name), _ri)
end

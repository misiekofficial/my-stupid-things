local fn = _gn(0x2902843FCD2B2D79)
function Global.GetEventData(p0, p1, p3)
	return _in2(fn, p0, p1, _i, p3, _r)
end

local fn = _gn(0xE659E47AF827484B)
function Global.IsEntityOnScreen(entity)
	return _in2(fn, entity, _r)
end

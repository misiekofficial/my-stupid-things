local fn = _gn(0x0B568201DD99F0EB)
function Global.N_0x0b568201dd99f0eb(p0)
	return _in2(fn, p0)
end

local fn = _gn(0xEB709A36958ABE0D)
function Global.N_0xeb709a36958abe0d(gamerTagId)
	return _in2(fn, gamerTagId, _r)
end

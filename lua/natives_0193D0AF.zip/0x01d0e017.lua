local fn = _gn(0x28157D43CF600981)
function Global.SetScenarioPedsSpawnInSphereArea(p0, p1, p2, p3, p4)
	return _in2(fn, p0, p1, p2, p3, p4)
end

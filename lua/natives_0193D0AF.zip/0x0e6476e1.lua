local fn = _gn(0x5BC9495F0B3B6FA6)
function Global.NetworkHasControlOfPickup(pickup)
	return _in2(fn, pickup, _r)
end

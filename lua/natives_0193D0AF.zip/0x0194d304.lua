local fn = _gn(0xFE99B66D079CF6BC)
function Global.DisableControlAction(inputGroup, control, disable)
	return _in2(fn, inputGroup, control, disable)
end

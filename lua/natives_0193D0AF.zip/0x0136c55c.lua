local fn = _gn(0x17330EBF2F2124A8)
function Global.N_0x17330ebf2f2124a8()
	return _in2(fn)
end

local fn = _gn(0xAE032F8BBA959E90)
function Global.TaskStandGuard(ped, x, y, z, heading, scenarioName)
	return _in2(fn, ped, x, y, z, heading, _ts(scenarioName))
end

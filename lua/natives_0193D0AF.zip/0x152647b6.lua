local fn = _gn(0xE625BEABBAFFDAB9)
function Global.GetCutsceneTime()
	return _in2(fn, _ri)
end

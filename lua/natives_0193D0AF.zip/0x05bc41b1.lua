local fn = _gn(0x95C5D356CDA6E85F)
function Global.AppSaveData()
	return _in2(fn)
end

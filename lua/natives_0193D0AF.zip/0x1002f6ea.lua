local fn = _gn(0xBE197EAA669238F4)
function Global.N_0xbe197eaa669238f4(p0, p1, p2, p3)
	return _in2(fn, p0, p1, p2, p3, _ri)
end

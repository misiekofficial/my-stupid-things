local fn = _gn(0x31125FD509D9043F)
function Global.N_0x31125fd509d9043f(p0)
	return _in2(fn, p0)
end

local fn = _gn(0x59BF8C3D52C92F66)
function Global.SetVehicleCanBreak(vehicle, toggle)
	return _in2(fn, vehicle, toggle)
end

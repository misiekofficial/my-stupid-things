local fn = _gn(0xBE22B26DD764C040)
function Global.GetAnimInitialOffsetPosition(animDict, animName, x, y, z, xRot, yRot, zRot, p8, p9)
	return _in2(fn, _ts(animDict), _ts(animName), x, y, z, xRot, yRot, zRot, p8, p9, _rv)
end

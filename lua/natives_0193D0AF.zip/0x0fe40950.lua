local fn = _gn(0x817268968605947A)
function Global.AssistedMovementRequestRoute(route)
	return _in2(fn, _ts(route))
end

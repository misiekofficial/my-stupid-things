local fn = _gn(0x813A0A7C9D2E831F)
function Global.IsPedHeadtrackingEntity(ped, entity)
	return _in2(fn, ped, entity, _r)
end

local fn = _gn(0x1461B28A06717D68)
function Global.N_0x1461b28a06717d68(p0)
	return _in2(fn, p0, _ri)
end

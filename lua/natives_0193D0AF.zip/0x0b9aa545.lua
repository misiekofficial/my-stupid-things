local fn = _gn(0x09693B0312F91649)
function Global.TaskRappelFromHeli(ped, unused)
	return _in2(fn, ped, unused)
end

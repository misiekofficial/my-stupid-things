local fn = _gn(0x327EDEEEAC55C369)
function Global.IsHelpMessageFadingOut()
	return _in2(fn, _r)
end

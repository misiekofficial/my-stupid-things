local fn = _gn(0x5F3B7749C112D552)
function Global.SuppressAgitationEventsNextFrame()
	return _in2(fn)
end

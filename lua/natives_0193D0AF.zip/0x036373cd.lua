local fn = _gn(0x991251AFC3981F84)
function Global.IsCutsceneActive()
	return _in2(fn, _r)
end

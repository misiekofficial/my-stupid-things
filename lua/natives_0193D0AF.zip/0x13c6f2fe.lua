local fn = _gn(0x2016C603D6B8987C)
function Global.N_0x2016c603d6b8987c(p0, p1)
	return _in2(fn, p0, p1)
end

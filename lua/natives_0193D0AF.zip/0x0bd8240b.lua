local fn = _gn(0xD10282B6E3751BA0)
function Global.N_0xd10282b6e3751ba0()
	return _in2(fn, _ri)
end

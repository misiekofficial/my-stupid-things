local fn = _gn(0x62522002E0C391BA)
function Global.IsSynchronizedSceneLooped(sceneID)
	return _in2(fn, sceneID, _r)
end

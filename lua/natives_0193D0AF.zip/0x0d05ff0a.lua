local fn = _gn(0x855BC38818F6F684)
function Global.N_0x855bc38818f6f684()
	return _in2(fn, _r)
end
